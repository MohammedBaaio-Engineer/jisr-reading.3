/* بنك المفردات — الكلمات العامة (2) */
window.WORDBANK_RAW = window.WORDBANK_RAW || [];
window.WORDBANK_RAW.push({ cat: "general", title: "الزمن والتكرار", text: `
today|اليوم|What did you learn today?
tomorrow|غداً|See you tomorrow.
yesterday|أمس|I finished the book yesterday.
weekend|عطلة نهاية الأسبوع|I read more on the weekend.
future|المستقبل|Plan for the future.
past|الماضي|Learn from the past.
present|الحاضر / يقدّم|She will present her project.
period|فترة|The trial period is seven days.
century|قرن|This book was written in the 19th century.
decade|عقد (عشر سنوات)|Technology changed a lot in the last decade.
season|موسم / فصل|Summer is my favorite season.
daily|يومي|Make reading a daily habit.
weekly|أسبوعي|We have a weekly meeting.
monthly|شهري|The monthly price is ten dollars.
annual|سنوي|Read the annual report.
schedule|جدول|Check the class schedule.
deadline|الموعد النهائي|The deadline is Friday.
moment|لحظة|Wait a moment, please.
instant|فوري / لحظة|You get instant access.
duration|مدة|The duration of the course is six weeks.
age|عمر / عصر|We live in the digital age.
date|تاريخ / موعد|Write the date at the top.
calendar|تقويم|Add the event to your calendar.
afternoon|بعد الظهر|The class is in the afternoon.
evening|مساء|I review words in the evening.
midnight|منتصف الليل|The offer ends at midnight.
hourly|كل ساعة|The data is updated hourly.
frequent|متكرر|These are frequent words.
rare|نادر|This word is rare.
ago|منذ|I started two months ago.
soon|قريباً|The new version is coming soon.
later|لاحقاً|We will cover this later.
lately|مؤخراً|I have been busy lately.
nowadays|هذه الأيام|Nowadays, everyone uses smartphones.
forever|إلى الأبد|You keep the course forever.
temporary|مؤقت|This is a temporary solution.
permanent|دائم|The change is permanent.
previous|سابق|Go back to the previous page.
following|التالي|Read the following text.
former|سابق|He is a former teacher.
initial|أولي|The initial results look good.
original|أصلي|Keep the original file.
upcoming|قادم|Check the upcoming events.
ongoing|مستمر|This is an ongoing project.
meanwhile|في الأثناء|Meanwhile, practice the new words.
during|أثناء|Don't use your phone during the exam.
before|قبل|Read the question before the text.
after|بعد|Review the words after the lesson.
start|بداية / يبدأ|Click Start.
finish|ينهي|Finish one lesson per day.
` });

window.WORDBANK_RAW.push({ cat: "general", title: "الكميات والأرقام والقياس", text: `
amount|كمية / مبلغ|Enter the amount you want to pay.
total|إجمالي|The total is fifty dollars.
half|نصف|I read half of the book.
quarter|ربع|Sales grew in the last quarter.
double|مضاعف / يضاعف|The price doubled.
single|واحد / مفرد|Choose a single answer.
several|عدة|I read several articles today.
enough|كافٍ|We have enough time.
plenty|الكثير|There is plenty of time.
whole|كامل|The whole page is in English.
majority|الأغلبية|The majority of users are students.
minority|الأقلية|Only a minority disagreed.
average|متوسط|The average score was 80%.
maximum|الحد الأقصى|The maximum file size is 10 MB.
minimum|الحد الأدنى|The minimum age is 13.
limit|حد|There is no limit on downloads.
range|نطاق / مدى|Choose a number in this range.
size|حجم|Change the font size.
length|طول|The length of the video is ten minutes.
weight|وزن|Check the weight of the package.
distance|مسافة|Keep a safe distance.
rate|معدل|The success rate is high.
percent|بالمئة|Ninety percent of students passed.
percentage|نسبة مئوية|What percentage did you get?
count|يعدّ / عدد|Count the words in the sentence.
measure|يقيس|We measure your progress weekly.
number|عدد / رقم|The number of users is growing.
million|مليون|The app has a million users.
billion|مليار|There are billions of web pages.
thousand|ألف|Over a thousand students joined.
hundred|مئة|I know a hundred new words.
dozen|دزينة (اثنا عشر)|I made a dozen mistakes.
extra|إضافي|Extra practice helps.
increase|زيادة|There was a big increase in users.
decrease|انخفاض / يقلل|We saw a decrease in errors.
growth|نمو|Your growth is clear.
loss|خسارة / فقدان|Data loss is a serious problem.
level|مستوى|Choose your level.
degree|درجة|The temperature is 30 degrees.
scale|مقياس / حجم|On a scale of 1 to 10, how easy was it?
unit|وحدة|Finish this unit to unlock the next.
piece|قطعة|A piece of advice.
item|عنصر|Add the item to your list.
pair|زوج|Work in pairs.
row|صف|Each row is one record.
column|عمود|Add a new column.
list|قائمة|Make a list of new words.
set|مجموعة|A set of rules.
step|خطوة|Step by step.
stage|مرحلة|You finished the first stage.
` });

window.WORDBANK_RAW.push({ cat: "general", title: "الأفكار والتفكير", text: `
thought|فكرة / تفكير|That's an interesting thought.
opinion|رأي|In my opinion, reading is the key.
belief|اعتقاد|Change your belief about your ability.
knowledge|معرفة|Knowledge is power.
memory|ذاكرة|Repetition builds memory.
mind|عقل|Keep an open mind.
sense|إحساس / معنى|It makes sense now.
meaning|معنى|Guess the meaning from the context.
concept|مفهوم|This concept is easy to understand.
theory|نظرية|In theory, it should work.
principle|مبدأ|Learn the basic principles.
method|طريقة / منهج|This method is effective.
approach|أسلوب / نهج|Try a different approach.
strategy|استراتيجية|We need a better strategy.
purpose|غرض / هدف|What is the purpose of this function?
goal|هدف|My goal is to read technical books.
aim|هدف / يهدف|The aim of this course is reading.
reason|سبب|There is a good reason for this.
cause|سبب|Find the cause of the error.
effect|أثر / تأثير|Sleep has a big effect on memory.
impact|تأثير|English has a big impact on your career.
influence|تأثير / يؤثر|Friends influence our habits.
decision|قرار|It was a good decision.
choice|اختيار|You have three choices.
option|خيار|Select an option.
solution|حل|We found a simple solution.
answer|إجابة|Write your answer here.
example|مثال|Here is an example.
detail|تفصيل|Read the details later.
evidence|دليل|There is no evidence of an attack.
proof|إثبات|Show me the proof.
truth|حقيقة|Tell the truth.
fact|حقيقة|Check the facts first.
mistake|خطأ|Mistakes help you learn.
error|خطأ|Fix the error on line 5.
attention|انتباه|Pay attention to the verb.
focus|تركيز|Keep your focus.
interest|اهتمام / فائدة|I have an interest in security.
experience|خبرة / تجربة|Experience is the best teacher.
skill|مهارة|Reading is a key skill.
ability|قدرة|You have the ability to learn.
talent|موهبة|Practice beats talent.
habit|عادة|Build a reading habit.
practice|تدريب / يتدرب|Practice makes perfect.
progress|تقدم|Track your progress.
success|نجاح|Success comes with patience.
failure|فشل|Failure is part of learning.
chance|فرصة / احتمال|Give it a chance.
opportunity|فرصة|English gives you more opportunities.
challenge|تحدٍّ|Accept the challenge.
` });

window.WORDBANK_RAW.push({ cat: "general", title: "الكتب والقراءة والدراسة", text: `
chapter|فصل (في كتاب)|Read chapter one tonight.
page|صفحة|Turn to page 20.
paragraph|فقرة|The second paragraph explains the idea.
sentence|جملة|Translate this sentence.
title|عنوان|Read the title first.
author|المؤلف|The author is a famous engineer.
article|مقال|I read an article about security.
summary|ملخص|Read the summary at the end.
content|محتوى|The content is very useful.
text|نص|Read the text and answer.
language|لغة|English is the language of technology.
vocabulary|مفردات|Build your vocabulary.
grammar|قواعد اللغة|Grammar helps you understand sentences.
spelling|تهجئة|Check your spelling.
pronunciation|نطق|Listen to the pronunciation.
dictionary|قاموس|Use a dictionary when needed.
translation|ترجمة|Don't depend on translation.
definition|تعريف|Read the definition carefully.
note|ملاحظة|Take notes while reading.
notebook|دفتر|Write new words in your notebook.
library|مكتبة|The library has thousands of books.
novel|رواية|I'm reading an English novel.
magazine|مجلة|This magazine is about technology.
newspaper|صحيفة|Read the newspaper online.
reader|قارئ|You are becoming a good reader.
writer|كاتب|The writer explains things simply.
edition|طبعة / إصدار|This is the second edition.
publish|ينشر|The book was published in 2020.
quote|اقتباس / يقتبس|I like this quote.
review|مراجعة / يراجع|Review the words every day.
lesson|درس|Today's lesson is short.
lecture|محاضرة|Watch the first lecture.
class|صف / حصة|The class starts at nine.
exam|امتحان|I passed the exam.
test|اختبار|Take the test again.
homework|واجب منزلي|Finish your homework.
assignment|مهمة / واجب|Submit the assignment on time.
course|دورة / كورس|This course is for beginners.
subject|موضوع / مادة|Math is my favorite subject.
topic|موضوع|Choose a topic you like.
degree|شهادة جامعية|She has a degree in computer science.
university|جامعة|He studies at the university.
college|كلية|I went to college in Tripoli.
graduate|يتخرج / خريج|She graduated last year.
instructor|مدرب / محاضر|The instructor is very clear.
tutor|معلم خصوصي|A tutor helped me with grammar.
learner|متعلم|This app is for adult learners.
beginner|مبتدئ|This book is for beginners.
advanced|متقدم|This is an advanced topic.
intermediate|متوسط (مستوى)|My level is intermediate.
` });

window.WORDBANK_RAW.push({ cat: "general", title: "التواصل والكلام", text: `
message|رسالة|Send me a message.
conversation|محادثة|We had a long conversation.
discussion|نقاش|Join the discussion.
comment|تعليق|Leave a comment.
reply|رد / يرد|Reply to the email.
response|استجابة / رد|I'm waiting for a response.
request|طلب|Your request was sent.
advice|نصيحة|Thanks for the advice.
suggestion|اقتراح|Do you have any suggestions?
explanation|شرح|The explanation is clear.
description|وصف|Read the product description.
instruction|تعليمات|Follow the instructions.
warning|تحذير|Read the warning carefully.
announcement|إعلان|Read the latest announcement.
news|أخبار|I read the tech news daily.
contact|اتصال / يتواصل|Contact us for more information.
email|بريد إلكتروني|Check your email.
phone|هاتف|My phone is on silent.
voice|صوت|Use your voice to search.
sound|صوت / يبدو|That sounds great.
noise|ضجيج|There is too much noise.
silence|صمت|Study in silence.
speech|خطاب / كلام|He gave a short speech.
talk|يتحدث / حديث|Let's talk about it.
discuss|يناقش|We will discuss this tomorrow.
argue|يجادل|They argued about the price.
claim|يدّعي / ادعاء|The company claims it is safe.
admit|يعترف|He admitted the mistake.
deny|ينكر|She denied the claim.
promise|يعد / وعد|I promise to practice daily.
complain|يشتكي|Users complained about the bug.
apologize|يعتذر|We apologize for the delay.
thank|يشكر|Thank you for your help.
invite|يدعو|Invite your friends.
announce|يعلن|They announced a new product.
inform|يُعلم / يبلغ|We will inform you by email.
notify|يُشعر / ينبّه|Notify me when it's ready.
confirm|يؤكد|Confirm your email address.
respond|يستجيب / يرد|The server did not respond.
express|يعبّر|Express your ideas clearly.
communicate|يتواصل|We communicate in English.
translate|يترجم|Try not to translate every word.
repeat|يكرر|Repeat the word aloud.
pronounce|ينطق|How do you pronounce this word?
spell|يتهجى|How do you spell your name?
mention|يذكر|He mentioned your name.
refer|يشير إلى|This word refers to the server.
introduce|يقدّم / يعرّف|Let me introduce myself.
greet|يحيّي|Greet the new members.
persuade|يقنع|The article tries to persuade the reader.
` });

window.WORDBANK_RAW.push({ cat: "general", title: "المشاعر والحالة", text: `
afraid|خائف|Don't be afraid of mistakes.
fear|خوف|Fear stops many learners.
nervous|متوتر|I was nervous before the test.
confident|واثق|I feel confident now.
confidence|ثقة|Reading builds confidence.
proud|فخور|Be proud of your progress.
excited|متحمس|I'm excited to start.
bored|ملول / ضجِر|I get bored with long videos.
boring|ممل|This lecture is boring.
interesting|مثير للاهتمام|What an interesting idea.
curious|فضولي|Stay curious.
tired|متعب|I'm tired; I'll study tomorrow.
angry|غاضب|The customer was angry.
sad|حزين|It's a sad story.
glad|سعيد / مسرور|I'm glad you liked it.
worried|قلق|I'm worried about the exam.
calm|هادئ|Stay calm and read again.
patient|صبور|Be patient with yourself.
surprised|متفاجئ|I was surprised by the result.
disappointed|محبط / خائب الأمل|I was disappointed with the app.
frustrated|محبط|I felt frustrated at first.
satisfied|راضٍ|Are you satisfied with the course?
comfortable|مرتاح|I feel comfortable reading English now.
relaxed|مسترخٍ|Study when you are relaxed.
stress|ضغط / توتر|Short lessons reduce stress.
pressure|ضغط|Don't put pressure on yourself.
motivation|دافع / حماس|Find your motivation.
motivated|متحفز|I feel motivated today.
energy|طاقة|I have more energy in the morning.
emotion|عاطفة / شعور|Music affects our emotions.
feeling|شعور|I have a good feeling about this.
mood|مزاج|I'm in a good mood.
enjoy|يستمتع|I enjoy reading in English.
hate|يكره|I hate waiting.
prefer|يفضّل|I prefer short lessons.
care|يهتم|We care about your privacy.
trust|يثق / ثقة|Trust the process.
doubt|شك|I have no doubt you will succeed.
hope|أمل|Never lose hope.
wish|يتمنى / أمنية|I wish I started earlier.
dream|حلم|My dream is to work abroad.
pleasure|متعة / سرور|It's a pleasure to help.
pain|ألم|No pain, no gain.
fun|متعة / ممتع|Learning can be fun.
funny|مضحك|That's a funny story.
serious|جاد|Take your studies seriously.
lucky|محظوظ|You are lucky to have a good teacher.
eager|متلهف / متشوق|I'm eager to learn more.
determined|مصمم / عازم|I am determined to finish.
grateful|ممتن|I'm grateful for your support.
` });

window.WORDBANK_RAW.push({ cat: "general", title: "أفعال متقدمة شائعة في الكتب", text: `
achieve|يحقق|You can achieve your goal.
acquire|يكتسب|Acquire new skills.
adapt|يتكيف|Adapt to new situations.
adjust|يعدّل / يضبط|Adjust the volume.
affect|يؤثر على|Sleep affects memory.
analyze|يحلل|Analyze the results.
appreciate|يقدّر|I appreciate your help.
approve|يوافق على|The manager approved the plan.
argue|يجادل|Some experts argue the opposite.
arrange|يرتب|Arrange the words in order.
assume|يفترض|Don't assume; check.
attach|يرفق|Attach the file to the email.
attract|يجذب|The design attracts users.
avoid|يتجنب|Avoid this common mistake.
benefit|يستفيد / فائدة|You will benefit from daily reading.
calculate|يحسب|Calculate the total price.
challenge|يتحدى|Challenge yourself every day.
collect|يجمع|Collect new words while reading.
combine|يدمج|Combine the two files.
commit|يلتزم|Commit to twenty minutes a day.
complete|يكمل|Complete all the exercises.
concern|يقلق / يخص|This change concerns all users.
conclude|يستنتج / يختم|We can conclude that it works.
conduct|يجري / يُجري|They conducted a study.
consist|يتكون (consist of)|The course consists of six stages.
contribute|يساهم|Everyone can contribute.
convince|يقنع|He convinced me to try.
define|يعرّف|Define the problem first.
deliver|يسلّم / يوصل|We deliver results.
demand|يطلب / طلب|There is a high demand for developers.
demonstrate|يوضح / يبرهن|Let me demonstrate.
depend|يعتمد|Success depends on practice.
derive|يشتق|This word is derived from Latin.
design|يصمم|They designed a new logo.
determine|يحدد|Determine the cause.
differ|يختلف|Opinions differ.
distinguish|يميّز|Distinguish between the two words.
divide|يقسّم|Divide the text into parts.
earn|يكسب|Earn points for every lesson.
emerge|يظهر / يبرز|New tools emerge every year.
emphasize|يؤكد على|The author emphasizes practice.
encourage|يشجع|Teachers encourage questions.
establish|يؤسس|The company was established in 2010.
estimate|يقدّر / تقدير|Estimate the time needed.
evaluate|يقيّم|Evaluate your progress weekly.
examine|يفحص|Examine the code carefully.
exist|يوجد|This file does not exist.
expand|يوسّع|Expand your vocabulary.
explore|يستكشف|Explore the menu.
extend|يمدد|Extend your subscription.
` });

window.WORDBANK_RAW.push({ cat: "general", title: "أفعال متقدمة أخرى", text: `
fail|يفشل|The upload failed.
gain|يكسب|Gain experience by practice.
generate|يولّد|Generate a report.
handle|يتعامل مع|Handle errors carefully.
hide|يخفي|Hide the sidebar.
ignore|يتجاهل|Ignore this message.
illustrate|يوضح بالأمثلة|The picture illustrates the idea.
implement|ينفّذ / يطبّق|Implement the new feature.
imply|يُلمح / يعني ضمناً|What does the author imply?
indicate|يشير إلى|A red icon indicates an error.
influence|يؤثر|Ads influence our choices.
inspire|يُلهم|Her story inspired me.
intend|ينوي|I intend to finish this month.
interpret|يفسر|Interpret the results.
investigate|يحقق في|The team is investigating the issue.
justify|يبرر|Justify your answer.
locate|يحدد مكان|Locate the file on your disk.
maintain|يحافظ / يصون|Maintain a daily routine.
modify|يعدّل|Modify the settings.
monitor|يراقب|Monitor your progress.
obtain|يحصل على|Obtain a certificate.
occur|يحدث|An error occurred.
operate|يشغّل / يعمل|Operate the machine safely.
organize|ينظم|Organize your notes.
perform|يؤدي|Perform the steps in order.
predict|يتنبأ|Predict the meaning of the word.
prevent|يمنع|Prevent data loss.
proceed|يتابع / يمضي|Proceed to checkout.
promote|يروّج / يرقّي|They promoted her to manager.
protect|يحمي|Protect your account.
publish|ينشر|Publish your work.
pursue|يسعى إلى|Pursue your dreams.
recommend|يوصي|I recommend this book.
recover|يستعيد / يتعافى|Recover your password.
reflect|يعكس / يتأمل|Reflect on what you learned.
refuse|يرفض|He refused the offer.
reject|يرفض|The request was rejected.
release|يطلق / يُصدر|They released a new version.
rely|يعتمد (rely on)|Don't rely only on translation.
remove|يزيل|Remove the old files.
replace|يستبدل|Replace the old battery.
require|يتطلب|This requires more practice.
resolve|يحل|The issue was resolved.
reveal|يكشف|The report reveals the truth.
satisfy|يُرضي|The answer did not satisfy him.
select|يختار|Select all that apply.
seek|يبحث عن|Seek help when needed.
store|يخزّن|Store your files in the cloud.
struggle|يكافح / يعاني|Many learners struggle with grammar.
transform|يحوّل|Reading transformed my career.
` });
