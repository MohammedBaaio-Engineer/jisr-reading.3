/* جسر القراءة — منطق الموقع */
(function () {
  "use strict";

  /* ---------------- أدوات عامة ---------------- */
  const $ = (s, r) => (r || document).querySelector(s);
  const esc = (s) => String(s == null ? "" : s).replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
  const DAY = 86400000;
  const todayKey = () => { const d = new Date(); return d.getFullYear() + "-" + (d.getMonth() + 1) + "-" + d.getDate(); };
  const splitSentences = (t) => (String(t).match(/[^.!?]+(?:[.!?]+|$)/g) || [String(t)]).map((x) => x.trim()).filter(Boolean);
  const ICON = {
    say: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M11 5 6 9H2v6h4l5 4V5z"/><path d="M15.5 8.5a5 5 0 0 1 0 7M19 5a10 10 0 0 1 0 14"/></svg>',
    lock: '<svg class="lock" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><rect x="4" y="11" width="16" height="10" rx="2"/><path d="M8 11V7a4 4 0 0 1 8 0v4"/></svg>',
    tr: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M4 5h8M8 3v2M10 5c-.5 4-3 7-6 8M6 9c1 2 3 3.5 5 4"/><path d="m13 21 4-9 4 9M14.5 18h5"/></svg>'
  };

  /* ---------------- القاموس الموحد ---------------- */
  const GLOSS = Object.assign({}, window.BASE_DICT);
  const PHRASES = [];
  window.LESSONS.forEach((l) => l.vocab.forEach(([en, ar]) => {
    const k = en.toLowerCase();
    GLOSS[k] = ar;
    if (k.includes(" ")) PHRASES.push([k, ar]);
  }));
  PHRASES.sort((a, b) => b[0].length - a[0].length);

  function lemmaCandidates(w) {
    const c = [w];
    const add = (x) => { if (x && x.length > 1 && !c.includes(x)) c.push(x); };
    if (w.endsWith("'s") || w.endsWith("’s")) add(w.slice(0, -2));
    if (w.endsWith("ies")) add(w.slice(0, -3) + "y");
    if (w.endsWith("es")) add(w.slice(0, -2));
    if (w.endsWith("s")) add(w.slice(0, -1));
    if (w.endsWith("ied")) add(w.slice(0, -3) + "y");
    if (w.endsWith("ed")) { add(w.slice(0, -2)); add(w.slice(0, -1)); const b = w.slice(0, -2); if (/(.)\1$/.test(b)) add(b.slice(0, -1)); }
    if (w.endsWith("ing")) { const b = w.slice(0, -3); add(b); add(b + "e"); if (/(.)\1$/.test(b)) add(b.slice(0, -1)); }
    if (w.endsWith("ly")) { add(w.slice(0, -2)); if (w.endsWith("ily")) add(w.slice(0, -3) + "y"); }
    if (w.endsWith("er")) { add(w.slice(0, -2)); add(w.slice(0, -1)); }
    if (w.endsWith("est")) add(w.slice(0, -3));
    if (w.endsWith("ment")) add(w.slice(0, -4));
    if (w.endsWith("tion")) add(w.slice(0, -3) + "e");
    return c;
  }
  function lookup(word) {
    const w = word.toLowerCase().replace(/^[^a-z]+|[^a-z']+$/g, "");
    for (const c of lemmaCandidates(w)) {
      if (GLOSS[c]) return { base: c, ar: GLOSS[c], exact: c === w };
      const cached = state.ai[c];
      if (cached) return { base: c, ar: cached, exact: c === w, ai: true };
    }
    return { base: w, ar: null };
  }

  /* ---------------- الحالة والحفظ ---------------- */
  const LS_KEY = "jisr-state-v1";
  const fresh = () => ({ v: 1, xp: 0, done: {}, sims: {}, cards: {}, streak: { count: 0, last: "" }, today: { d: "", xp: 0, nw: 0 }, unlockAll: false, rate: 0.9, goal: 40, newGoal: 20, autoSpeak: false, units: {}, tests: {}, name: "", notif: { on: true, every: 3, start: 9, end: 22 }, ai: {}, updatedAt: 0 });
  let state = fresh();
  try { const raw = localStorage.getItem(LS_KEY); if (raw) state = Object.assign(fresh(), JSON.parse(raw)); } catch (e) { /* التخزين غير متاح */ }

  let cloud = { ref: null, ready: false, saving: false, dirty: false, timer: null };

  function save() {
    state.updatedAt = Date.now();
    try { localStorage.setItem(LS_KEY, JSON.stringify(state)); } catch (e) { /* تجاهل */ }
    if (cloud.ready) {
      clearTimeout(cloud.timer);
      cloud.timer = setTimeout(pushCloud, 1500);
    }
  }
  async function pushCloud() {
    if (!cloud.ref) return;
    if (cloud.saving) { cloud.dirty = true; return; }
    cloud.saving = true;
    try { await cloud.ref.set({ state: JSON.parse(JSON.stringify(state)) }); setSync(true); }
    catch (e) { if (e && e.code === "invalid_argument") { cloud.ready = false; setSync(false); } }
    cloud.saving = false;
    if (cloud.dirty) { cloud.dirty = false; pushCloud(); }
  }
  function merge(a, b) {
    const m = Object.assign(fresh(), a);
    m.xp = Math.max(a.xp || 0, b.xp || 0);
    m.done = Object.assign({}, b.done, a.done);
    for (const k in b.done || {}) if (a.done && a.done[k] && b.done[k].score > a.done[k].score) m.done[k] = b.done[k];
    m.sims = Object.assign({}, b.sims, a.sims);
    for (const k in b.sims || {}) if (a.sims && a.sims[k] && b.sims[k].score > a.sims[k].score) m.sims[k] = b.sims[k];
    m.cards = Object.assign({}, b.cards);
    for (const k in a.cards || {}) { const x = a.cards[k], y = b.cards && b.cards[k]; if (!y || (x.rt || 0) >= (y.rt || 0)) m.cards[k] = x; }
    m.ai = Object.assign({}, b.ai, a.ai);
    const sa = a.streak || {}, sb = b.streak || {};
    m.streak = (sb.last && (!sa.last || new Date(sb.last) > new Date(sa.last))) ? sb : sa;
    m.today = ((b.today || {}).d === todayKey() && (b.today.xp || 0) > ((a.today || {}).xp || 0)) ? b.today : a.today;
    const newer = (a.updatedAt || 0) >= (b.updatedAt || 0) ? a : b;
    m.unlockAll = newer.unlockAll; m.rate = newer.rate; m.goal = newer.goal;
    m.newGoal = newer.newGoal || 20; m.autoSpeak = !!newer.autoSpeak; m.notif = newer.notif || m.notif; m.name = newer.name || a.name || b.name || "";
    m.units = Object.assign({}, b.units, a.units);
    m.tests = Object.assign({}, b.tests, a.tests);
    for (const k in b.tests || {}) if (!(a.tests && a.tests[k] && a.tests[k].passed) && b.tests[k].passed) m.tests[k] = b.tests[k];
    for (const k in b.units || {}) if (a.units && a.units[k] && b.units[k].score > a.units[k].score) m.units[k] = b.units[k];
    return m;
  }
  async function initCloud() {
    if (!window.claude || typeof window.claude.use !== "function") return;
    try {
      const [user, db] = await Promise.all([window.claude.use("user"), window.claude.use("db")]);
      if (!user || !db) return;
      const id = await user.id();
      if (!id) return;
      cloud.ref = db.doc("data/users/" + id + "/progress");
      let timedOut = false;
      const t = setTimeout(() => { timedOut = true; }, 10000);
      const snap = await cloud.ref.get();
      clearTimeout(t);
      if (timedOut) return;
      const remote = snap.exists ? (snap.data() || {}).state : null;
      if (remote && typeof remote === "object") {
        state = merge(state, remote);
        try { localStorage.setItem(LS_KEY, JSON.stringify(state)); } catch (e) { /* تجاهل */ }
        softRefresh();
      }
      cloud.ready = true;
      setSync(true);
      pushCloud();
    } catch (e) { setSync(false); }
  }
  function setSync(on) {
    const el = $("#set-sync"), tx = $("#set-sync-text");
    if (!el) return;
    el.classList.toggle("cloud", !!on);
    tx.textContent = on ? "على حسابك: يتزامن بين الجوال واللابتوب" : "على هذا المتصفح فقط";
  }

  /* ---------------- النقاط والمستويات ---------------- */
  const LEVELS = [
    [0, "متردد"], [100, "مستكشف"], [300, "قارئ مبتدئ"], [700, "قارئ واثق"], [1300, "قارئ تقني"],
    [2200, "متابع كورسات"], [3500, "قارئ توثيق"], [5000, "محترف القراءة"], [7000, "جسر مكتمل"]
  ];
  function levelInfo(xp) {
    let i = 0; while (i < LEVELS.length - 1 && xp >= LEVELS[i + 1][0]) i++;
    const cur = LEVELS[i][0], nxt = LEVELS[i + 1] ? LEVELS[i + 1][0] : cur;
    return { n: i + 1, name: LEVELS[i][1], cur, nxt, pct: nxt > cur ? Math.round(((xp - cur) / (nxt - cur)) * 100) : 100, last: !LEVELS[i + 1] };
  }
  function addXP(n, why) {
    const before = levelInfo(state.xp).n;
    state.xp += n;
    const tk = todayKey();
    if (state.today.d !== tk) state.today = { d: tk, xp: 0 };
    state.today.xp += n;
    if (state.streak.last !== tk) {
      const y = new Date(Date.now() - DAY);
      const yk = y.getFullYear() + "-" + (y.getMonth() + 1) + "-" + y.getDate();
      state.streak.count = state.streak.last === yk ? state.streak.count + 1 : 1;
      state.streak.last = tk;
    }
    save(); renderHeader();
    const after = levelInfo(state.xp);
    if (after.n > before) toast("مستوى جديد: " + after.name);
    else if (why) toast("+" + n + " XP · " + why);
  }
  function streakNow() {
    if (!state.streak.last) return 0;
    const tk = todayKey();
    const y = new Date(Date.now() - DAY); const yk = y.getFullYear() + "-" + (y.getMonth() + 1) + "-" + y.getDate();
    return (state.streak.last === tk || state.streak.last === yk) ? state.streak.count : 0;
  }

  /* ---------------- البطاقات (تكرار متباعد) ---------------- */
  const INTERVALS = [0, 1, 2, 4, 8, 16, 32]; // أيام لكل صندوق
  function addCard(en, ar, ex, silent) {
    const k = en.toLowerCase().trim();
    if (!k || !ar) return false;
    if (state.cards[k]) { if (!silent) toast("الكلمة موجودة في المراجعة"); return false; }
    if (Object.keys(state.cards).length >= 1500) { toast("وصلت للحد الأقصى 1500 بطاقة"); return false; }
    state.cards[k] = { en: en.trim(), ar: ar, ex: ex ? String(ex).slice(0, 220) : "", box: 0, due: Date.now(), rt: Date.now() };
    save();
    if (!silent) toast("أُضيفت للمراجعة");
    renderHeader();
    return true;
  }
  const dueCards = () => Object.values(state.cards).filter((c) => c.due <= Date.now()).sort((a, b) => a.due - b.due);

  /* ---------------- النطق ---------------- */
  let voice = null;
  function pickVoice() {
    try {
      const vs = speechSynthesis.getVoices();
      voice = vs.find((v) => /en[-_]US/i.test(v.lang) && /natural|google|samantha|aria|jenny/i.test(v.name)) || vs.find((v) => /en[-_](US|GB)/i.test(v.lang)) || vs.find((v) => /^en/i.test(v.lang)) || null;
    } catch (e) { voice = null; }
  }
  const canSpeak = (() => { try { return "speechSynthesis" in window && typeof SpeechSynthesisUtterance === "function"; } catch (e) { return false; } })();
  if (canSpeak) { pickVoice(); try { speechSynthesis.onvoiceschanged = pickVoice; } catch (e) { /* تجاهل */ } }
  function speak(text) {
    if (!canSpeak) { toast("النطق غير مدعوم في هذا المتصفح"); return; }
    try {
      speechSynthesis.cancel();
      const u = new SpeechSynthesisUtterance(text);
      u.lang = "en-US"; u.rate = Number(state.rate) || 0.9;
      if (voice) u.voice = voice;
      speechSynthesis.speak(u);
    } catch (e) { toast("تعذر تشغيل الصوت"); }
  }
  const sayBtn = (text, label) => `<button class="say" type="button" data-say="${esc(text)}" aria-label="${esc(label || "استمع")}">${ICON.say}</button>`;

  /* ---------------- Claude (اختياري) ---------------- */
  let sampleFn = null;
  async function initSample() {
    if (!window.claude || typeof window.claude.use !== "function") return;
    try { sampleFn = await window.claude.use("sample"); } catch (e) { sampleFn = null; }
    if (sampleFn) { document.body.classList.add("has-ai"); const h = location.hash.slice(1); if (h === "analyzer") route(); }
  }
  let aiBusy = false, aiBlockedUntil = 0;
  async function askClaude(prompt, tier) {
    if (!sampleFn) throw { code: "none", message: "غير متاح" };
    if (Date.now() < aiBlockedUntil) throw { code: "rate_limited", message: "انتظر قليلاً" };
    aiBusy = true;
    try {
      const r = await sampleFn(prompt, { modelTier: tier || "quick" });
      const t = (r && r.text) || "";
      const a = t.indexOf("{"), b = t.lastIndexOf("}");
      if (a < 0 || b < a) throw { code: "parse", message: "رد غير مفهوم" };
      return JSON.parse(t.slice(a, b + 1));
    } catch (e) {
      if (e && e.code === "rate_limited") aiBlockedUntil = Date.now() + 30000;
      if (e && e.code === "not_granted") { sampleFn = null; document.body.classList.remove("has-ai"); }
      throw e;
    } finally { aiBusy = false; }
  }
  function aiErrorText(e) {
    const c = e && e.code;
    if (c === "rate_limited") return "طلبات كثيرة متتالية. انتظر نصف دقيقة ثم جرّب مجدداً.";
    if (c === "not_granted") return "لم تُمنح الصلاحية لاستخدام Claude في هذه الصفحة.";
    if (c === "parse") return "وصل رد غير مكتمل. جرّب مرة أخرى.";
    return "تعذر الوصول إلى Claude الآن. جرّب بعد قليل.";
  }

  /* ---------------- القارئ الذكي: تحويل النص لكلمات قابلة للضغط ---------------- */
  const WORD_RE = /[A-Za-z][A-Za-z'’-]*[A-Za-z]|[A-Za-z]/g;
  function makeReadable(root) {
    const walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT, {
      acceptNode(n) {
        if (!n.nodeValue || !/[A-Za-z]/.test(n.nodeValue)) return NodeFilter.FILTER_REJECT;
        const p = n.parentElement;
        if (!p || p.closest(".no-read, button, input, textarea, select, .w")) return NodeFilter.FILTER_REJECT;
        return NodeFilter.FILTER_ACCEPT;
      }
    });
    const nodes = []; let n; while ((n = walker.nextNode())) nodes.push(n);
    nodes.forEach((node) => {
      const text = node.nodeValue; const frag = document.createDocumentFragment();
      let last = 0; WORD_RE.lastIndex = 0; let m;
      while ((m = WORD_RE.exec(text))) {
        if (m.index > last) frag.appendChild(document.createTextNode(text.slice(last, m.index)));
        const s = document.createElement("span"); s.className = "w"; s.textContent = m[0];
        if (state.cards[m[0].toLowerCase()]) s.classList.add("known");
        frag.appendChild(s); last = m.index + m[0].length;
      }
      if (last < text.length) frag.appendChild(document.createTextNode(text.slice(last)));
      node.parentNode.replaceChild(frag, node);
    });
  }
  function sentenceOf(span) {
    const block = span.closest(".en-p, .en-s, .en-line, p, li, td, dd, pre, label, h3, h4, div") || span.parentElement;
    const full = (block.textContent || "").replace(/\s+/g, " ").trim();
    const word = span.textContent;
    const parts = splitSentences(full);
    return (parts.find((s) => s.includes(word)) || full).slice(0, 300);
  }

  let sheetState = null, selSpan = null;
  function openSheet(span) {
    if (selSpan) selSpan.classList.remove("sel");
    selSpan = span; span.classList.add("sel");
    const word = span.textContent;
    const ctx = sentenceOf(span);
    const r = lookup(word);
    const low = ctx.toLowerCase();
    const ph = PHRASES.find(([p]) => p.split(" ").includes(r.base) || p.split(" ").includes(word.toLowerCase()) ? low.includes(p) : false);
    sheetState = { word, base: r.base, ar: r.ar, ctx, phrase: ph || null };
    $("#sh-word").textContent = word;
    $("#sh-say").innerHTML = ICON.say;
    $("#sh-mean").textContent = r.ar || "ليست في القاموس المدمج بعد";
    $("#sh-mean").style.color = r.ar ? "" : "var(--muted)";
    $("#sh-base").textContent = r.ar && !r.exact ? "أصل الكلمة: " + r.base : (r.ai ? "شرحها Claude سابقاً" : "");
    const pe = $("#sh-phrase");
    if (ph) { pe.hidden = false; pe.innerHTML = 'ضمن عبارة: <b dir="ltr" class="en">' + esc(ph[0]) + "</b> = " + esc(ph[1]); } else pe.hidden = true;
    const ce = $("#sh-ctx"); ce.hidden = false; ce.textContent = ctx;
    $("#sh-ai").hidden = true;
    $("#sh-add").disabled = false;
    $("#sh-add").textContent = state.cards[(ph ? ph[0] : r.base)] ? "موجودة في المراجعة" : "أضف للمراجعة";
    $("#sh-ask").hidden = !sampleFn;
    $("#sh-ask").textContent = r.ar ? "اشرحها في سياقها" : "اسأل Claude عن معناها";
    $("#sheet").classList.add("open");
    speakIfAuto(word);
  }
  function speakIfAuto() { /* النطق بالضغط على الزر فقط حتى لا يزعجك */ }
  function closeSheet() { $("#sheet").classList.remove("open"); if (selSpan) selSpan.classList.remove("sel"); selSpan = null; }

  $("#sh-close").addEventListener("click", closeSheet);
  $("#sh-say").addEventListener("click", () => sheetState && speak(sheetState.word));
  $("#sh-add").addEventListener("click", () => {
    if (!sheetState) return;
    const s = sheetState;
    const en = s.phrase ? s.phrase[0] : s.base;
    const ar = s.phrase ? s.phrase[1] : s.ar;
    if (!ar) { toast(sampleFn ? "اسأل Claude عن المعنى أولاً" : "لا يوجد معنى لهذه الكلمة في القاموس"); return; }
    if (addCard(en, ar, s.ctx)) { addXP(1); if (selSpan) selSpan.classList.add("known"); $("#sh-add").textContent = "موجودة في المراجعة"; }
  });
  $("#sh-ask").addEventListener("click", async () => {
    if (!sheetState || aiBusy) return;
    const s = sheetState; const box = $("#sh-ai");
    box.hidden = false; box.className = "notice"; box.innerHTML = '<span class="spinner"></span> يفكر Claude في معنى الكلمة داخل الجملة...';
    try {
      const out = await askClaude(
        "You help an Arabic-speaking learner read technical English. Explain the English word in its sentence.\n" +
        "Word: " + s.word + "\nSentence: " + s.ctx + "\n" +
        'Reply ONLY with JSON: {"meaning":"short Arabic meaning in this context (2-5 words)","base":"dictionary form in English","note":"one short Arabic sentence explaining the usage here"}'
      );
      if (out && out.meaning) {
        const base = String(out.base || s.base).toLowerCase().trim();
        state.ai[base] = String(out.meaning).slice(0, 80);
        const keys = Object.keys(state.ai); if (keys.length > 400) delete state.ai[keys[0]];
        save();
        s.ar = state.ai[base]; s.base = base;
        $("#sh-mean").textContent = s.ar; $("#sh-mean").style.color = "";
        box.textContent = out.note || "";
        if (!out.note) box.hidden = true;
      } else throw { code: "parse" };
    } catch (e) { box.className = "notice err"; box.textContent = aiErrorText(e); }
  });

  document.addEventListener("click", (e) => {
    const w = e.target.closest(".w");
    if (w) { openSheet(w); return; }
    const sb = e.target.closest("[data-say]");
    if (sb) { speak(sb.getAttribute("data-say")); return; }
    if ($("#sheet").classList.contains("open") && !e.target.closest("#sheet")) closeSheet();
  });
  document.addEventListener("keydown", (e) => { if (e.key === "Escape") { closeSheet(); closeSettings(); } });

  /* ---------------- إشعار صغير ---------------- */
  let toastT;
  function toast(msg) { const t = $("#toast"); t.textContent = msg; t.classList.add("show"); clearTimeout(toastT); toastT = setTimeout(() => t.classList.remove("show"), 2200); }

  /* ================= بنك المفردات والوحدات ================= */
  const WORDS = []; const WORD_BY = {};
  const UNITS = [];
  (function buildBank() {
    const seen = new Set();
    const perTrack = { general: 0, tech: 0 };
    (window.WORDBANK_RAW || []).forEach((g) => {
      const items = [];
      g.text.trim().split("\n").forEach((line) => {
        const p = line.split("|"); if (p.length !== 3) return;
        const en = p[0].trim(), k = en.toLowerCase();
        if (!en || seen.has(k)) return; seen.add(k);
        const w = { en, ar: p[1].trim(), ex: p[2].trim(), cat: g.cat };
        WORDS.push(w); WORD_BY[k] = w; items.push(w);
      });
      if (!items.length) return;
      const parts = Math.max(1, Math.round(items.length / 18));
      const size = Math.ceil(items.length / parts);
      for (let i = 0; i < parts; i++) {
        const words = items.slice(i * size, i * size + size);
        if (!words.length) continue;
        perTrack[g.cat]++;
        UNITS.push({ id: (g.cat === "tech" ? "t" : "v") + perTrack[g.cat], cat: g.cat, group: g.title, title: g.title + (parts > 1 ? " · الجزء " + (i + 1) : ""), words });
      }
    });
    WORDS.forEach((w) => { const k = w.en.toLowerCase(); if (!GLOSS[k]) GLOSS[k] = w.ar; if (k.includes(" ")) PHRASES.push([k, w.ar]); });
    PHRASES.sort((a, b) => b[0].length - a[0].length);
  })();
  /* ================= المسار الموحد: درس ← كلمات ← ... ← اختبار المرحلة ← تحدي ================= */
  const PATH_MAP = {
    l1: ["أفعال لا يخلو منها نص"],
    l2: ["واجهات البرامج والأجهزة"],
    l3: ["الكتب والقراءة والدراسة"],
    l4: ["أفعال يومية شائعة"],
    g1: ["أسماء يومية أساسية"],
    g2: ["أشياء وأماكن من حولنا"],
    l5: ["الزمن والتكرار"],
    l6: ["الملفات والإعدادات"],
    l7: ["أسماء الناس والمجتمع"],
    g3: ["أفعال الفهم والتفكير"],
    g4: ["الصفات الأكثر استخداماً"],
    l8: ["أضداد مفيدة للقراءة", "الكميات والأرقام والقياس"],
    l9: ["ظروف وكلمات توجيه الجملة"],
    g5: ["أدوات الربط والعلاقات"],
    l10: ["صفات للوصف والحكم"],
    g6: ["الأفعال المركبة الأكثر شيوعاً"],
    l11: ["رسائل الأخطاء والتحذيرات"],
    l12: ["أساسيات البرمجة", "البرمجة: التنفيذ والأخطاء"],
    l13: ["التواصل والكلام"],
    l14: ["أدوات المطور والعمل الجماعي", "الويب وقواعد البيانات"],
    l15: ["الشبكات: المكونات", "الشبكات: البروتوكولات والعناوين"],
    l16: ["أمن المعلومات: المفاهيم", "الأفكار والتفكير"],
    l17: ["أمن المعلومات: الهجمات والأدوات"],
    l18: ["لغة الكورسات والمنصات التعليمية", "العمل والحياة المهنية"],
    l19: ["المشاعر والحالة"],
    l20: ["أفعال متقدمة شائعة في الكتب"],
    l21: ["العلم والطبيعة والصحة", "أسماء مجردة شائعة"],
    l22: ["كلمات المقالات والتقارير", "أسماء مجردة أخرى"],
    l23: ["أفعال متقدمة أخرى", "تعابير تتكرر في الكتب والمقالات"],
    x1: ["لينكس وأنظمة التشغيل"],
    x2: ["السحابة والبنية التحتية"],
    x3: ["البيانات والذكاء الاصطناعي", "أفعال القراءة الأكاديمية"],
    x4: ["كلمات الكتب التقنية والأكاديمية", "تطوير التطبيقات والجوال", "كلمات القصص والحياة"]
  };
  const PATH = []; const STAGE_WORDS = {}; const PIDX = {};
  (function buildPath() {
    const mapped = new Set();
    Object.values(PATH_MAP).forEach((gs) => gs.forEach((g) => mapped.add(g)));
    const orphans = UNITS.filter((u) => !mapped.has(u.group));
    const stages = window.STAGES;
    stages.forEach((st, si) => {
      const words = [];
      const addUnit = (u) => { u.stage = st.id; PATH.push({ type: "unit", id: u.id, stage: st.id }); words.push(...u.words); };
      window.LESSONS.filter((l) => l.stage === st.id).forEach((l) => {
        PATH.push({ type: "lesson", id: l.id, stage: st.id });
        (PATH_MAP[l.id] || []).forEach((g) => UNITS.filter((u) => u.group === g).forEach(addUnit));
      });
      if (si === stages.length - 1) orphans.forEach(addUnit);
      if (words.length) { PATH.push({ type: "test", id: "test-" + st.id, stage: st.id }); STAGE_WORDS[st.id] = words; }
      window.SIMS.filter((s) => s.stage === st.id).forEach((s) => PATH.push({ type: "sim", id: s.id, stage: st.id }));
    });
    PATH.forEach((it, i) => { PIDX[it.type + ":" + it.id] = i; it.n = i + 1; });
  })();
  function itemDone(it) {
    if (it.type === "lesson") return !!state.done[it.id];
    if (it.type === "unit") return !!state.units[it.id];
    if (it.type === "test") return !!(state.tests && state.tests[it.id] && state.tests[it.id].passed);
    return !!state.sims[it.id];
  }
  function pathUnlocked(type, id) {
    const i = PIDX[type + ":" + id];
    if (i == null) return true;
    return state.unlockAll || i === 0 || itemDone(PATH[i]) || itemDone(PATH[i - 1]);
  }
  const nextStep = () => PATH.find((it) => !itemDone(it)) || null;
  const pathDoneCount = () => PATH.filter(itemDone).length;
  const pathComplete = () => PATH.every(itemDone);
  function stepHref(it) { return it.type === "lesson" ? "#lesson-" + it.id : it.type === "unit" ? "#unit-" + it.id : it.type === "test" ? "#" + it.id : "#sim-" + it.id; }
  const STEP_KIND = { lesson: "درس", unit: "كلمات", test: "اختبار المرحلة", sim: "تحدي المرحلة" };
  function stepTitle(it) {
    if (it.type === "lesson") return window.LESSONS.find((l) => l.id === it.id).title;
    if (it.type === "unit") return UNITS.find((u) => u.id === it.id).title;
    if (it.type === "test") return "اختبار كلمات المرحلة " + window.STAGES.find((s) => s.id === it.stage).n;
    return window.SIMS.find((s) => s.id === it.id).title;
  }
  function nextStepButton(cls) {
    const ns = nextStep();
    if (!ns) return `<a class="btn ${cls || "pri"}" href="#cert">اعرض شهادتك</a>`;
    return `<a class="btn ${cls || "pri"}" href="${stepHref(ns)}">الخطوة التالية: ${STEP_KIND[ns.type]}</a>`;
  }
  function unitUnlocked(u) { return pathUnlocked("unit", u.id); }
  const learnedCount = () => Object.keys(state.cards).length;
  const masteredCount = () => Object.values(state.cards).filter((c) => c.box >= 3).length;
  function nextUnit() {
    const it = PATH.find((x) => x.type === "unit" && !itemDone(x));
    return it ? UNITS.find((u) => u.id === it.id) : null;
  }
  function todayNew() { return state.today.d === todayKey() ? (state.today.nw || 0) : 0; }

  /* كلمة اللحظة: من أضعف الكلمات المحفوظة، أو من الوحدة القادمة */
  function wordOfMoment() {
    const cards = Object.values(state.cards);
    if (cards.length) {
      const weak = cards.slice().sort((a, b) => a.box - b.box || a.due - b.due).slice(0, 25);
      const c = weak[Math.floor(Math.random() * weak.length)];
      const w = WORD_BY[c.en.toLowerCase()];
      return { en: c.en, ar: c.ar, ex: c.ex || (w ? w.ex : "") };
    }
    const u = nextUnit() || UNITS[0];
    return u.words[Math.floor(Math.random() * u.words.length)];
  }
  const CHEERS = [
    "كل كلمة تحفظها اليوم ستقابلك غداً في كورس أو مقال.",
    "أول 2000 كلمة شائعة تغطي قرابة 80% من أي نص عادي.",
    "لا تحتاج أن تفهم كل كلمة. افهم الفكرة وأكمل.",
    "10 دقائق كل يوم أقوى من ساعتين مرة في الأسبوع.",
    "الخطأ في الاختبار جزء من التعلم، والمراجعة تثبّت الكلمة.",
    "اقرأ بصوت مسموع أحياناً، فالأذن تساعد الذاكرة.",
    "الكلمة التي تراها في جملة تبقى في الذاكرة أطول من الكلمة الوحيدة."
  ];

  /* ---- دفتر الكلمات: إحصاءات وبحث في البنك كله ---- */
  let wordQuery = "";
  function viewWords() {
    const total = WORDS.length;
    const learned = learnedCount(), mastered = masteredCount();
    const goal = Number(state.newGoal) || 20;
    const nu = nextUnit();
    app.innerHTML = `<div class="section-title"><h2>الكلمات</h2><span>${total} كلمة عامة وتقنية موزعة على المسار في ${UNITS.length} وحدة</span></div>
    <section class="dash">
      <div class="card">
        <div class="stats3">
          <div class="stat"><b>${learned}</b><span>كلمة تعلمتها</span></div>
          <div class="stat"><b>${mastered}</b><span>كلمة ثابتة في ذاكرتك</span></div>
          <div class="stat"><b>${Math.round((learned / total) * 100)}%</b><span>من بنك المفردات</span></div>
        </div>
        <div style="margin-top:14px"><div class="row" style="justify-content:space-between;font-size:13.5px"><span>كلمات جديدة اليوم</span><span class="muted" style="font-variant-numeric:tabular-nums">${Math.min(todayNew(), goal)} / ${goal}</span></div>
        <div class="bar gold"><i style="width:${Math.min(100, Math.round((todayNew() / goal) * 100))}%"></i></div></div>
        <p class="muted" style="font-size:13px;margin-top:10px">وحدات الكلمات تأتي في المسار بعد كل درس. "ثابتة" تعني أنك تذكرتها في المراجعة عدة مرات متباعدة.</p>
      </div>
      <div class="card next-card">
        ${nu ? `<div><div class="kicker">وحدة الكلمات القادمة في مسارك</div><h3>${esc(nu.title)}</h3><p class="muted" style="font-size:14px" dir="ltr">${nu.words.slice(0, 5).map((w) => esc(w.en)).join(" · ")} ...</p></div>
          ${unitUnlocked(nu) ? `<a class="btn pri" href="#unit-${nu.id}">ابدأ الوحدة</a>` : nextStepButton()}` : `<div><h3>أنهيت كل وحدات الكلمات</h3><p class="muted">استمر في المراجعة اليومية حتى تثبت كل الكلمات.</p></div>`}
        ${dueCards().length ? `<a class="btn" href="#review">راجع ${dueCards().length} كلمة مستحقة</a>` : ""}
      </div>
    </section>
    <section class="card" style="display:grid;gap:12px">
      <label for="w-q" style="font-weight:600">ابحث في بنك الكلمات</label>
      <input id="w-q" class="txt" type="search" placeholder="اكتب كلمة إنجليزية أو معنى عربياً" value="${esc(wordQuery)}" autocomplete="off">
      <div id="w-res"></div>
    </section>`;
    const inp = $("#w-q");
    const draw = () => {
      const q = wordQuery.trim().toLowerCase();
      let list, head;
      if (!q) { list = nu ? nu.words : WORDS.slice(0, 20); head = nu ? "كلمات وحدتك القادمة" : "أول كلمات البنك"; }
      else { list = WORDS.filter((w) => w.en.toLowerCase().includes(q) || w.ar.includes(wordQuery.trim())).slice(0, 60); head = list.length ? list.length + (list.length === 60 ? "+" : "") + " نتيجة" : "لا توجد نتائج"; }
      $("#w-res").innerHTML = `<div class="muted" style="font-size:13px;margin-bottom:6px">${esc(head)}</div><div class="wlist">${list.map((w) => {
        const known = state.cards[w.en.toLowerCase()];
        const u = UNITS.find((x) => x.words.includes(w));
        const st = u && u.stage ? window.STAGES.find((s) => s.id === u.stage) : null;
        return `<div class="wrow"><div class="wbody"><div class="row" style="gap:8px"><b class="wen" dir="ltr">${esc(w.en)}</b>${sayBtn(w.en)}<span class="war">${esc(w.ar)}</span></div><div class="wex" dir="ltr">${esc(w.ex)}</div></div>
          <span class="chip ${known ? "" : "gold"}" style="align-self:center">${known ? "في مراجعتك" : st ? "المرحلة " + st.n : "قريباً"}</span></div>`;
      }).join("")}</div>`;
      $("#w-res").querySelectorAll(".wex").forEach(makeReadable);
    };
    let t; inp.addEventListener("input", () => { wordQuery = inp.value; clearTimeout(t); t = setTimeout(draw, 150); });
    draw();
  }

  /* ---- اختبار كلمات المرحلة ---- */
  function viewTest(id) {
    const sid = id.replace(/^test-/, "");
    const st = window.STAGES.find((s) => s.id === sid);
    const words = STAGE_WORDS[sid];
    if (!st || !words) return viewPath();
    if (!pathUnlocked("test", id)) { toast("أكمل خطوات المرحلة أولاً"); location.hash = "path"; return; }
    const prev = state.tests && state.tests[id];
    app.innerHTML = `<div class="crumbs"><a href="#path">المسار</a><span>›</span><span>المرحلة ${st.n}: ${esc(st.title)}</span></div>
    <section class="card lesson-head"><span class="chip gold">اختبار المرحلة</span><h1>اختبار كلمات المرحلة ${st.n}</h1>
      <p class="muted" style="margin-top:6px">20 سؤالاً عشوائياً من ${words.length} كلمة تعلمتها في هذه المرحلة. تنجح بـ 14 إجابة صحيحة أو أكثر، وكل كلمة تخطئ فيها تعود إلى مراجعتك فوراً.</p>
      ${prev ? `<p style="margin-top:8px">أفضل نتيجة لك: <b>${prev.score}/${prev.total}</b> ${prev.passed ? "· ناجح" : ""}</p>` : ""}
      <div class="row" style="margin-top:12px"><button class="btn pri" type="button" id="t-start">ابدأ الاختبار</button></div>
    </section>
    <section class="card" id="t-sec" hidden><div id="quiz"></div></section>`;
    $("#t-start").addEventListener("click", () => { $("#t-sec").hidden = false; $("#t-start").disabled = true; runStageTest(id, words); $("#t-sec").scrollIntoView({ behavior: "smooth", block: "start" }); });
  }
  function runStageTest(id, words) {
    const root = $("#quiz");
    const picks = shuffle(words.slice()).slice(0, 20);
    let i = 0, score = 0; const missed = [];
    const draw = () => {
      if (i >= picks.length) return finish();
      const w = picks[i];
      const q = buildWordQuestion(w, i % 3, words);
      root.innerHTML = `<div class="quiz"><div class="q-count">سؤال ${i + 1} من ${picks.length} · صحيح ${score}</div>${q.prompt}<div class="opts">${q.optsHtml}</div><div id="why"></div></div>`;
      root.querySelectorAll(".opt").forEach((b) => b.addEventListener("click", () => {
        const ok = q.opts[Number(b.dataset.j)] === w;
        if (ok) score++; else missed.push(w);
        root.querySelectorAll(".opt").forEach((x) => { x.disabled = true; const o = q.opts[Number(x.dataset.j)]; if (o === w) x.classList.add("right"); else if (x === b) x.classList.add("wrong"); });
        const wy = root.querySelector("#why");
        wy.innerHTML = `<div class="why ${ok ? "ok" : "no"}"><b>${ok ? "صحيح" : "ستعود إلى مراجعتك"}</b><span dir="ltr" style="font-family:var(--font-en)">${esc(w.en)}</span> = ${esc(w.ar)}</div>
          <div class="row" style="margin-top:10px"><button class="btn pri" type="button" id="q-next">${i + 1 < picks.length ? "التالي" : "اعرض النتيجة"}</button>${sayBtn(w.en)}</div>`;
        const nb = root.querySelector("#q-next");
        try { nb.focus({ preventScroll: true }); wy.scrollIntoView({ behavior: "smooth", block: "nearest" }); } catch (e) { nb.focus(); }
        nb.addEventListener("click", () => { i++; draw(); });
      }));
    };
    const finish = () => {
      const total = picks.length, passed = score >= Math.ceil(total * 0.7);
      state.tests = state.tests || {};
      const prev = state.tests[id];
      const firstPass = passed && !(prev && prev.passed);
      state.tests[id] = { score: Math.max(score, prev ? prev.score : 0), total, passed: passed || !!(prev && prev.passed), at: Date.now() };
      missed.forEach((w) => { addCard(w.en, w.ar, w.ex, true); const c = state.cards[w.en.toLowerCase()]; if (c) { c.box = 0; c.due = Date.now(); c.rt = Date.now(); } });
      const gain = firstPass ? 30 + score : 5;
      addXP(gain, passed ? "نجحت في اختبار المرحلة" : "محاولة اختبار");
      scheduleNotifs();
      root.innerHTML = `<div class="result"><div class="big">${score}/${total}</div><div class="stars" style="font-size:22px">${starStr(score, total)}</div><div class="xp">+${gain} XP</div>
        <p class="muted">${passed ? "ممتاز! انتقلت إلى الخطوة التالية في المسار." : "تحتاج 14 إجابة صحيحة على الأقل. راجع الكلمات المستحقة ثم أعد الاختبار."}${missed.length ? " عادت " + missed.length + " كلمة إلى مراجعتك." : ""}</p>
        <div class="row" style="justify-content:center"><button class="btn" type="button" data-retry>أعد الاختبار</button>${passed ? nextStepButton() : `<a class="btn pri" href="#review">راجع الآن</a>`}</div></div>`;
      root.querySelector("[data-retry]").addEventListener("click", () => runStageTest(id, words));
    };
    draw();
  }
  function buildWordQuestion(w, type, pool) {
    let blank = null;
    if (type === 2) { blank = blankOf(w); if (!blank) type = 0; }
    const field = type === 0 ? "ar" : "en";
    const others = shuffle(pool.filter((x) => x !== w && x[field] !== w[field])).slice(0, 3);
    const opts = shuffle([w].concat(others));
    const prompt = type === 0 ? `<div class="q-big" dir="ltr">${esc(w.en)}</div><div class="muted" style="font-size:13.5px">ما معنى هذه الكلمة؟</div>`
      : type === 1 ? `<div class="q-big">${esc(w.ar)}</div><div class="muted" style="font-size:13.5px">اختر الكلمة الإنجليزية</div>`
      : `<div class="q-sent" dir="ltr">${esc(blank)}</div><div class="muted" style="font-size:13.5px">اختر الكلمة التي تكمل الجملة</div>`;
    const optsHtml = opts.map((o, j) => `<button class="opt" type="button" data-j="${j}" ${type === 0 ? "" : 'dir="ltr" style="text-align:left;font-family:var(--font-en);font-size:17px"'}><span class="k">${j + 1}</span><span>${esc(type === 0 ? o.ar : o.en)}</span></button>`).join("");
    return { type, opts, prompt, optsHtml };
  }

  function viewUnit(id) {
    const u = UNITS.find((x) => x.id === id);
    if (!u) return viewWords();
    if (!unitUnlocked(u)) { toast("أكمل الخطوة السابقة في المسار أولاً"); location.hash = "path"; return; }
    const st = window.STAGES.find((x) => x.id === u.stage) || window.STAGES[0];
    const it = PATH[PIDX["unit:" + u.id]];
    app.innerHTML = `<div class="crumbs"><a href="#path">المسار</a><span>›</span><span>المرحلة ${st.n}: ${esc(st.title)}</span></div>
    <section class="card lesson-head"><span class="chip">الخطوة ${it ? it.n : ""} من ${PATH.length} · ${u.cat === "tech" ? "كلمات تقنية" : "كلمات عامة"} · ${u.words.length} كلمة</span><h1>${esc(u.title)}</h1>
      <p class="muted" style="margin-top:6px">اقرأ كل كلمة ومثالها واستمع لنطقها. لا تحاول الحفظ بالقوة؛ التدريب والمراجعة سيثبتانها.</p>
      <div class="row" style="margin-top:12px"><button class="btn pri" type="button" id="u-start">ابدأ التدريب</button><button class="btn" type="button" id="u-hide">إخفاء المعاني لاختبار نفسك</button></div>
    </section>
    <section class="card"><div class="wlist" id="wlist">${u.words.map((w, i) => `
      <div class="wrow"><div class="wn">${i + 1}</div><div class="wbody">
        <div class="row" style="gap:8px"><b class="wen" dir="ltr">${esc(w.en)}</b>${sayBtn(w.en)}<span class="war">${esc(w.ar)}</span></div>
        <div class="wex" dir="ltr">${esc(w.ex)}</div></div>${state.cards[w.en.toLowerCase()] ? `<span class="chip" style="align-self:center">محفوظة</span>` : ""}</div>`).join("")}
    </div></section>
    <section class="card" id="u-quiz-sec" hidden><h2 style="font-size:18px;margin-bottom:10px">تدريب الوحدة</h2><div id="quiz"></div></section>`;
    app.querySelectorAll(".wex").forEach(makeReadable);
    $("#u-hide").addEventListener("click", (e) => { const l = $("#wlist"); l.classList.toggle("hide-ar"); e.target.textContent = l.classList.contains("hide-ar") ? "إظهار المعاني" : "إخفاء المعاني لاختبار نفسك"; });
    $("#wlist").addEventListener("click", (e) => { const r = e.target.closest(".wrow"); if (r && $("#wlist").classList.contains("hide-ar") && !e.target.closest(".w, .say")) r.classList.toggle("peek"); });
    $("#u-start").addEventListener("click", () => { const s = $("#u-quiz-sec"); s.hidden = false; runUnitDrill(u); s.scrollIntoView({ behavior: "smooth", block: "start" }); });
  }

  function blankOf(w) {
    const re = new RegExp("\\b" + w.en.replace(/[.*+?^${}()|[\]\\]/g, "\\$&") + "[a-z]*\\b", "i");
    if (!re.test(w.ex)) return null;
    return w.ex.replace(re, "_____");
  }
  function runUnitDrill(u) {
    const root = $("#quiz");
    const pool = u.words;
    const distract = (w, field) => {
      const others = shuffle(pool.filter((x) => x !== w && x[field] !== w[field])).slice(0, 3);
      return shuffle([w].concat(others));
    };
    let queue = shuffle(pool.map((w, i) => ({ w, t: i % 3 })));
    const firstTry = new Set(), missed = new Set();
    let done = 0; const total = pool.length;
    const draw = () => {
      if (!queue.length) return finish();
      const item = queue[0]; const w = item.w;
      let type = item.t; let blank = null;
      if (type === 2) { blank = blankOf(w); if (!blank) type = 0; }
      const opts = type === 1 ? distract(w, "en") : distract(w, type === 0 ? "ar" : "en");
      const prompt = type === 0 ? `<div class="q-big" dir="ltr">${esc(w.en)}</div><div class="muted" style="font-size:13.5px">ما معنى هذه الكلمة؟</div>`
        : type === 1 ? `<div class="q-big">${esc(w.ar)}</div><div class="muted" style="font-size:13.5px">اختر الكلمة الإنجليزية</div>`
        : `<div class="q-sent" dir="ltr">${esc(blank)}</div><div class="muted" style="font-size:13.5px">اختر الكلمة التي تكمل الجملة</div>`;
      root.innerHTML = `<div class="quiz"><div class="q-count">أتقنت ${done} من ${total}</div><div class="bar" style="margin-top:0"><i style="width:${Math.round((done / total) * 100)}%"></i></div>
        ${prompt}
        <div class="opts">${opts.map((o, j) => `<button class="opt" type="button" data-j="${j}" ${type === 0 ? "" : 'dir="ltr" style="text-align:left;font-family:var(--font-en);font-size:17px"'}><span class="k">${j + 1}</span><span>${esc(type === 0 ? o.ar : o.en)}</span></button>`).join("")}</div><div id="why"></div></div>`;
      if (type === 0) speakSoft(w.en);
      root.querySelectorAll(".opt").forEach((b) => b.addEventListener("click", () => {
        const pick = opts[Number(b.dataset.j)]; const ok = pick === w;
        root.querySelectorAll(".opt").forEach((x) => { x.disabled = true; const o = opts[Number(x.dataset.j)]; if (o === w) x.classList.add("right"); else if (x === b) x.classList.add("wrong"); });
        queue.shift();
        if (ok) { done++; if (!missed.has(w)) firstTry.add(w); }
        else { missed.add(w); queue.splice(Math.min(queue.length, 3), 0, { w, t: (item.t + 1) % 3 }); }
        const wy = root.querySelector("#why");
        wy.innerHTML = `<div class="why ${ok ? "ok" : "no"}"><b>${ok ? "صحيح" : "ستعود هذه الكلمة بعد قليل"}</b><span dir="ltr" class="en-x" style="font-family:var(--font-en)">${esc(w.en)}</span> = ${esc(w.ar)}<div dir="ltr" class="ex-x" style="font-family:var(--font-en);margin-top:4px">${esc(w.ex)}</div></div>
          <div class="row" style="margin-top:10px"><button class="btn pri" type="button" id="q-next">${queue.length ? "التالي" : "اعرض النتيجة"}</button>${sayBtn(w.en)}</div>`;
        makeReadable(wy.querySelector(".ex-x"));
        const nb = root.querySelector("#q-next");
        try { nb.focus({ preventScroll: true }); wy.scrollIntoView({ behavior: "smooth", block: "nearest" }); } catch (e) { nb.focus(); }
        nb.addEventListener("click", draw);
      }));
    };
    const finish = () => {
      const score = firstTry.size;
      const first = !state.units[u.id]; const prev = state.units[u.id];
      state.units[u.id] = { score: Math.max(score, prev ? prev.score : 0), total, at: Date.now() };
      let added = 0;
      u.words.forEach((w) => { if (addCard(w.en, w.ar, w.ex, true)) added++; });
      // الكلمات التي أخطأت فيها تُراجع قريباً
      u.words.forEach((w) => {
        const c = state.cards[w.en.toLowerCase()]; if (!c || c.box > 1) return;
        if (missed.has(w)) { c.box = 0; c.due = Date.now() + 10 * 60000; } else { c.box = Math.max(c.box, 1); c.due = Date.now() + DAY; }
      });
      if (state.today.d !== todayKey()) state.today = { d: todayKey(), xp: 0, nw: 0 };
      state.today.nw = (state.today.nw || 0) + added;
      const gain = first ? 15 + score : 5;
      addXP(gain, first ? "أنهيت الوحدة" : "إعادة الوحدة");
      scheduleNotifs();
      root.innerHTML = `<div class="result"><div class="big">${score}/${total}</div><div class="muted">صحيحة من أول محاولة</div><div class="stars" style="font-size:22px">${starStr(score, total)}</div><div class="xp">+${gain} XP</div>
        <p class="muted">${added ? "أُضيفت " + added + " كلمة إلى مراجعتك. ستعود إليك في الأيام القادمة حتى تثبت." : "كل كلمات الوحدة موجودة في مراجعتك."} ${milestoneText()}</p>
        <div class="row" style="justify-content:center"><button class="btn" type="button" data-retry>أعد التدريب</button>${nextStepButton()}</div></div>`;
      root.querySelector("[data-retry]").addEventListener("click", () => runUnitDrill(u));
    };
    draw();
  }
  function milestoneText() {
    const n = learnedCount();
    const ms = [100, 250, 500, 750, 1000, 1500, WORDS.length];
    const next = ms.find((m) => m > n);
    return next ? "باقٍ " + (next - n) + " كلمة لتصل إلى " + next + "." : "وصلت إلى كل كلمات البنك!";
  }
  let lastSoft = 0;
  function speakSoft(t) { if (!state.autoSpeak) return; if (Date.now() - lastSoft < 300) return; lastSoft = Date.now(); speak(t); }

  /* ================= الشهادة ================= */
  function allLessonsDone() { return pathComplete(); }
  function viewCert() {
    const ld = window.LESSONS.filter((l) => state.done[l.id]).length;
    const sd = window.SIMS.filter((s) => state.sims[s.id]).length;
    const ud = UNITS.filter((u) => state.units[u.id]).length;
    const ready = allLessonsDone();
    const lv = levelInfo(state.xp);
    const nm = state.name || "";
    app.innerHTML = `<div class="section-title"><h2>شهادة الإتمام</h2><span>${ready ? "أنهيت المسار كاملاً" : "تُفتح الشهادة بعد إنهاء كل خطوات المسار (" + pathDoneCount() + " من " + PATH.length + ")"}</span></div>
    ${ready ? `<section class="card"><label for="cert-name" class="muted" style="font-size:14px">اسمك على الشهادة</label>
      <div class="row" style="margin-top:6px"><input id="cert-name" class="txt" type="text" value="${esc(nm)}" maxlength="40" placeholder="اكتب اسمك"><button class="btn" type="button" id="cert-save">حفظ</button></div></section>` : ""}
    <section class="cert ${ready ? "" : "locked"}">
      <div class="cert-in">
        <div class="cert-k">Certificate of Completion · شهادة إتمام</div>
        <h2>جسر القراءة الإنجليزية</h2>
        <p class="cert-name">${esc(nm || "اسمك هنا")}</p>
        <p>أتم مسار قراءة الإنجليزية العامة والتقنية، وكسر رهبة النصوص والكورسات الإنجليزية.</p>
        <div class="cert-stats">
          <div><b>${ld}/${window.LESSONS.length}</b><span>درساً</span></div>
          <div><b>${learnedCount()}</b><span>كلمة تعلمها</span></div>
          <div><b>${masteredCount()}</b><span>كلمة ثابتة</span></div>
          <div><b>${sd}/${window.SIMS.length}</b><span>تحدياً</span></div>
          <div><b>${ud}/${UNITS.length}</b><span>وحدة مفردات</span></div>
          <div><b>${window.STAGES.filter((st) => state.tests && state.tests["test-" + st.id] && state.tests["test-" + st.id].passed).length}/${window.STAGES.length}</b><span>اختبار مرحلة</span></div>
          <div><b>${state.xp}</b><span>XP · ${esc(lv.name)}</span></div>
        </div>
        <div class="cert-date">${new Date().toLocaleDateString("ar-LY-u-nu-latn", { year: "numeric", month: "long", day: "numeric" })}</div>
      </div>
    </section>
    <section class="card"><h3 style="font-size:17px;margin-bottom:8px">ماذا بعد؟</h3>
      <div class="tips">
        <div class="tip"><b>كورس حقيقي الآن</b>اختر كورساً قصيراً في مجالك وفعّل الترجمة الإنجليزية (وليس العربية) وانسخ أي فقرة صعبة إلى المحلل.</div>
        <div class="tip"><b>صفحة توثيق يومياً</b>اقرأ صفحة واحدة من توثيق أداة تستخدمها. ستجد أن كلمات Getting Started وParameters صارت مألوفة.</div>
        <div class="tip"><b>استمر في المراجعة</b>المراجعة اليومية القصيرة تنقل الكلمات من "تعلمتها" إلى "ثابتة".</div>
        <div class="tip"><b>كتاب تقني كامل</b>ابدأ بكتاب قصير في مجالك. اقرأ فصلاً في الأسبوع، ولا تتوقف عند كل كلمة.</div>
      </div></section>`;
    const sv = $("#cert-save");
    if (sv) sv.addEventListener("click", () => { state.name = $("#cert-name").value.trim().slice(0, 40); save(); viewCert(); toast("حُفظ الاسم"); });
  }

  /* ================= الإشعارات (داخل تطبيق أندرويد فقط) ================= */
  const NATIVE = (() => { try { return !!(window.Capacitor && window.Capacitor.isNativePlatform && window.Capacitor.isNativePlatform()); } catch (e) { return false; } })();
  const LN = (() => { try { return NATIVE && window.Capacitor.Plugins && window.Capacitor.Plugins.LocalNotifications ? window.Capacitor.Plugins.LocalNotifications : null; } catch (e) { return null; } })();
  let notifTimer = null;
  function scheduleNotifs() { clearTimeout(notifTimer); notifTimer = setTimeout(doSchedule, 800); }
  async function doSchedule() {
    if (!LN) return;
    try {
      const pend = await LN.getPending();
      const old = (pend && pend.notifications || []).filter((n) => n.id >= 1000 && n.id < 1200).map((n) => ({ id: n.id }));
      if (old.length) await LN.cancel({ notifications: old });
      const n = state.notif || {};
      if (!n.on) return;
      let perm = await LN.checkPermissions();
      if (perm.display !== "granted") { perm = await LN.requestPermissions(); if (perm.display !== "granted") return; }
      try { await LN.createChannel({ id: "words", name: "كلمة للتذكير", description: "تذكير دوري بالكلمات", importance: 4, visibility: 1, vibration: true }); } catch (e) { /* القناة موجودة */ }
      const every = Math.max(1, Number(n.every) || 3), start = Number(n.start ?? 9), end = Number(n.end ?? 22);
      const times = []; let t = new Date(); t.setMinutes(0, 0, 0); t = new Date(t.getTime() + 3600000);
      const limit = Date.now() + 4 * DAY;
      while (t.getTime() < limit && times.length < 48) {
        const h = t.getHours();
        if (h >= start && h <= end && (h - start) % every === 0) times.push(new Date(t.getTime() + Math.floor(Math.random() * 10) * 60000));
        t = new Date(t.getTime() + 3600000);
      }
      if (!times.length) return;
      let pool = Object.values(state.cards).sort((a, b) => a.box - b.box || a.due - b.due).slice(0, 120);
      if (pool.length < times.length) { const nu = nextUnit(); if (nu) pool = pool.concat(nu.words.map((w) => ({ en: w.en, ar: w.ar, ex: w.ex, fresh: true }))); }
      if (!pool.length) pool = WORDS.slice(0, 40);
      pool = shuffle(pool.slice());
      const list = times.map((at, i) => {
        const c = pool[i % pool.length];
        return { id: 1000 + i, channelId: "words", title: c.en + " = " + c.ar, body: (c.fresh ? "كلمة جديدة من وحدتك القادمة · " : "") + (c.ex || "افتح التطبيق وراجع كلماتك"), largeBody: c.ex || "", schedule: { at, allowWhileIdle: true }, extra: { route: "review" } };
      });
      await LN.schedule({ notifications: list });
      state.notifNext = times[0].getTime();
    } catch (e) { /* تجاهل أخطاء الإشعارات */ }
  }
  if (LN) {
    try { LN.addListener("localNotificationActionPerformed", () => { location.hash = "review"; }); } catch (e) { /* تجاهل */ }
    document.addEventListener("visibilitychange", () => { if (document.visibilityState === "visible") { renderHeader(); scheduleNotifs(); } });
  }

  /* ================= نقل التقدم بين الموقع والتطبيق ================= */
  function exportCode() {
    const s = JSON.parse(JSON.stringify(state)); delete s.ai;
    return "JISR1:" + btoa(unescape(encodeURIComponent(JSON.stringify(s))));
  }
  function importCode(code) {
    const c = String(code || "").trim();
    if (!c.startsWith("JISR1:")) throw new Error("bad");
    const obj = JSON.parse(decodeURIComponent(escape(atob(c.slice(6)))));
    if (!obj || typeof obj !== "object" || !obj.cards) throw new Error("bad");
    state = merge(state, obj); save();
  }

  /* ---------------- منطق الفتح ---------------- */
  const LIDX = {}; window.LESSONS.forEach((l, i) => (LIDX[l.id] = i));
  function lessonUnlocked(l) { return pathUnlocked("lesson", l.id); }
  function simUnlocked(s) { return pathUnlocked("sim", s.id); }
  const starStr = (score, total) => { const r = total ? score / total : 0; const n = r >= 0.99 ? 3 : r >= 0.6 ? 2 : 1; return "★".repeat(n) + "☆".repeat(3 - n); };

  /* ---------------- الهيدر ---------------- */
  function renderHeader() {
    $("#hdr-xp").textContent = state.xp + " XP";
    const s = streakNow();
    $("#hdr-streak").textContent = s + (s === 1 ? " يوم" : " أيام") + " متتالية";
    const d = dueCards().length; const b = $("#due-badge");
    b.hidden = d === 0; b.textContent = d > 99 ? "99+" : d;
  }

  /* ---------------- الصفحات ---------------- */
  const app = $("#app");

  function viewPath() {
    const lv = levelInfo(state.xp);
    const nx = nextStep();
    const doneCount = Object.keys(state.done).length;
    const pdone = pathDoneCount();
    const tday = state.today.d === todayKey() ? state.today.xp : 0;
    const goal = Number(state.goal) || 40;
    const due = dueCards().length;
    let html = `
    <section class="dash">
      <div class="card">
        <div class="lvl">
          <div class="lvl-badge">${lv.n}</div>
          <div style="flex:1;min-width:0">
            <div class="muted" style="font-size:13px">مستواك في القراءة</div>
            <h3>${esc(lv.name)}</h3>
            <div class="bar"><i style="width:${lv.pct}%"></i></div>
            <div class="muted" style="font-size:12.5px;margin-top:4px">${lv.last ? "وصلت لأعلى مستوى" : state.xp + " / " + lv.nxt + " XP للمستوى التالي"}</div>
          </div>
        </div>
        <div class="stats3">
          <div class="stat"><b>${pdone}<small class="muted" style="font-size:14px"> / ${PATH.length}</small></b><span>خطوة في المسار</span></div>
          <div class="stat"><b>${learnedCount()}</b><span>كلمة تعلمتها</span></div>
          <div class="stat"><b>${streakNow()}</b><span>أيام متتالية</span></div>
        </div>
        <div style="margin-top:14px">
          <div class="row" style="justify-content:space-between;font-size:13.5px"><span>هدف اليوم</span><span class="muted" style="font-variant-numeric:tabular-nums">${Math.min(tday, goal)} / ${goal} XP</span></div>
          <div class="bar gold"><i style="width:${Math.min(100, Math.round((tday / goal) * 100))}%"></i></div>
        </div>
      </div>
      <div class="card next-card">
        ${nx ? `<div><div class="kicker">الخطوة ${nx.n} من ${PATH.length} · المرحلة ${window.STAGES.find((s) => s.id === nx.stage).n} · ${STEP_KIND[nx.type]}</div><h3>${esc(stepTitle(nx))}</h3>
          <p class="muted" style="font-size:14px">${nx.type === "lesson" ? window.LESSONS.find((l) => l.id === nx.id).minutes + " دقائق تقريباً" : nx.type === "unit" ? UNITS.find((u) => u.id === nx.id).words.length + " كلمة جديدة · كلمات اليوم " + todayNew() + "/" + (Number(state.newGoal) || 20) : nx.type === "test" ? "20 سؤالاً من كلمات المرحلة" : "شاشة واقعية ومهمة"}</p></div>
        <a class="btn pri" href="${stepHref(nx)}">ابدأ</a>` :
        `<div><div class="kicker">أنهيت المسار كاملاً</div><h3>الآن طبّق على نصوص حقيقية</h3><p class="muted" style="font-size:14px">انسخ فقرة من أي كورس أو توثيق وضعها في المحلل، واستمر في المراجعة.</p></div><a class="btn pri" href="#cert">اعرض شهادتك</a>`}
        ${due ? `<a class="btn" href="#review">راجع ${due} ${due === 1 ? "كلمة" : "كلمات"} مستحقة</a>` : ""}
      </div>
    </section>
    ${(() => { const w = wordOfMoment(); return w ? `<section class="card wom"><div class="wom-k">كلمة اللحظة</div>
      <div class="row" style="gap:10px"><b class="wen" dir="ltr">${esc(w.en)}</b>${sayBtn(w.en)}<span class="war">${esc(w.ar)}</span></div>
      ${w.ex ? `<div class="wex" dir="ltr">${esc(w.ex)}</div>` : ""}<p class="muted" style="font-size:13px">${esc(CHEERS[Math.floor(Math.random() * CHEERS.length)])}</p></section>` : ""; })()}
    ${pathComplete() ? `<section class="card next-card" style="flex-direction:row;align-items:center"><div style="flex:1"><div class="kicker">مبروك</div><h3>شهادة إتمام المسار جاهزة</h3></div><a class="btn pri" href="#cert">اعرض الشهادة</a></section>` : ""}`;

    if (doneCount === 0) {
      html += `<section class="card"><div class="section-title"><h2>كيف تستخدم الموقع</h2></div>
      <div class="tips" style="margin-top:12px">
        <div class="tip"><b>اضغط أي كلمة إنجليزية</b>في أي مكان بالموقع يظهر معناها ونطقها، ويمكنك إضافتها للمراجعة.</div>
        <div class="tip"><b>مسار واحد متدرج</b>درس قصير، ثم وحدات كلمات من موضوعه، وفي آخر كل مرحلة اختبار كلمات وتحدٍّ على شاشة واقعية.</div>
        <div class="tip"><b>المراجعة تثبت الكلمات</b>البطاقات تعود لك في الوقت المناسب حتى لا تنساها.</div>
        <div class="tip"><b>قرابة 2000 كلمة</b>عامة وتقنية، كل كلمة بمعناها ومثال. خطوتان أو ثلاث يومياً تكفي.</div>
        <div class="tip"><b>المحاكاة والمحلل</b>تدرّب على شاشات تشبه المواقع الحقيقية، ثم حلّل أي نص من كورساتك.</div>
      </div></section>`;
    }

    const cur = nx ? nx.stage : null;
    window.STAGES.forEach((st) => {
      const items = PATH.filter((it) => it.stage === st.id);
      const dn = items.filter(itemDone).length;
      const allDone = dn === items.length;
      const open = st.id === cur || (!cur && st === window.STAGES[window.STAGES.length - 1]);
      html += `<details class="card stage ${allDone ? "done" : ""}" ${open ? "open" : ""}>
        <summary class="stage-head"><div class="stage-num">${st.n}</div><div><h3>${esc(st.title)}</h3><p>${esc(st.sub)}</p></div><div class="stage-prog">${dn}/${items.length}</div></summary>
        <ul class="lessons">`;
      items.forEach((it) => {
        const un = pathUnlocked(it.type, it.id), d = itemDone(it);
        let title, small, rec = null, cls = "", dot;
        if (it.type === "lesson") { const l = window.LESSONS.find((x) => x.id === it.id); title = l.title; small = "درس · " + l.minutes + " دقائق"; rec = state.done[l.id]; }
        else if (it.type === "unit") { const u = UNITS.find((x) => x.id === it.id); title = u.title; small = "كلمات · " + u.words.slice(0, 3).map((w) => w.en).join(" · ") + " ..."; rec = state.units[u.id]; cls = "unit"; }
        else if (it.type === "test") { title = "اختبار كلمات المرحلة"; small = "20 سؤالاً من " + (STAGE_WORDS[st.id] || []).length + " كلمة · النجاح 70%"; rec = state.tests && state.tests[it.id]; cls = "boss"; }
        else { const sm = window.SIMS.find((x) => x.id === it.id); title = "تحدي المرحلة: " + sm.title; small = "شاشة واقعية ومهمة استخراج معلومات"; rec = state.sims[sm.id]; cls = "boss"; }
        dot = d ? "✓" : it.type === "unit" ? "Aa" : it.type === "lesson" ? it.n : "★";
        html += `<li><button class="lrow ${cls} ${d ? "complete" : un ? "avail" : ""} ${nx === it ? "current" : ""}" type="button" data-go="${stepHref(it).slice(1)}" ${un ? "" : "disabled"}>
          <span class="ldot">${dot}</span>
          <span class="ltitle"><b>${esc(title)}</b><small ${it.type === "unit" ? 'dir="auto"' : ""}>${esc(small)}</small></span>
          ${d && rec ? `<span class="stars">${starStr(rec.score, rec.total)}</span>` : un ? `<span class="chip ${cls === "boss" ? "gold" : ""}">${nx === it ? "التالي" : "متاح"}</span>` : ICON.lock}
        </button></li>`;
      });
      html += `</ul></details>`;
    });
    app.innerHTML = html;
    app.querySelectorAll(".wom .wex").forEach(makeReadable);
  }

  function viewLesson(id) {
    const l = window.LESSONS.find((x) => x.id === id);
    if (!l) return viewPath();
    if (!lessonUnlocked(l)) { toast("أكمل الخطوة السابقة في المسار أولاً، أو افتح كل الدروس من الإعدادات"); location.hash = "path"; return; }
    const st = window.STAGES.find((s) => s.id === l.stage);
    const idx = LIDX[l.id];
    const nxt = window.LESSONS[idx + 1];
    app.innerHTML = `
    <div class="crumbs"><a href="#path">المسار</a><span>›</span><span>المرحلة ${st.n}: ${esc(st.title)}</span></div>
    <section class="card lesson-head">
      <span class="chip">الدرس ${idx + 1} من ${window.LESSONS.length} · ${l.minutes} دقائق</span>
      <h1>${esc(l.title)}</h1>
      <div class="steps" aria-hidden="true"><i class="on"></i><i class="on"></i><i class="on"></i><i class="on"></i><i id="st-q"></i></div>
    </section>
    <section class="card block"><h2><span class="n">1</span>الفكرة</h2><div class="prose tbl-wrap">${l.explain}</div></section>
    <section class="card block"><h2><span class="n">2</span>أمثلة من الواقع</h2>
      <div class="ex-list">${l.examples.map((e) => `<div class="ex"><div class="en-line"><span class="en-x">${esc(e.en)}</span>${sayBtn(e.en)}</div><div class="ar">${esc(e.ar)}</div>${e.note ? `<div class="note">${esc(e.note)}</div>` : ""}</div>`).join("")}</div>
    </section>
    <section class="card block"><h2><span class="n">3</span>اقرأ النص</h2>
      <div class="read-hint">اقرأ الفقرة أولاً بدون ترجمة. اضغط على أي كلمة لتعرف معناها، ثم تأكد من فهمك بزر الترجمة.</div>
      <div class="paper"><h3>${esc(l.reading.title)}</h3>
      ${l.reading.paras.map((p, i) => `<div class="para"><p class="en-p">${esc(p.en)}</p>
        <div class="tools">${sayBtn(p.en, "استمع للفقرة")}<button class="btn sm ghost" type="button" data-tr="${i}">${ICON.tr} الترجمة</button></div>
        <div class="ar-p" id="tr-${i}" hidden>${esc(p.ar)}</div></div>`).join("")}
      </div>
    </section>
    <section class="card block"><h2><span class="n">4</span>كلمات الدرس</h2>
      <div class="vocab">${l.vocab.map(([en, ar]) => `<div class="vcell"><span class="en no-read">${esc(en)}</span><span class="ar">${esc(ar)}</span>${sayBtn(en)}</div>`).join("")}</div>
      <div class="row" style="margin-top:12px"><button class="btn sm" type="button" id="add-all">أضف كل الكلمات للمراجعة</button></div>
    </section>
    <section class="card block" id="quiz-sec"><h2><span class="n">5</span>اختبر فهمك</h2><div id="quiz"></div></section>`;

    app.querySelectorAll(".prose .en, .en-x, .en-p, .paper h3, .formula, table.mini").forEach(makeReadable);
    app.querySelectorAll("[data-tr]").forEach((b) => b.addEventListener("click", () => { const el = $("#tr-" + b.dataset.tr); el.hidden = !el.hidden; }));
    $("#add-all").addEventListener("click", () => {
      let n = 0; l.vocab.forEach(([en, ar]) => { if (addCard(en, ar, findExample(l, en), true)) n++; });
      toast(n ? "أُضيفت " + n + " كلمة للمراجعة" : "كل الكلمات موجودة بالفعل");
      if (n) addXP(n);
    });

    runQuiz($("#quiz"), l.quiz, (score, total) => {
      $("#st-q").classList.add("on");
      const first = !state.done[l.id];
      const prev = state.done[l.id];
      state.done[l.id] = { score: Math.max(score, prev ? prev.score : 0), total, at: Date.now() };
      let added = 0; l.vocab.forEach(([en, ar]) => { if (addCard(en, ar, findExample(l, en), true)) added++; });
      const gain = first ? 20 + score * 5 : 5;
      addXP(gain, first ? "أكملت الدرس" : "مراجعة الدرس");
      return `<div class="result"><div class="big">${score}/${total}</div><div class="stars" style="font-size:22px">${starStr(score, total)}</div>
        <div class="xp">+${gain} XP</div>
        <p class="muted">${score === total ? "ممتاز! فهمت الدرس بالكامل." : score >= total * 0.6 ? "جيد جداً. راجع التوضيح تحت الأسئلة التي أخطأت فيها." : "لا بأس، اقرأ النص مرة ثانية ثم أعد الاختبار."}${added ? " أُضيفت " + added + " كلمة لمراجعتك." : ""}</p>
        <div class="row" style="justify-content:center">
          <button class="btn" type="button" data-retry>أعد الاختبار</button>
          ${nextStepButton()}
        </div>

      </div>`;
    }, () => viewLesson(id));
  }
  function findExample(l, en) {
    const k = en.toLowerCase();
    const all = l.reading.paras.map((p) => p.en).concat(l.examples.map((e) => e.en));
    for (const t of all) { const s = splitSentences(t).find((x) => x.toLowerCase().includes(k)); if (s) return s; }
    return "";
  }

  function runQuiz(root, qs, onFinish, onRetry) {
    let i = 0, score = 0;
    const draw = () => {
      if (i >= qs.length) {
        root.innerHTML = onFinish(score, qs.length);
        const r = root.querySelector("[data-retry]"); if (r) r.addEventListener("click", onRetry);
        return;
      }
      const q = qs[i];
      root.innerHTML = `<div class="quiz"><div class="q-count">سؤال ${i + 1} من ${qs.length}</div><div class="q-text">${esc(q.q)}</div>
        <div class="opts">${q.o.map((o, j) => `<button class="opt" type="button" data-j="${j}"><span class="k">${["أ", "ب", "ج", "د"][j]}</span><span>${esc(o)}</span></button>`).join("")}</div>
        <div id="why"></div></div>`;
      makeReadable(root.querySelector(".q-text"));
      root.querySelectorAll(".opt").forEach((b) => b.addEventListener("click", () => {
        const j = Number(b.dataset.j), ok = j === q.a;
        if (ok) score++;
        root.querySelectorAll(".opt").forEach((x) => { x.disabled = true; const k = Number(x.dataset.j); if (k === q.a) x.classList.add("right"); else if (k === j) x.classList.add("wrong"); });
        const w = root.querySelector("#why");
        w.innerHTML = `<div class="why ${ok ? "ok" : "no"}"><b>${ok ? "إجابة صحيحة" : "ليست هذه"}</b><span class="why-t">${esc(q.why)}</span></div>
          <div class="row" style="margin-top:10px"><button class="btn pri" type="button" id="q-next">${i + 1 < qs.length ? "السؤال التالي" : "اعرض النتيجة"}</button></div>`;
        makeReadable(w.querySelector(".why-t"));
        root.querySelector("#q-next").addEventListener("click", () => { i++; draw(); });
        const nb = root.querySelector("#q-next");
        try { nb.focus({ preventScroll: true }); w.scrollIntoView({ behavior: "smooth", block: "nearest" }); } catch (e) { nb.focus(); }
      }));
    };
    draw();
  }

  function viewSims() {
    app.innerHTML = `<div class="section-title"><h2>المحاكاة</h2><span>شاشات تشبه المواقع الحقيقية بأسماء خيالية. مهمتك: استخرج المعلومة كأنك أمام الموقع الأصلي.</span></div>
    <div class="sim-grid">${window.SIMS.map((s) => {
      const un = simUnlocked(s), d = state.sims[s.id];
      const st = window.STAGES.find((x) => x.id === s.stage);
      return `<button class="sim-tile" type="button" data-go="sim-${s.id}" ${un ? "" : "disabled"}>
        <div class="row" style="justify-content:space-between"><span class="chip gold">${esc(s.kind)}</span>${d ? `<span class="stars">${starStr(d.score, d.total)}</span>` : un ? "" : ICON.lock}</div>
        <h3>${esc(s.title)}</h3><p>${esc(s.intro)}</p>
        <small class="muted">${un ? (d ? "أنجزته · يمكنك إعادته" : "متاح الآن · 40 XP") : "يُفتح بعد اختبار المرحلة " + st.n + ": " + esc(st.title)}</small>
      </button>`;
    }).join("")}</div>`;
  }

  function viewSim(id) {
    const s = window.SIMS.find((x) => x.id === id);
    if (!s) return viewSims();
    if (!simUnlocked(s)) { toast("أكمل خطوات المرحلة واختبارها أولاً"); location.hash = "sims"; return; }
    app.innerHTML = `<div class="crumbs"><a href="#sims">المحاكاة</a><span>›</span><span>${esc(s.kind)}</span></div>
    <section class="card"><h1 style="font-size:23px">${esc(s.title)}</h1><p class="muted" style="margin-top:4px">${esc(s.intro)} اضغط أي كلمة في الشاشة لمعرفة معناها.</p></section>
    <div class="sim-split"><div class="sim-stage" id="sim-screen">${s.html}</div><div class="card sticky"><h2 style="font-size:18px;margin-bottom:10px">المهمة</h2><div id="quiz"></div></div></div>`;
    makeReadable($("#sim-screen"));
    runQuiz($("#quiz"), s.tasks, (score, total) => {
      const first = !state.sims[s.id];
      const prev = state.sims[s.id];
      state.sims[s.id] = { score: Math.max(score, prev ? prev.score : 0), total, at: Date.now() };
      const gain = first ? 40 : 5;
      addXP(gain, first ? "أنجزت التحدي" : "إعادة التحدي");
      return `<div class="result"><div class="big">${score}/${total}</div><div class="stars" style="font-size:22px">${starStr(score, total)}</div><div class="xp">+${gain} XP</div>
        <p class="muted">${score === total ? "قرأت الشاشة كمحترف." : "ارجع للشاشة وابحث عن الكلمات المفتاحية في الأسئلة التي فاتتك."}</p>
        <div class="row" style="justify-content:center"><button class="btn" type="button" data-retry>أعد التحدي</button>${nextStepButton()}</div></div>`;
    }, () => viewSim(id));
  }

  /* ---- المراجعة ---- */
  let reviewQueue = [], reviewIdx = 0, revealed = false, practice = false, inPractice = false;
  function viewReview() {
    const all = Object.values(state.cards);
    const due = dueCards();
    if (!all.length) {
      app.innerHTML = `<div class="section-title"><h2>المراجعة</h2></div><section class="card"><p>لا توجد كلمات بعد. أكمل درساً أو اضغط أي كلمة في النصوص واختر "أضف للمراجعة".</p><div class="row" style="margin-top:12px"><a class="btn pri" href="#path">اذهب للمسار</a></div></section>`;
      return;
    }
    inPractice = practice;
    reviewQueue = (practice ? shuffle(all.slice()).slice(0, 20) : due.slice(0, 30));
    reviewIdx = 0; revealed = false;
    const boxes = [0, 0, 0, 0, 0, 0, 0]; all.forEach((c) => boxes[Math.min(6, c.box)]++);
    const mastered = all.filter((c) => c.box >= 4).length;
    app.innerHTML = `<div class="section-title"><h2>المراجعة</h2><span>${due.length ? due.length + " مستحقة الآن" : "لا شيء مستحق الآن"} · ${mastered} كلمة ثابتة في ذاكرتك</span></div>
      <div id="flash"></div>
      <section class="card"><h3 style="font-size:16px;margin-bottom:10px">كلماتك حسب قوة الحفظ</h3>
        <div class="boxes">${["جديدة", "يوم", "يومان", "4 أيام", "8 أيام", "16 يوماً", "شهر"].map((n, i) => `<div class="stat"><b>${boxes[i]}</b><span>${n}</span></div>`).join("")}</div>
        <details style="margin-top:14px"><summary style="cursor:pointer">كل الكلمات (${all.length})</summary>
          <div class="deck" style="margin-top:10px">${all.sort((a, b) => a.en.localeCompare(b.en)).map((c) => `<div class="vcell"><span class="en no-read">${esc(c.en)}</span><span class="ar">${esc(c.ar)}</span></div>`).join("")}</div>
        </details>
      </section>`;
    drawCard();
  }
  function shuffle(a) { for (let i = a.length - 1; i > 0; i--) { const j = Math.floor(Math.random() * (i + 1)); [a[i], a[j]] = [a[j], a[i]]; } return a; }
  function drawCard() {
    const root = $("#flash"); if (!root) return;
    if (reviewIdx >= reviewQueue.length) {
      const nextDue = Object.values(state.cards).reduce((m, c) => Math.min(m, c.due), Infinity);
      const wait = nextDue - Date.now();
      root.innerHTML = `<section class="card flash"><div class="result"><div class="big">✓</div><h3>${reviewQueue.length ? "أنهيت المراجعة" : "لا توجد بطاقات مستحقة الآن"}</h3>
        <p class="muted">${isFinite(nextDue) && wait > 0 ? "البطاقة التالية بعد " + humanWait(wait) + "." : ""} المراجعة القصيرة اليومية أقوى من جلسة طويلة كل أسبوع.</p>
        <div class="row" style="justify-content:center"><button class="btn" type="button" id="prac">تدرّب على 20 كلمة عشوائية</button><a class="btn pri" href="#path">إلى المسار</a></div></div></section>`;
      $("#prac").addEventListener("click", () => { practice = true; viewReview(); practice = false; });
      return;
    }
    const c = reviewQueue[reviewIdx];
    root.innerHTML = `<section class="flash">
      <div class="q-count" style="text-align:center">${reviewIdx + 1} / ${reviewQueue.length}${inPractice ? " · تدريب حر" : ""}</div>
      <div class="fcard"><div class="box-row">${[1, 2, 3, 4, 5, 6].map((i) => `<i class="${c.box >= i ? "on" : ""}"></i>`).join("")}</div>
        <div class="word">${esc(c.en)}</div>${sayBtn(c.en)}
        ${c.ex ? `<div class="exs">${esc(c.ex)}</div>` : ""}
        ${revealed ? `<div class="mean">${esc(c.ar)}</div>` : ""}</div>
      ${revealed ? `<div class="grade"><button class="btn hard" type="button" id="g-hard">لم أتذكرها</button><button class="btn easy" type="button" id="g-easy">عرفتها</button></div>`
        : `<button class="btn pri" type="button" id="g-show" style="padding:13px">اعرض المعنى</button>`}
    </section>`;
    const ex = root.querySelector(".exs"); if (ex) makeReadable(ex);
    if (revealed) {
      $("#g-hard").addEventListener("click", () => grade(c, false));
      $("#g-easy").addEventListener("click", () => grade(c, true));
    } else $("#g-show").addEventListener("click", () => { revealed = true; drawCard(); });
  }
  function grade(c, ok) {
    const card = state.cards[c.en.toLowerCase()];
    if (card && !inPractice) {
      if (ok) { card.box = Math.min(6, card.box + 1); card.due = Date.now() + INTERVALS[card.box] * DAY; }
      else { card.box = Math.max(0, card.box - 2); card.due = Date.now() + 10 * 60000; }
      card.rt = Date.now();
    }
    addXP(ok ? 2 : 1);
    reviewIdx++; revealed = false; drawCard();
  }
  function humanWait(ms) {
    const m = Math.round(ms / 60000);
    if (m < 60) return m + " دقيقة";
    const h = Math.round(m / 60); if (h < 24) return h + " ساعة";
    return Math.round(h / 24) + " يوم";
  }

  /* ---- المحلل ---- */
  const SAMPLE_TEXT = "In this section, we'll set up authentication for our API. Before you continue, make sure you have completed the previous lecture, because we'll reuse the database connection we configured there. Don't worry if JSON Web Tokens seem confusing at first; we'll break them down step by step.";
  let anText = null;
  function viewAnalyzer() {
    if (anText === null) anText = SAMPLE_TEXT;
    app.innerHTML = `<div class="section-title"><h2>محلل النصوص</h2><span>الصق فقرة من أي كورس، توثيق، أو رسالة خطأ واقرأها هنا.</span></div>
    <section class="card" style="display:grid;gap:12px">
      <label for="an-in" class="muted" style="font-size:14px">النص الإنجليزي (حتى 2500 حرف)</label>
      <textarea id="an-in" maxlength="2500" spellcheck="false">${esc(anText)}</textarea>
      <div class="row">
        <button class="btn" type="button" id="an-read">اعرضه كنص تفاعلي</button>
        <button class="btn pri" type="button" id="an-ai" ${sampleFn ? "" : "hidden"}>حلّل مع Claude</button>
        <button class="btn ghost sm" type="button" id="an-clear">مسح</button>
      </div>
      ${sampleFn ? "" : `<div class="notice">التحليل بالذكاء الاصطناعي يعمل عند فتح الموقع من رابطه في Claude${NATIVE ? "، وليس داخل التطبيق" : ""}. الضغط على الكلمات والقاموس (قرابة 2000 كلمة) يعمل دائماً.</div>`}
    </section>
    <div id="an-out" class="an-out"></div>`;
    const inp = $("#an-in");
    inp.addEventListener("input", () => { anText = inp.value; });
    $("#an-clear").addEventListener("click", () => { anText = ""; inp.value = ""; $("#an-out").innerHTML = ""; inp.focus(); });
    $("#an-read").addEventListener("click", () => {
      const t = inp.value.trim(); if (!t) { toast("الصق نصاً أولاً"); return; }
      const out = $("#an-out");
      out.innerHTML = `<section class="card"><div class="read-hint">اضغط أي كلمة لمعناها. الكلمات المسطرة موجودة في مراجعتك.</div><div class="paper">${t.split(/\n\s*\n|\n/).filter(Boolean).map((p) => `<div class="para"><p class="en-p">${esc(p)}</p><div class="tools">${sayBtn(p, "استمع")}</div></div>`).join("")}</div></section>`;
      makeReadable(out.querySelector(".paper"));
      out.scrollIntoView({ behavior: "smooth", block: "start" });
    });
    $("#an-ai").addEventListener("click", analyzeAI);
  }
  async function analyzeAI() {
    const t = $("#an-in").value.trim();
    if (!t) { toast("الصق نصاً أولاً"); return; }
    if (aiBusy) return;
    const out = $("#an-out"), btn = $("#an-ai");
    btn.disabled = true;
    out.innerHTML = `<section class="card"><div class="row"><span class="spinner"></span><span>يقرأ Claude النص ويجهز الشرح جملة جملة...</span></div></section>`;
    try {
      const r = await askClaude(
        "You are an expert English teacher for Arabic speakers who want to READ technical English (programming, networking, cybersecurity, online courses). " +
        "Analyze the text below for an intermediate learner.\n" +
        "Reply ONLY with JSON in this exact shape:\n" +
        '{"summary":"2-3 sentence Arabic summary","sentences":[{"en":"original sentence","ar":"natural Arabic translation","note":"one short Arabic tip about grammar/structure that helps reading it (e.g. find the main verb, passive voice, relative clause), or empty string"}],' +
        '"terms":[{"en":"key word or phrase (dictionary form)","ar":"Arabic meaning"}]}\n' +
        "Include every sentence in order (max 25). Give 5-12 useful terms, prefer technical words and common phrases. Use Modern Standard Arabic.\n\nTEXT:\n" + t.slice(0, 2500),
        "default"
      );
      const sents = Array.isArray(r.sentences) ? r.sentences : [];
      const terms = Array.isArray(r.terms) ? r.terms.filter((x) => x && x.en && x.ar) : [];
      terms.forEach((x) => { const k = String(x.en).toLowerCase(); if (!GLOSS[k]) state.ai[k] = String(x.ar).slice(0, 80); });
      save();
      out.innerHTML = `
        ${r.summary ? `<section class="card summary-box"><b>الفكرة العامة</b><p style="margin-top:4px">${esc(r.summary)}</p></section>` : ""}
        <section class="card" style="display:grid;gap:10px"><h3 style="font-size:17px">جملة جملة</h3>
          <p class="muted" style="font-size:13.5px">اقرأ الجملة الإنجليزية وحاول فهمها، ثم اضغط "الترجمة".</p>
          ${sents.map((s, i) => `<div class="sent"><div class="row" style="align-items:flex-start"><p class="en-s" style="flex:1">${esc(s.en)}</p>${sayBtn(s.en || "")}</div>
            <button class="btn sm ghost" type="button" data-str="${i}" style="justify-self:start">${ICON.tr} الترجمة</button>
            <div id="str-${i}" hidden style="display:grid;gap:6px"><div>${esc(s.ar)}</div>${s.note ? `<div class="note">${esc(s.note)}</div>` : ""}</div></div>`).join("")}
        </section>
        ${terms.length ? `<section class="card"><h3 style="font-size:17px;margin-bottom:10px">مصطلحات مهمة</h3>
          <div class="vocab">${terms.map((x, i) => `<div class="vcell"><span class="en no-read">${esc(x.en)}</span><span class="ar">${esc(x.ar)}</span><button class="btn sm" type="button" data-addt="${i}">+</button></div>`).join("")}</div>
          <div class="row" style="margin-top:10px"><button class="btn sm" type="button" id="add-terms">أضف كل المصطلحات للمراجعة</button></div></section>` : ""}`;
      out.querySelectorAll(".en-s").forEach(makeReadable);
      out.querySelectorAll("[data-str]").forEach((b) => b.addEventListener("click", () => { const el = $("#str-" + b.dataset.str); el.hidden = !el.hidden; }));
      const exFor = (en) => { const k = String(en).toLowerCase(); const s = sents.find((x) => String(x.en || "").toLowerCase().includes(k)); return s ? s.en : ""; };
      out.querySelectorAll("[data-addt]").forEach((b) => b.addEventListener("click", () => { const x = terms[Number(b.dataset.addt)]; if (addCard(x.en, x.ar, exFor(x.en))) { addXP(1); b.textContent = "✓"; b.disabled = true; } }));
      const at = $("#add-terms");
      if (at) at.addEventListener("click", () => { let n = 0; terms.forEach((x) => { if (addCard(x.en, x.ar, exFor(x.en), true)) n++; }); toast(n ? "أُضيف " + n + " مصطلح" : "كلها موجودة"); if (n) addXP(n); });
      addXP(5, "حللت نصاً حقيقياً");
    } catch (e) {
      out.innerHTML = `<section class="card"><div class="notice err">${esc(aiErrorText(e))}</div></section>`;
    } finally { btn.disabled = false; }
  }

  function softRefresh() {
    const h = (location.hash || "#path").slice(1);
    if (["path", "review", "sims", "analyzer", "words", "cert", ""].includes(h)) route(); else renderHeader();
  }
  /* ---------------- التوجيه ---------------- */
  function route() {
    closeSheet();
    const h = (location.hash || "#path").slice(1);
    let v = "path";
    if (h === "review") { v = "review"; viewReview(); }
    else if (h === "sims") { v = "sims"; viewSims(); }
    else if (h === "analyzer") { v = "analyzer"; viewAnalyzer(); }
    else if (h === "words") { v = "words"; viewWords(); }
    else if (h.startsWith("unit-")) { v = "words"; viewUnit(h.slice(5)); }
    else if (h === "cert") { viewCert(); }
    else if (h.startsWith("test-")) { viewTest(h); }
    else if (h.startsWith("lesson-")) { viewLesson(h.slice(7)); }
    else if (h.startsWith("sim-")) { v = "sims"; viewSim(h.slice(4)); }
    else viewPath();
    document.querySelectorAll("#nav a").forEach((a) => a.classList.toggle("on", a.dataset.v === v));
    renderHeader();
  }
  window.addEventListener("hashchange", () => { route(); window.scrollTo(0, 0); });
  app.addEventListener("click", (e) => {
    const g = e.target.closest("[data-go]");
    if (g && !g.disabled) location.hash = g.dataset.go;
  });

  /* ---------------- الإعدادات ---------------- */
  function openSettings() {
    $("#set-unlock").classList.toggle("on", !!state.unlockAll);
    $("#set-unlock").setAttribute("aria-pressed", state.unlockAll ? "true" : "false");
    $("#set-rate").value = String(state.rate || 0.9);
    $("#set-goal").value = String(state.goal || 40);
    $("#set-newgoal").value = String(state.newGoal || 20);
    $("#set-autospeak").classList.toggle("on", !!state.autoSpeak);
    const n = state.notif || {};
    $("#set-notif").classList.toggle("on", !!n.on);
    $("#set-every").value = String(n.every || 3);
    $("#set-hours").value = (n.start ?? 9) + "-" + (n.end ?? 22);
    $("#notif-rows").hidden = !LN; $("#notif-web").hidden = !!LN;
    $("#xfer-box").hidden = true;
    unlockAtOpen = state.unlockAll;
    $("#settings").classList.add("open");
    $("#set-close").focus();
  }
  let unlockAtOpen = null;
  function closeSettings() { $("#settings").classList.remove("open"); }
  function closeAndRefresh() { closeSettings(); if (unlockAtOpen !== state.unlockAll) softRefresh(); }
  $("#btn-settings").addEventListener("click", openSettings);
  $("#set-close").addEventListener("click", closeAndRefresh);
  $("#settings").addEventListener("click", (e) => { if (e.target.id === "settings") closeAndRefresh(); });
  $("#set-unlock").addEventListener("click", () => { state.unlockAll = !state.unlockAll; $("#set-unlock").classList.toggle("on", state.unlockAll); save(); });
  $("#set-rate").addEventListener("change", (e) => { state.rate = Number(e.target.value); save(); speak("This is how fast I will speak."); });
  $("#set-goal").addEventListener("change", (e) => { state.goal = Number(e.target.value); save(); });
  $("#set-newgoal").addEventListener("change", (e) => { state.newGoal = Number(e.target.value); save(); });
  $("#set-autospeak").addEventListener("click", (e) => { state.autoSpeak = !state.autoSpeak; e.currentTarget.classList.toggle("on", state.autoSpeak); save(); });
  $("#set-notif").addEventListener("click", (e) => { state.notif = Object.assign({}, state.notif, { on: !(state.notif && state.notif.on) }); e.currentTarget.classList.toggle("on", state.notif.on); save(); scheduleNotifs(); });
  $("#set-every").addEventListener("change", (e) => { state.notif = Object.assign({}, state.notif, { every: Number(e.target.value) }); save(); scheduleNotifs(); });
  $("#set-hours").addEventListener("change", (e) => { const [a, b] = e.target.value.split("-").map(Number); state.notif = Object.assign({}, state.notif, { start: a, end: b }); save(); scheduleNotifs(); });
  $("#xfer-out").addEventListener("click", () => { const box = $("#xfer-box"); box.hidden = false; const ta = $("#xfer-text"); ta.value = exportCode(); ta.select(); try { navigator.clipboard.writeText(ta.value).then(() => toast("نُسخ رمز التقدم"), () => {}); } catch (e) { /* انسخه يدوياً */ } $("#xfer-hint").textContent = "انسخ هذا الرمز والصقه في الجهاز الآخر من نفس المكان."; });
  $("#xfer-in").addEventListener("click", () => { const box = $("#xfer-box"); box.hidden = false; const ta = $("#xfer-text"); ta.value = ""; ta.focus(); $("#xfer-hint").textContent = "الصق رمز التقدم هنا ثم اضغط دمج."; });
  $("#xfer-apply").addEventListener("click", () => { try { importCode($("#xfer-text").value); toast("تم دمج التقدم"); closeSettings(); softRefresh(); scheduleNotifs(); } catch (e) { toast("الرمز غير صحيح"); } });
  let resetArmed = false;
  $("#set-reset").addEventListener("click", (e) => {
    if (!resetArmed) { resetArmed = true; e.target.textContent = "اضغط مرة ثانية للتأكيد"; setTimeout(() => { resetArmed = false; e.target.textContent = "مسح"; }, 4000); return; }
    const keep = { rate: state.rate, goal: state.goal };
    state = Object.assign(fresh(), keep); save(); resetArmed = false; e.target.textContent = "مسح";
    closeSettings(); location.hash = "path"; route(); toast("تم مسح التقدم");
  });

  /* ---------------- تشغيل ---------------- */
  setSync(false);
  route();
  initCloud();
  initSample();
  scheduleNotifs();

  /* للاختبار فقط */
  window.__jisr = { lookup, levelInfo, merge, WORDS, UNITS, exportCode, importCode };
})();
