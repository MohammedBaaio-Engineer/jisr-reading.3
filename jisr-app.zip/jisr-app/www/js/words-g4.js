/* بنك المفردات — الكلمات العامة (4): كلمات الكتب والمقالات */
window.WORDBANK_RAW = window.WORDBANK_RAW || [];
window.WORDBANK_RAW.push({ cat: "general", title: "كلمات المقالات والتقارير", text: `
according|وفقاً|According to experts, sleep matters.
significant|كبير / مهم|A significant change.
significantly|بشكل كبير|Errors dropped significantly.
relevant|ذو صلة|Find relevant information.
essential|أساسي / ضروري|Practice is essential.
crucial|حاسم|Security is crucial.
primary|أساسي / أولي|The primary goal.
secondary|ثانوي|A secondary reason.
obvious|واضح|The answer is obvious.
apparent|ظاهر / واضح|It became apparent that it failed.
potential|محتمل / إمكانية|A potential problem.
likely|محتمل|It is likely to work.
unlikely|غير محتمل|It is unlikely to fail.
previous|سابق|Previous studies show this.
recent|حديث|A recent report.
further|إضافي / أبعد|For further information, visit our site.
additional|إضافي|Additional costs.
alternative|بديل|An alternative solution.
appropriate|مناسب|Choose an appropriate method.
sufficient|كافٍ|Sufficient time.
adequate|كافٍ / ملائم|Adequate security.
efficient|فعّال|An efficient process.
effective|مؤثر / فعّال|An effective way to learn.
accurate|دقيق|Accurate information.
consistent|ثابت / متسق|Be consistent.
constant|ثابت / مستمر|Constant practice.
continuous|مستمر|Continuous learning.
frequent|متكرر|Frequent updates.
gradual|تدريجي|Gradual progress.
rapid|سريع|Rapid growth.
massive|ضخم|A massive attack.
minor|بسيط / ثانوي|A minor bug.
negative|سلبي|A negative effect.
positive|إيجابي|A positive result.
neutral|محايد|A neutral opinion.
independent|مستقل|An independent study.
individual|فردي / فرد|Each individual learns differently.
general|عام|General information.
particular|معين / خاص|In particular.
specific|محدد|A specific goal.
various|متنوع|Various tools.
numerous|عديد|Numerous examples.
entire|كامل|The entire system.
overall|إجمالي / عموماً|Overall, it's good.
relative|نسبي|Relative speed.
absolute|مطلق|Absolute path.
direct|مباشر|A direct link.
indirect|غير مباشر|An indirect effect.
official|رسمي|The official website.
standard|قياسي|Standard settings.
` });

window.WORDBANK_RAW.push({ cat: "general", title: "أفعال القراءة الأكاديمية", text: `
argue|يحتج / يرى|The author argues that reading is key.
assess|يقيّم|Assess your level.
cite|يستشهد|Cite your sources.
clarify|يوضح|Can you clarify this point?
classify|يصنّف|Classify the words.
comprise|يتألف من|The book comprises ten chapters.
confirm|يؤكد|The results confirm our idea.
consult|يستشير|Consult the documentation.
contrast|يقارن بالتضاد|Contrast the two methods.
criticize|ينتقد|Critics criticized the design.
discuss|يناقش|This chapter discusses networks.
display|يعرض|The table displays the results.
emphasize|يشدد على|He emphasized the main point.
evaluate|يقيم|Evaluate the options.
expand|يتوسع في|Let me expand on this idea.
explain|يوضح|The figure explains the process.
highlight|يبرز|The report highlights three problems.
illustrate|يوضح بمثال|This example illustrates the rule.
indicate|يدل على|The results indicate success.
interpret|يفسر|How do you interpret this?
list|يسرد|The table lists all commands.
outline|يلخص الخطوط العريضة|The first chapter outlines the course.
propose|يقترح|We propose a new method.
prove|يبرهن|They proved the theory.
question|يشكك في|Some experts question this idea.
quote|يقتبس|He quoted the president.
recall|يتذكر / يسترجع|Recall the previous lesson.
reflect|يعكس|The results reflect our effort.
relate|يرتبط|How does this relate to security?
review|يراجع|Review the chapter.
state|يصرّح / ينص|The rule states that...
suggest|يشير / يقترح|The data suggests a problem.
summarize|يلخص|Summarize the article.
support|يدعم|The evidence supports the idea.
survey|استطلاع / يستطلع|A survey of 1000 users.
underline|يضع خطاً تحت|Underline the main verb.
verify|يتحقق|Verify the information.
assume|يفترض|We assume the user is online.
conclude|يخلص إلى|The study concludes that...
compare|يقارن|Compare the results.
contrast with|يتناقض مع|This contrasts with the old method.
deal|يتناول (deal with)|This book deals with security.
focus|يركز|The course focuses on reading.
address|يعالج / يتناول|The update addresses several bugs.
cover|يغطي|We will cover this in Chapter 5.
present|يعرض|The author presents two ideas.
introduce|يقدّم|This chapter introduces Linux.
examine|يدرس / يفحص|We will examine three cases.
explore|يستكشف|Let's explore the options.
` });

window.WORDBANK_RAW.push({ cat: "general", title: "كلمات القصص والحياة", text: `
journey|رحلة|Learning is a journey.
adventure|مغامرة|An exciting adventure.
travel|يسافر|I travel for work.
trip|رحلة قصيرة|A business trip.
visit|يزور|Visit our website.
explore|يستكشف|Explore the city.
discover|يكتشف|Discover new books.
memory|ذكرى|A happy memory.
childhood|الطفولة|My childhood was simple.
youth|الشباب|In my youth, I loved books.
adult|بالغ|Adults can learn languages too.
generation|جيل|The new generation.
neighbor|جار|My neighbor is a teacher.
stranger|غريب|Don't trust strangers online.
guest|ضيف|Welcome, guest!
crowd|حشد|A large crowd.
hero|بطل|The hero of the story.
enemy|عدو|Fear is the enemy of learning.
secret|سر|The secret is practice.
mystery|لغز|An unsolved mystery.
surprise|مفاجأة|What a surprise!
celebrate|يحتفل|Celebrate small wins.
holiday|عطلة|Summer holiday.
weekend|نهاية الأسبوع|Have a nice weekend.
routine|روتين|A daily routine.
habit|عادة|Good habits.
goal|هدف|Set a goal.
dream|حلم|Follow your dream.
effort|جهد|Every effort counts.
patience|صبر|Learning needs patience.
courage|شجاعة|It takes courage to start.
honest|صادق|Be honest with yourself.
kind|لطيف|A kind teacher.
polite|مهذب|A polite email.
rude|وقح|A rude comment.
brave|شجاع|Be brave and start.
lazy|كسول|Don't be lazy today.
busy|مشغول|I'm busy at work.
alone|وحيداً|I study alone.
together|معاً|Let's learn together.
lonely|وحيد / منعزل|He felt lonely.
famous|مشهور|A famous writer.
ordinary|عادي|An ordinary day.
unusual|غير عادي|An unusual idea.
strange|غريب|A strange error.
familiar|مألوف|This word looks familiar.
foreign|أجنبي|A foreign language.
native|أصلي / من أهل اللغة|A native speaker.
fluent|طليق|Fluent in English.
fluently|بطلاقة|Read fluently.
` });
