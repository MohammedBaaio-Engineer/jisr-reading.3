/* الدروس — الجزء الثاني (المراحل 4 إلى 6) */
window.LESSONS.push(
/* ================= المرحلة 4 ================= */
{
  id: "l15", stage: "s4", title: "أساسيات لغة الشبكات", minutes: 10,
  explain: `
  <p>كورسات الشبكات تستخدم مجموعة كلمات صغيرة لكنها تتكرر في كل درس. إذا ثبتت في ذهنك ستفهم 70% من أي شرح.</p>
  <table class="mini" dir="ltr"><tr><th>الكلمة</th><th dir="rtl">المعنى</th></tr>
  <tr><td>packet</td><td dir="rtl">حزمة بيانات</td></tr>
  <tr><td>router / switch</td><td dir="rtl">موجّه / مبدّل</td></tr>
  <tr><td>IP address</td><td dir="rtl">عنوان الجهاز في الشبكة</td></tr>
  <tr><td>port</td><td dir="rtl">منفذ (رقم الخدمة)</td></tr>
  <tr><td>protocol</td><td dir="rtl">بروتوكول: قواعد التواصل</td></tr>
  <tr><td>bandwidth</td><td dir="rtl">عرض النطاق: كمية البيانات الممكنة</td></tr>
  <tr><td>latency</td><td dir="rtl">زمن التأخير</td></tr>
  <tr><td>host</td><td dir="rtl">جهاز مضيف</td></tr>
  <tr><td>gateway</td><td dir="rtl">بوابة الخروج من الشبكة</td></tr></table>
  <p>لاحظ أن الكورسات تشرح بالتشبيه كثيراً: <span class="en">Think of a router as a post office</span> = تخيّل الموجّه كمكتب بريد. عبارة <span class="en">think of X as Y</span> تعني: افهم X على أنه Y.</p>`,
  examples: [
    { en: "Data is divided into small packets before it is sent across the network.", ar: "تُقسم البيانات إلى حزم صغيرة قبل إرسالها عبر الشبكة.", note: "is divided / is sent: مبني للمجهول" },
    { en: "Web servers usually listen on port 443 for HTTPS traffic.", ar: "خوادم الويب عادة تستمع على المنفذ 443 لحركة HTTPS.", note: "traffic = حركة البيانات" },
    { en: "High latency causes delays in video calls, even with good bandwidth.", ar: "زمن التأخير العالي يسبب تأخيراً في مكالمات الفيديو حتى مع عرض نطاق جيد.", note: "even with = حتى مع" }
  ],
  reading: {
    title: "How Data Travels",
    paras: [
      { en: "Think of a router as a post office. Every packet carries a source address and a destination address, just like a letter.", ar: "تخيّل الموجّه كمكتب بريد. كل حزمة تحمل عنوان مصدر وعنوان وجهة، تماماً مثل الرسالة البريدية." },
      { en: "When a packet arrives, the router checks the destination IP address and forwards the packet to the next router on the path.", ar: "عندما تصل حزمة، يفحص الموجّه عنوان IP للوجهة ويمرر الحزمة إلى الموجّه التالي في المسار." },
      { en: "If a packet is lost along the way, protocols such as TCP detect the loss and send the packet again. UDP, in contrast, does not resend lost packets, which makes it faster but less reliable.", ar: "إذا فُقدت حزمة في الطريق، تكتشف بروتوكولات مثل TCP الفقد وترسل الحزمة مجدداً. أما UDP فلا يعيد إرسال الحزم المفقودة، مما يجعله أسرع لكن أقل موثوقية." }
    ]
  },
  vocab: [["packet","حزمة"],["router","موجّه (راوتر)"],["switch","مبدّل"],["port","منفذ"],["protocol","بروتوكول"],["bandwidth","عرض النطاق"],["latency","زمن التأخير"],["host","مضيف"],["gateway","بوابة"],["traffic","حركة البيانات"],["source","مصدر"],["destination","وجهة"],["forward","يمرّر / يعيد توجيه"],["detect","يكتشف"],["reliable","موثوق"],["in contrast","في المقابل"],["think of","تخيّل / افهم على أنه"],["along the way","في الطريق"]],
  quiz: [
    { q: "ما الفرق بين TCP و UDP حسب النص؟", o: ["UDP يعيد إرسال الحزم المفقودة","TCP يعيد إرسال الحزم المفقودة و UDP لا","كلاهما لا يعيد","TCP أسرع"], a: 1, why: "TCP detect the loss and send again. UDP does not resend." },
    { q: "ماذا يفحص الموجّه عند وصول حزمة؟", o: ["حجم الحزمة","عنوان IP للوجهة","كلمة المرور","المنفذ فقط"], a: 1, why: "the router checks the destination IP address." },
    { q: "Think of a router as a post office تعني:", o: ["الموجّه يرسل رسائل بريدية","تخيّل الموجّه كأنه مكتب بريد","اشترِ موجّهاً من البريد","فكّر في مكتب البريد"], a: 1, why: "think of X as Y = تخيّل X على أنه Y." }
  ]
},
{
  id: "l16", stage: "s4", title: "مصطلحات أمن المعلومات", minutes: 10,
  explain: `
  <p>في الأمن، كلمات متقاربة لها معانٍ مختلفة بدقة. الخلط بينها يربك فهم أي كورس:</p>
  <table class="mini" dir="ltr"><tr><th>الكلمة</th><th dir="rtl">المعنى الدقيق</th></tr>
  <tr><td>vulnerability</td><td dir="rtl">ثغرة: نقطة ضعف موجودة</td></tr>
  <tr><td>threat</td><td dir="rtl">تهديد: خطر محتمل</td></tr>
  <tr><td>exploit</td><td dir="rtl">استغلال الثغرة (أو الكود الذي يستغلها)</td></tr>
  <tr><td>attack</td><td dir="rtl">هجوم فعلي</td></tr>
  <tr><td>breach</td><td dir="rtl">اختراق: نجح الهجوم ووصل للبيانات</td></tr>
  <tr><td>patch</td><td dir="rtl">ترقيع / تحديث يسد الثغرة</td></tr>
  <tr><td>encryption</td><td dir="rtl">تشفير</td></tr>
  <tr><td>authentication / authorization</td><td dir="rtl">من أنت؟ / ماذا يحق لك؟</td></tr>
  <tr><td>phishing</td><td dir="rtl">تصيّد: خداع لسرقة البيانات</td></tr>
  <tr><td>malware</td><td dir="rtl">برمجيات خبيثة</td></tr></table>
  <p><b>الفرق المهم:</b> <span class="en">authentication</span> يتحقق من هويتك، و<span class="en">authorization</span> يحدد صلاحياتك بعد الدخول.</p>`,
  examples: [
    { en: "Attackers exploited a vulnerability in the login form.", ar: "استغل المهاجمون ثغرة في نموذج تسجيل الدخول.", note: "exploited = استغلوا" },
    { en: "The company confirmed a data breach affecting 2 million users.", ar: "أكدت الشركة اختراق بيانات يؤثر على مليوني مستخدم.", note: "affecting = يؤثر على" },
    { en: "Apply the security patch as soon as possible.", ar: "طبّق ترقيع الأمان في أسرع وقت ممكن.", note: "as soon as possible (ASAP) = بأسرع وقت" }
  ],
  reading: {
    title: "What Is Phishing?",
    paras: [
      { en: "Phishing is a type of social engineering attack in which criminals pretend to be a trusted company in order to trick you into revealing sensitive information.", ar: "التصيّد نوع من هجمات الهندسة الاجتماعية يتظاهر فيه المجرمون بأنهم شركة موثوقة لخداعك ودفعك لكشف معلومات حساسة." },
      { en: "A typical phishing email creates a sense of urgency, for example: \"Your account will be suspended within 24 hours.\" It then asks you to click a link and enter your password.", ar: "رسالة التصيد المعتادة تخلق شعوراً بالاستعجال، مثلاً: \"سيُعلق حسابك خلال 24 ساعة.\" ثم تطلب منك الضغط على رابط وإدخال كلمة المرور." },
      { en: "To protect yourself, always check the sender's address carefully and never enter your credentials on a page you reached through an email link.", ar: "لحماية نفسك، افحص عنوان المرسل بعناية دائماً، ولا تُدخل بيانات دخولك أبداً في صفحة وصلت إليها عبر رابط في بريد." }
    ]
  },
  vocab: [["vulnerability","ثغرة"],["threat","تهديد"],["exploit","يستغل / استغلال"],["attack","هجوم"],["breach","اختراق"],["patch","ترقيع أمني"],["encryption","تشفير"],["authorization","التفويض / الصلاحيات"],["phishing","تصيّد احتيالي"],["malware","برمجيات خبيثة"],["social engineering","الهندسة الاجتماعية"],["pretend","يتظاهر"],["trusted","موثوق"],["trick","يخدع"],["reveal","يكشف"],["sensitive","حساس"],["urgency","استعجال"],["suspend","يعلّق / يوقف"],["credentials","بيانات الدخول"],["sender","المرسل"]],
  quiz: [
    { q: "ما الفرق بين vulnerability و breach؟", o: ["نفس المعنى","الثغرة نقطة ضعف، والاختراق نجاح الوصول للبيانات","breach أخف من vulnerability","vulnerability هجوم فعلي"], a: 1, why: "vulnerability موجودة قبل أي هجوم، breach يعني أن الهجوم نجح." },
    { q: "ما الحيلة النفسية المعتادة في رسائل التصيد؟", o: ["الهدوء","خلق شعور بالاستعجال","تقديم هدية دائماً","لغة رسمية فقط"], a: 1, why: "creates a sense of urgency." },
    { q: "credentials تعني:", o: ["الشهادات الجامعية","بيانات الدخول مثل اسم المستخدم وكلمة المرور","بطاقة الائتمان فقط","رسالة البريد"], a: 1, why: "في سياق الأمن credentials = بيانات الدخول." }
  ]
},
{
  id: "l17", stage: "s4", title: "قراءة تقرير ثغرة أمنية", minutes: 9,
  explain: `
  <p>تقارير الثغرات (Security Advisories) مكتوبة بقالب ثابت. اقرأها كأنها استمارة:</p>
  <table class="mini" dir="ltr"><tr><th>الحقل</th><th dir="rtl">ماذا يخبرك</th></tr>
  <tr><td>Severity: Critical / High / Medium / Low</td><td dir="rtl">درجة الخطورة</td></tr>
  <tr><td>Affected versions</td><td dir="rtl">الإصدارات المتأثرة</td></tr>
  <tr><td>Patched / Fixed in</td><td dir="rtl">الإصدار الذي يحتوي الإصلاح</td></tr>
  <tr><td>Impact</td><td dir="rtl">ماذا يستطيع المهاجم فعله</td></tr>
  <tr><td>Mitigation / Workaround</td><td dir="rtl">ما تفعله إن لم تستطع التحديث الآن</td></tr>
  <tr><td>CVE-2026-12345</td><td dir="rtl">الرقم العالمي للثغرة</td></tr></table>
  <p>عبارات تنبيه: <span class="en">prior to</span> = قبل، <span class="en">and earlier</span> = وما قبله، <span class="en">remote</span> = عن بُعد، <span class="en">arbitrary code</span> = كود عشوائي يختاره المهاجم.</p>`,
  examples: [
    { en: "Versions prior to 4.2.1 are affected.", ar: "الإصدارات الأقدم من 4.2.1 متأثرة.", note: "prior to = قبل" },
    { en: "A remote attacker could execute arbitrary code.", ar: "قد يتمكن مهاجم عن بُعد من تنفيذ كود يختاره.", note: "could = قد يستطيع" },
    { en: "There is no known workaround. Users are advised to upgrade immediately.", ar: "لا يوجد حل التفافي معروف. يُنصح المستخدمون بالترقية فوراً.", note: "are advised = يُنصحون" }
  ],
  reading: {
    title: "Security Advisory: ImageKit Upload Module",
    paras: [
      { en: "Severity: High. A vulnerability in the upload module allows an unauthenticated user to upload files of any type to the server.", ar: "الخطورة: عالية. ثغرة في وحدة الرفع تسمح لمستخدم غير مسجل الدخول برفع ملفات من أي نوع إلى الخادم." },
      { en: "Affected versions: 2.0.0 through 2.3.4. The issue has been fixed in version 2.3.5.", ar: "الإصدارات المتأثرة: من 2.0.0 حتى 2.3.4. تم إصلاح المشكلة في الإصدار 2.3.5." },
      { en: "Mitigation: if you cannot upgrade right away, disable public uploads in the settings and restrict the allowed file extensions to images only.", ar: "التخفيف: إذا لم تستطع الترقية فوراً، عطّل الرفع العام من الإعدادات وقصر امتدادات الملفات المسموحة على الصور فقط." }
    ]
  },
  vocab: [["advisory","تقرير / تنبيه أمني"],["severity","درجة الخطورة"],["critical","حرج"],["affected","متأثر"],["impact","التأثير"],["mitigation","التخفيف"],["prior to","قبل"],["remote","عن بُعد"],["arbitrary","عشوائي / أي شيء"],["execute","ينفّذ"],["advised","يُنصح"],["upgrade","يرقّي"],["immediately","فوراً"],["unauthenticated","غير مسجل / غير موثّق"],["through","حتى (في نطاق)"],["restrict","يقيّد"],["extension","امتداد (ملف)"],["right away","حالاً"]],
  quiz: [
    { q: "أنت تستخدم الإصدار 2.3.4، ماذا تفعل؟", o: ["لا شيء، أنت آمن","ترقّي إلى 2.3.5","تنزل إلى 2.0.0","تحذف الخادم"], a: 1, why: "2.0.0 through 2.3.4 متأثرة، والإصلاح في 2.3.5." },
    { q: "ما الذي تسمح به الثغرة؟", o: ["سرقة كلمات المرور","رفع ملفات من أي نوع بدون تسجيل دخول","حذف قاعدة البيانات","إبطاء الخادم"], a: 1, why: "allows an unauthenticated user to upload files of any type." },
    { q: "Mitigation تعني:", o: ["الإصلاح النهائي","إجراء لتخفيف الخطر مؤقتاً","سبب الثغرة","اسم المهاجم"], a: 1, why: "mitigation = تقليل الخطر إلى أن تستطيع الإصلاح الكامل." }
  ]
},

/* ================= المرحلة 5 ================= */
{
  id: "l18", stage: "s5", title: "فهم صفحة الكورس قبل الشراء", minutes: 8,
  explain: `
  <p>منصات الكورسات كلها تستخدم نفس الأقسام تقريباً. اعرفها لتقرر بسرعة إن كان الكورس مناسباً:</p>
  <table class="mini" dir="ltr"><tr><th>القسم</th><th dir="rtl">المعنى</th></tr>
  <tr><td>What you'll learn</td><td dir="rtl">ما ستتعلمه</td></tr>
  <tr><td>Requirements</td><td dir="rtl">المتطلبات</td></tr>
  <tr><td>Who this course is for</td><td dir="rtl">لمن هذا الكورس</td></tr>
  <tr><td>Course content: 12 sections • 140 lectures</td><td dir="rtl">المحتوى: 12 قسماً • 140 محاضرة</td></tr>
  <tr><td>Bestseller / Highest rated</td><td dir="rtl">الأكثر مبيعاً / الأعلى تقييماً</td></tr>
  <tr><td>Last updated 10/2026</td><td dir="rtl">آخر تحديث (مهم في التقنية!)</td></tr>
  <tr><td>Lifetime access</td><td dir="rtl">وصول مدى الحياة</td></tr>
  <tr><td>Certificate of completion</td><td dir="rtl">شهادة إتمام</td></tr>
  <tr><td>30-day money-back guarantee</td><td dir="rtl">ضمان استرداد المال خلال 30 يوماً</td></tr></table>`,
  examples: [
    { en: "This course is not for experienced developers.", ar: "هذا الكورس ليس للمطورين ذوي الخبرة.", note: "اقرأ Who this course is for قبل الشراء" },
    { en: "Preview this course", ar: "شاهد معاينة لهذا الكورس", note: "preview = معاينة مجانية" },
    { en: "Enroll now and start learning today.", ar: "سجّل الآن وابدأ التعلم اليوم.", note: "enroll = يلتحق / يسجل في كورس" }
  ],
  reading: {
    title: "The Complete Ethical Hacking Bootcamp",
    paras: [
      { en: "Learn ethical hacking from scratch and practice on your own safe lab. No prior knowledge is required: we start with the basics of networking and Linux.", ar: "تعلّم الاختراق الأخلاقي من الصفر وتدرّب في مختبرك الآمن. لا يلزم معرفة سابقة: نبدأ بأساسيات الشبكات ولينكس." },
      { en: "By the end of this course, you will be able to identify common vulnerabilities, perform basic penetration tests and write a professional report.", ar: "في نهاية هذا الكورس ستكون قادراً على تحديد الثغرات الشائعة، وتنفيذ اختبارات اختراق أساسية، وكتابة تقرير احترافي." },
      { en: "Who this course is for: beginners interested in cyber security, and IT staff who want to protect their company's network. This course is not intended for advanced penetration testers.", ar: "لمن هذا الكورس: المبتدئون المهتمون بالأمن السيبراني، وموظفو تقنية المعلومات الذين يريدون حماية شبكة شركتهم. هذا الكورس غير موجه لمختبري الاختراق المتقدمين." }
    ]
  },
  vocab: [["enroll","يلتحق / يسجل"],["lecture","محاضرة"],["bestseller","الأكثر مبيعاً"],["rating","تقييم"],["lifetime access","وصول مدى الحياة"],["certificate","شهادة"],["money-back guarantee","ضمان استرداد المال"],["preview","معاينة"],["ethical hacking","الاختراق الأخلاقي"],["lab","مختبر"],["by the end of","في نهاية"],["be able to","يكون قادراً على"],["identify","يحدد / يتعرف على"],["perform","ينفّذ / يؤدي"],["penetration test","اختبار اختراق"],["intended for","موجّه لـ"],["advanced","متقدم"],["staff","موظفون"]],
  quiz: [
    { q: "هل يناسب الكورس مختبر اختراق محترف؟", o: ["نعم تماماً","لا، غير موجه للمتقدمين","فقط إن دفع أكثر","غير مذكور"], a: 1, why: "This course is not intended for advanced penetration testers." },
    { q: "بماذا يبدأ الكورس؟", o: ["كتابة التقارير","أساسيات الشبكات ولينكس","الاختراق المتقدم","البرمجة بلغة C"], a: 1, why: "we start with the basics of networking and Linux." },
    { q: "ما معنى Enroll now؟", o: ["سجّل الآن في الكورس","أكمل الآن","ادفع لاحقاً","ألغِ الاشتراك"], a: 0, why: "enroll = الالتحاق بالكورس." }
  ]
},
{
  id: "l19", stage: "s5", title: "لغة المحاضر في الفيديو", minutes: 10,
  explain: `
  <p>المحاضر يتكلم بلغة <b>منطوقة</b> فيها عبارات حشو وانتقال. فعّل الترجمة النصية (Subtitles / CC) واقرأ مع الاستماع. هذه العبارات ستسمعها في كل كورس:</p>
  <table class="mini" dir="ltr"><tr><th>العبارة</th><th dir="rtl">المعنى الحقيقي</th></tr>
  <tr><td>Let's go ahead and...</td><td dir="rtl">هيا نقوم بـ... (ابدأ الخطوة)</td></tr>
  <tr><td>As you can see</td><td dir="rtl">كما ترى على الشاشة</td></tr>
  <tr><td>Under the hood</td><td dir="rtl">ما يحدث في الداخل</td></tr>
  <tr><td>We'll cover that later</td><td dir="rtl">سنشرح ذلك لاحقاً (لا تقلق الآن)</td></tr>
  <tr><td>Pause the video and try it</td><td dir="rtl">أوقف الفيديو وجرّب بنفسك</td></tr>
  <tr><td>Don't worry if this seems confusing</td><td dir="rtl">لا تقلق إن بدا هذا مربكاً</td></tr>
  <tr><td>Pretty much / basically</td><td dir="rtl">تقريباً / ببساطة (حشو)</td></tr>
  <tr><td>Recap / To sum up</td><td dir="rtl">مراجعة / للتلخيص</td></tr></table>
  <p><b>نصيحة:</b> اجعل سرعة الفيديو 0.75x في البداية، وانسخ النص المكتوب (Transcript) إلى <b>المحلل</b> في هذا الموقع.</p>`,
  examples: [
    { en: "So let's go ahead and create a new file called app.js.", ar: "إذن هيا ننشئ ملفاً جديداً اسمه app.js.", note: "so في بداية الكلام حشو، تعني: إذن" },
    { en: "Under the hood, the browser converts this into an HTTP request.", ar: "في الداخل، يحوّل المتصفح هذا إلى طلب HTTP.", note: "" },
    { en: "Don't worry about this part for now, we'll come back to it.", ar: "لا تقلق بشأن هذا الجزء الآن، سنعود إليه.", note: "for now = في الوقت الحالي" }
  ],
  reading: {
    title: "Lecture 14 — Transcript",
    paras: [
      { en: "Alright, welcome back. In the previous lecture we set up our server, and in this one we're going to connect it to a database.", ar: "حسناً، مرحباً بعودتك. في المحاضرة السابقة أعددنا الخادم، وفي هذه سنربطه بقاعدة بيانات." },
      { en: "So let's go ahead and open the terminal. As you can see, the server is still running from last time, so I'm just going to stop it with Control C.", ar: "إذن هيا نفتح الطرفية. كما ترى، الخادم لا يزال يعمل من المرة السابقة، لذلك سأوقفه بـ Control C." },
      { en: "Now, this next part might look a bit confusing at first, but don't worry, I'll explain what's happening under the hood in a moment. Feel free to pause the video and type along with me.", ar: "الآن، الجزء التالي قد يبدو مربكاً قليلاً في البداية، لكن لا تقلق، سأشرح ما يحدث في الداخل بعد لحظة. لا تتردد في إيقاف الفيديو والكتابة معي." }
    ]
  },
  vocab: [["go ahead","تفضل / نبدأ"],["as you can see","كما ترى"],["under the hood","في الداخل / خلف الكواليس"],["cover","يشرح / يغطي"],["pause","يوقف مؤقتاً"],["confusing","مربك"],["basically","ببساطة / أساساً"],["recap","مراجعة سريعة"],["welcome back","مرحباً بعودتك"],["set up","يُعدّ / يجهّز"],["in a moment","بعد لحظة"],["feel free to","لا تتردد في"],["type along","اكتب معي"],["at first","في البداية"],["for now","حالياً"],["a bit","قليلاً"]],
  quiz: [
    { q: "ماذا فعلوا في المحاضرة السابقة؟", o: ["ربطوا قاعدة البيانات","أعدّوا الخادم","حذفوا الخادم","كتبوا اختباراً"], a: 1, why: "In the previous lecture we set up our server." },
    { q: "Feel free to pause the video تعني:", o: ["ممنوع إيقاف الفيديو","لا تتردد في إيقاف الفيديو","الفيديو مجاني","أعد الفيديو"], a: 1, why: "feel free to = لا تتردد في." },
    { q: "ماذا سيحدث في هذه المحاضرة؟", o: ["ربط الخادم بقاعدة بيانات","تثبيت ويندوز","حذف الطرفية","شرح CSS"], a: 0, why: "in this one we're going to connect it to a database." }
  ]
},
{
  id: "l20", stage: "s5", title: "تعليمات التمارين والاختبارات", minutes: 7,
  explain: `
  <p>أكثر شيء يضيّع الدرجات في الكورسات ليس صعوبة السؤال، بل <b>سوء فهم التعليمات</b>. احفظ هذه:</p>
  <table class="mini" dir="ltr"><tr><th>التعليمات</th><th dir="rtl">المطلوب</th></tr>
  <tr><td>Which of the following...</td><td dir="rtl">أيٌّ مما يلي...</td></tr>
  <tr><td>Select all that apply</td><td dir="rtl">اختر كل الإجابات الصحيحة (أكثر من واحدة)</td></tr>
  <tr><td>Which is NOT...</td><td dir="rtl">أيها ليس... (انتبه للنفي!)</td></tr>
  <tr><td>True or False</td><td dir="rtl">صح أم خطأ</td></tr>
  <tr><td>Fill in the blank</td><td dir="rtl">املأ الفراغ</td></tr>
  <tr><td>Passing grade: 80%</td><td dir="rtl">درجة النجاح 80%</td></tr>
  <tr><td>Attempts remaining: 2</td><td dir="rtl">المحاولات المتبقية: 2</td></tr>
  <tr><td>Due date / Deadline</td><td dir="rtl">موعد التسليم</td></tr>
  <tr><td>Submit</td><td dir="rtl">أرسل / سلّم</td></tr></table>`,
  examples: [
    { en: "Which of the following is NOT a valid HTTP method?", ar: "أيٌّ مما يلي ليس طريقة HTTP صالحة؟", note: "NOT مكتوبة بحروف كبيرة لتنبهك" },
    { en: "You must score at least 70% to pass this quiz.", ar: "يجب أن تحصل على 70% على الأقل لتنجح في هذا الاختبار.", note: "at least = على الأقل" },
    { en: "Your assignment is due on Friday at 11:59 PM.", ar: "موعد تسليم واجبك الجمعة الساعة 11:59 مساءً.", note: "assignment = واجب / مهمة" }
  ],
  reading: {
    title: "Module 3 Quiz — Instructions",
    paras: [
      { en: "This quiz contains 10 questions. You have 20 minutes to complete it once you start, and the timer cannot be paused.", ar: "يحتوي هذا الاختبار على 10 أسئلة. لديك 20 دقيقة لإكماله بمجرد أن تبدأ، ولا يمكن إيقاف المؤقت." },
      { en: "Some questions have more than one correct answer. For these questions, select all that apply. Partial answers receive no points.", ar: "بعض الأسئلة لها أكثر من إجابة صحيحة. في هذه الأسئلة اختر كل ما ينطبق. الإجابات الجزئية لا تحصل على نقاط." },
      { en: "You need 80% to pass. You may retake the quiz up to three times, and only your highest score will count.", ar: "تحتاج 80% للنجاح. يمكنك إعادة الاختبار حتى ثلاث مرات، وتُحتسب أعلى درجة فقط." }
    ]
  },
  vocab: [["which of the following","أيٌّ مما يلي"],["select all that apply","اختر كل ما ينطبق"],["fill in the blank","املأ الفراغ"],["passing grade","درجة النجاح"],["attempt","محاولة"],["remaining","متبقٍ"],["due","مستحق / موعد التسليم"],["deadline","الموعد النهائي"],["submit","يسلّم / يرسل"],["assignment","واجب"],["score","درجة / يحرز"],["at least","على الأقل"],["once","بمجرد أن"],["partial","جزئي"],["retake","يعيد (الاختبار)"],["up to","حتى / بحد أقصى"],["count","يُحتسب"]],
  quiz: [
    { q: "إذا أجبت إجابة صحيحة واحدة فقط من اثنتين في سؤال Select all that apply؟", o: ["تحصل نصف الدرجة","لا تحصل على نقاط","تحصل الدرجة كاملة","يُعاد السؤال"], a: 1, why: "Partial answers receive no points." },
    { q: "كم مرة يمكنك إعادة الاختبار؟", o: ["مرة واحدة","حتى ثلاث مرات","بلا حدود","لا يمكن"], a: 1, why: "You may retake the quiz up to three times." },
    { q: "هل يمكن إيقاف المؤقت؟", o: ["نعم","لا","فقط مرة","بعد 10 دقائق"], a: 1, why: "the timer cannot be paused." }
  ]
},

/* ================= المرحلة 6 ================= */
{
  id: "l21", stage: "s6", title: "قراءة مقال ويكيبيديا", minutes: 9,
  explain: `
  <p>مقالات ويكيبيديا الإنجليزية تبدأ دائماً بجملة تعريف بنفس القالب:</p>
  <p class="formula" dir="ltr">X is a/an [category] that/which [what it does].</p>
  <p>إذا فهمت <b>الجملة الأولى</b> فهمت جوهر المقال. بعدها تأتي أقسام ثابتة: <span class="en">History</span> (التاريخ)، <span class="en">Overview</span> (نظرة عامة)، <span class="en">See also</span> (انظر أيضاً)، <span class="en">References</span> (المراجع).</p>
  <p>عبارات شائعة: <span class="en">is known for</span> = مشهور بـ، <span class="en">was founded in</span> = تأسس عام، <span class="en">also referred to as</span> = يُسمى أيضاً، <span class="en">is widely used</span> = يُستخدم على نطاق واسع.</p>`,
  examples: [
    { en: "Linux is a family of open-source operating systems based on the Linux kernel.", ar: "لينكس عائلة من أنظمة التشغيل مفتوحة المصدر مبنية على نواة لينكس.", note: "is a family of = عائلة من" },
    { en: "The company was founded in 1998 and is headquartered in California.", ar: "تأسست الشركة عام 1998 ومقرها الرئيسي في كاليفورنيا.", note: "headquartered = مقرها الرئيسي" },
    { en: "JavaScript, often abbreviated as JS, is widely used for web development.", ar: "جافاسكربت، وتُختصر غالباً إلى JS، تُستخدم على نطاق واسع في تطوير الويب.", note: "abbreviated = مختصر" }
  ],
  reading: {
    title: "Encryption (Wikipedia style)",
    paras: [
      { en: "In cryptography, encryption is the process of transforming information into a form that only authorized parties can read.", ar: "في علم التشفير، التشفير هو عملية تحويل المعلومات إلى شكل لا يقرأه إلا الأطراف المصرّح لها." },
      { en: "Historically, encryption was used mainly by the military and governments to keep messages secret. One of the earliest known examples is the Caesar cipher, which shifts each letter by a fixed number.", ar: "تاريخياً، استُخدم التشفير أساساً من الجيوش والحكومات لإبقاء الرسائل سرية. ومن أقدم الأمثلة المعروفة شيفرة قيصر التي تزيح كل حرف بعدد ثابت." },
      { en: "Today, encryption is widely used to protect online banking, messaging apps and almost every website that uses HTTPS.", ar: "اليوم، يُستخدم التشفير على نطاق واسع لحماية الخدمات المصرفية عبر الإنترنت وتطبيقات المراسلة وتقريباً كل موقع يستخدم HTTPS." }
    ]
  },
  vocab: [["is known for","مشهور بـ"],["was founded","تأسس"],["referred to as","يُشار إليه بـ"],["widely used","مستخدم على نطاق واسع"],["open-source","مفتوح المصدر"],["based on","مبني على"],["kernel","النواة"],["headquartered","مقره الرئيسي"],["abbreviated","مختصر"],["cryptography","علم التشفير"],["transform","يحوّل"],["authorized","مصرّح له"],["party","طرف"],["historically","تاريخياً"],["mainly","أساساً"],["secret","سري"],["cipher","شيفرة"],["shift","يزيح"],["almost","تقريباً"]],
  quiz: [
    { q: "حسب الجملة الأولى، ما التشفير؟", o: ["نوع من الفيروسات","عملية تحويل المعلومات لشكل لا يقرأه إلا المصرح لهم","برنامج حماية","موقع إلكتروني"], a: 1, why: "encryption is the process of transforming information into a form that only authorized parties can read." },
    { q: "كيف تعمل شيفرة قيصر؟", o: ["تحذف الحروف","تزيح كل حرف بعدد ثابت","تستخدم كلمات مرور","تعكس الكلمات"], a: 1, why: "shifts each letter by a fixed number." },
    { q: "is widely used تعني:", o: ["نادر الاستخدام","مستخدم على نطاق واسع","استُخدم قديماً فقط","ممنوع"], a: 1, why: "widely = على نطاق واسع." }
  ]
},
{
  id: "l22", stage: "s6", title: "فك شيفرة العناوين الإخبارية", minutes: 8,
  explain: `
  <p>عناوين الأخبار الإنجليزية تكسر القواعد عمداً لتوفير المساحة، وهذا يربك المتعلمين. اعرف الحيل الثلاث:</p>
  <p><b>1. حذف الكلمات الصغيرة:</b> <span class="en">Hackers Target Hospital Systems</span> = The hackers are targeting the hospital systems.</p>
  <p><b>2. المضارع يعني الماضي القريب:</b> <span class="en">Google Releases New AI Model</span> = أصدرت جوجل نموذجاً جديداً.</p>
  <p><b>3. to + فعل = مستقبل:</b> <span class="en">Apple To Launch Foldable iPhone</span> = ستطلق آبل...</p>
  <p><b>4. الفعل الثالث وحده = مبني للمجهول:</b> <span class="en">Millions Of Passwords Leaked</span> = تم تسريب ملايين كلمات المرور.</p>
  <p>كلمات إخبارية قصيرة: <span class="en">slams</span> = ينتقد بشدة، <span class="en">eyes</span> = يتطلع إلى، <span class="en">probe</span> = تحقيق، <span class="en">hit</span> = يضرب / يؤثر، <span class="en">amid</span> = وسط.</p>`,
  examples: [
    { en: "Major Bank Hit By Ransomware Attack", ar: "بنك كبير يتعرض لهجوم فدية", note: "Hit By = تعرّض لـ (مجهول)" },
    { en: "EU To Fine Tech Giant Over Data Privacy", ar: "الاتحاد الأوروبي سيغرّم عملاقاً تقنياً بسبب خصوصية البيانات", note: "To + فعل = مستقبل، over = بسبب" },
    { en: "Startup Raises $50M Amid AI Boom", ar: "شركة ناشئة تجمع 50 مليون دولار وسط طفرة الذكاء الاصطناعي", note: "raises = تجمع تمويلاً، amid = وسط" }
  ],
  reading: {
    title: "Tech News Today",
    paras: [
      { en: "Popular Browser Patches Critical Flaw Used In Attacks. The company says the vulnerability was actively exploited before the fix was released.", ar: "متصفح شهير يرقّع ثغرة حرجة استُخدمت في هجمات. تقول الشركة إن الثغرة كانت تُستغل فعلياً قبل نشر الإصلاح." },
      { en: "Government To Ban Weak Default Passwords On Smart Devices. Under the new law, every device must ship with a unique password.", ar: "الحكومة ستحظر كلمات المرور الافتراضية الضعيفة على الأجهزة الذكية. بموجب القانون الجديد، يجب أن يُشحن كل جهاز بكلمة مرور فريدة." },
      { en: "Cloud Outage Disrupts Thousands Of Websites. Engineers restored most services within four hours.", ar: "انقطاع في الخدمات السحابية يعطل آلاف المواقع. أعاد المهندسون معظم الخدمات خلال أربع ساعات." }
    ]
  },
  vocab: [["flaw","عيب / ثغرة"],["actively","فعلياً / بنشاط"],["ban","يحظر"],["weak","ضعيف"],["smart device","جهاز ذكي"],["under the law","بموجب القانون"],["ship","يُشحن / يُطرح"],["outage","انقطاع (خدمة)"],["disrupt","يعطّل"],["restore","يعيد / يستعيد"],["within","خلال"],["ransomware","برمجية فدية"],["fine","يغرّم / غرامة"],["privacy","الخصوصية"],["raise","يجمع (تمويلاً)"],["amid","وسط"],["boom","طفرة"],["leak","يسرّب"],["launch","يطلق"]],
  quiz: [
    { q: "Government To Ban Weak Default Passwords... هل الحظر حدث بالفعل؟", o: ["نعم حدث","لا، سيحدث مستقبلاً","حدث وأُلغي","غير واضح"], a: 1, why: "To + فعل في العناوين = مستقبل." },
    { q: "ماذا تعني outage؟", o: ["تحديث","انقطاع في الخدمة","هجوم","ترقية"], a: 1, why: "Cloud Outage Disrupts Thousands Of Websites = انقطاع." },
    { q: "Passwords Leaked معناها:", o: ["كلمات المرور تسرّب شيئاً","تم تسريب كلمات المرور","كلمات مرور قوية","كلمات مرور جديدة"], a: 1, why: "الفعل الثالث وحده في العنوان = مبني للمجهول." }
  ]
},
{
  id: "l23", stage: "s6", title: "المواقع اليومية: التسجيل والاشتراكات", minutes: 7,
  explain: `
  <p>قبل أن تصل للكورس، ستمر بنوافذ التسجيل والكوكيز والاشتراك. هذه العبارات تحميك من دفع ما لا تريده:</p>
  <table class="mini" dir="ltr"><tr><th>العبارة</th><th dir="rtl">المعنى</th></tr>
  <tr><td>Sign up / Sign in / Log out</td><td dir="rtl">إنشاء حساب / دخول / خروج</td></tr>
  <tr><td>Accept all cookies / Reject / Manage preferences</td><td dir="rtl">قبول الكوكيز / رفض / إدارة التفضيلات</td></tr>
  <tr><td>Free trial</td><td dir="rtl">تجربة مجانية</td></tr>
  <tr><td>Billed annually / monthly</td><td dir="rtl">يُدفع سنوياً / شهرياً</td></tr>
  <tr><td>Cancel anytime</td><td dir="rtl">ألغِ في أي وقت</td></tr>
  <tr><td>Auto-renew</td><td dir="rtl">تجديد تلقائي</td></tr>
  <tr><td>Verify your email</td><td dir="rtl">أكّد بريدك</td></tr>
  <tr><td>By continuing, you agree to our Terms</td><td dir="rtl">بالمتابعة توافق على شروطنا</td></tr></table>
  <p><b>انتبه دائماً لـ:</b> <span class="en">after the trial ends</span> و <span class="en">will be charged</span> = سيُخصم المبلغ.</p>`,
  examples: [
    { en: "Start your 7-day free trial. You will be charged $19.99/month after the trial ends.", ar: "ابدأ تجربتك المجانية 7 أيام. سيُخصم 19.99 دولار شهرياً بعد انتهاء التجربة.", note: "charged = يُخصم منك" },
    { en: "We sent a verification link to your email. It expires in 15 minutes.", ar: "أرسلنا رابط تأكيد إلى بريدك. تنتهي صلاحيته خلال 15 دقيقة.", note: "expires = تنتهي صلاحيته" },
    { en: "Already have an account? Sign in.", ar: "لديك حساب بالفعل؟ سجّل الدخول.", note: "" }
  ],
  reading: {
    title: "Choose Your Plan",
    paras: [
      { en: "Pro Plan: $12 per month, billed annually. Includes unlimited courses, offline downloads and certificates.", ar: "الخطة الاحترافية: 12 دولاراً شهرياً، تُدفع سنوياً. تشمل كورسات غير محدودة، وتنزيلات للمشاهدة دون إنترنت، وشهادات." },
      { en: "Your subscription will automatically renew at the end of each billing period unless you cancel at least 24 hours before.", ar: "سيتجدد اشتراكك تلقائياً في نهاية كل فترة فوترة ما لم تلغِ قبل 24 ساعة على الأقل." },
      { en: "By clicking Subscribe, you agree to our Terms of Service and confirm that you have read our Privacy Policy.", ar: "بالضغط على اشترك، فإنك توافق على شروط الخدمة وتؤكد أنك قرأت سياسة الخصوصية." }
    ]
  },
  vocab: [["sign up","إنشاء حساب"],["sign in","تسجيل الدخول"],["log out","تسجيل الخروج"],["cookies","ملفات تعريف الارتباط"],["preferences","التفضيلات"],["free trial","تجربة مجانية"],["billed annually","يُدفع سنوياً"],["cancel","يلغي"],["anytime","في أي وقت"],["renew","يجدد"],["charged","يُخصم / يُحاسب"],["verify","يؤكد / يتحقق"],["expire","تنتهي صلاحيته"],["agree","يوافق"],["terms of service","شروط الخدمة"],["privacy policy","سياسة الخصوصية"],["subscription","اشتراك"],["unlimited","غير محدود"],["offline","بدون إنترنت"],["billing period","فترة الفوترة"]],
  quiz: [
    { q: "billed annually تعني:", o: ["تدفع كل شهر","تدفع المبلغ مرة واحدة عن السنة","مجاني","تدفع يومياً"], a: 1, why: "annually = سنوياً: السعر محسوب شهرياً لكنك تدفعه دفعة واحدة سنوياً." },
    { q: "متى يجب أن تلغي حتى لا يتجدد الاشتراك؟", o: ["في أي وقت","قبل 24 ساعة على الأقل من نهاية الفترة","بعد التجديد","لا يمكن الإلغاء"], a: 1, why: "unless you cancel at least 24 hours before." },
    { q: "ماذا تؤكد عند الضغط على Subscribe؟", o: ["أنك قرأت سياسة الخصوصية وتوافق على الشروط","أنك تريد الإلغاء","أنك طالب","لا شيء"], a: 0, why: "you agree to our Terms of Service and confirm that you have read our Privacy Policy." }
  ]
}
);
