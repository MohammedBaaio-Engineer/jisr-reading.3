/* المحاكاة: شاشات مأخوذة من الواقع بأسماء خيالية، والمهمة استخراج المعلومة منها */
window.SIMS = [
{
  id: "m1", stage: "s3", title: "طرفية غاضبة", kind: "الطرفية",
  intro: "شغّلت مشروعاً نزّلته من الإنترنت فظهرت هذه الرسائل. اقرأها وحدد المشكلة.",
  html: `
  <div class="sim-term" dir="ltr">
    <div class="term-bar"><i></i><i></i><i></i><span>bash — my-app</span></div>
<pre><span class="t-p">$</span> npm start

> my-app@1.0.0 start
> node server.js

<span class="t-warn">(node:4821) [DEP0005] DeprecationWarning: Buffer() is deprecated due to security and usability issues. Please use Buffer.from() instead.</span>
<span class="t-err">Error: listen EADDRINUSE: address already in use :::3000</span>
    at Server.setupListenHandle (node:net:1817:16)
    at listenInCluster (node:net:1865:12)
    at Object.&lt;anonymous&gt; (/home/mo/my-app/server.js:42:8)

<span class="t-p">$</span> node scripts/seed.js
<span class="t-err">Error: Cannot find module 'dotenv'</span>
Require stack:
- /home/mo/my-app/scripts/seed.js
<span class="t-dim">Did you forget to run "npm install"?</span></pre>
  </div>`,
  tasks: [
    { q: "لماذا لم يعمل الخادم على المنفذ 3000؟", o: ["المنفذ مستخدم بالفعل من برنامج آخر","الملف server.js محذوف","الإنترنت مقطوع","كلمة المرور خاطئة"], a: 0, why: "address already in use :::3000 = العنوان مستخدم بالفعل." },
    { q: "في أي سطر من كودك حدث الخطأ الأول؟", o: ["node:net:1817","server.js السطر 42","seed.js السطر 1","لا يمكن معرفته"], a: 1, why: "السطر الذي يذكر ملفك أنت: /home/mo/my-app/server.js:42:8." },
    { q: "التحذير DeprecationWarning يطلب منك:", o: ["حذف Node","استخدام Buffer.from() بدلاً من Buffer()","تثبيت dotenv","إعادة تشغيل الجهاز"], a: 1, why: "Please use Buffer.from() instead." },
    { q: "ما الحل المقترح لخطأ Cannot find module 'dotenv'؟", o: ["تشغيل npm install","حذف المجلد","تغيير المنفذ","تحديث المتصفح"], a: 0, why: "Did you forget to run \"npm install\"? = هل نسيت تشغيل npm install؟" }
  ]
},
{
  id: "m2", stage: "s3", title: "صفحة توثيق مكتبة", kind: "التوثيق",
  intro: "تريد استخدام مكتبة اسمها Parcelo لضغط الصور. هذه صفحة التوثيق. استخرج ما تحتاجه.",
  html: `
  <div class="sim-docs" dir="ltr">
    <aside><b>Parcelo Docs</b><a>Getting Started</a><a class="on">API Reference</a><a>Guides</a><a>Troubleshooting</a><a>Changelog</a></aside>
    <article>
      <div class="crumb">API Reference / compress()</div>
      <h3>compress(input, options?)</h3>
      <p>Compresses an image and returns a smaller version. Supported formats are JPEG, PNG and WebP. GIF files are not supported and will throw an error.</p>
      <div class="callout warn"><b>Breaking change in v4:</b> the <code>quality</code> option now accepts values from 0 to 1 instead of 0 to 100.</div>
      <h4>Parameters</h4>
      <table><tr><th>Name</th><th>Type</th><th>Description</th></tr>
      <tr><td><code>input</code></td><td>Buffer | string</td><td>Required. The image data or a path to the file.</td></tr>
      <tr><td><code>options.quality</code></td><td>number</td><td>Optional. Defaults to <code>0.8</code>. Lower values produce smaller files.</td></tr>
      <tr><td><code>options.keepMetadata</code></td><td>boolean</td><td>Optional. Defaults to <code>false</code>. When true, EXIF data such as location is preserved.</td></tr></table>
      <h4>Returns</h4>
      <p>A <code>Promise</code> that resolves to a <code>Buffer</code>.</p>
      <pre>const small = await compress("photo.jpg", { quality: 0.6 });</pre>
    </article>
  </div>`,
  tasks: [
    { q: "هل تستطيع ضغط ملف GIF بهذه الدالة؟", o: ["نعم","لا، غير مدعوم وسيطلق خطأ","فقط في الإصدار 4","فقط مع keepMetadata"], a: 1, why: "GIF files are not supported and will throw an error." },
    { q: "في الإصدار 4، إذا أردت جودة 70% تكتب:", o: ["quality: 70","quality: 0.7","quality: 700","quality: true"], a: 1, why: "the quality option now accepts values from 0 to 1." },
    { q: "إذا لم تحدد keepMetadata، هل يُحفظ موقع التصوير في الصورة؟", o: ["نعم دائماً","لا، القيمة الافتراضية false","فقط في PNG","غير مذكور"], a: 1, why: "Defaults to false. When true, EXIF data such as location is preserved." },
    { q: "أي معامل إلزامي Required؟", o: ["options.quality","options.keepMetadata","input","لا يوجد"], a: 2, why: "input: Required." }
  ]
},
{
  id: "m3", stage: "s4", title: "تنبيه أمني من الإدارة", kind: "الأمن",
  intro: "وصلك هذا التنبيه الأمني عن موجّه (راوتر) تستخدمه في الشبكة. افهم الخطر وما يجب فعله.",
  html: `
  <div class="sim-adv" dir="ltr">
    <div class="adv-head"><span class="sev">CRITICAL</span><span>CVE-2026-31877</span><span>Published: Oct 28, 2026</span></div>
    <h3>Authentication bypass in NetHaven R7 router web interface</h3>
    <dl>
      <dt>Affected products</dt><dd>NetHaven R7 and R7 Pro, firmware 3.1.0 through 3.4.2</dd>
      <dt>Fixed in</dt><dd>Firmware 3.4.3</dd>
      <dt>Attack vector</dt><dd>Network. No user interaction required.</dd>
    </dl>
    <h4>Description</h4>
    <p>An attacker on the same local network can access the admin panel without a password by sending a specially crafted request. Devices with remote management enabled are also exposed to attacks from the internet.</p>
    <h4>Mitigation</h4>
    <p>Update the firmware as soon as possible. Until you can update, disable remote management and change the default admin username. There is no evidence that this vulnerability has been exploited in the wild.</p>
  </div>`,
  tasks: [
    { q: "راوترك يعمل بالإصدار 3.2.0. هل هو متأثر؟", o: ["لا","نعم، يقع بين 3.1.0 و 3.4.2","فقط إن كان Pro","غير واضح"], a: 1, why: "firmware 3.1.0 through 3.4.2." },
    { q: "ماذا يستطيع المهاجم فعله؟", o: ["إبطاء الإنترنت فقط","دخول لوحة الإدارة بدون كلمة مرور","سرقة الجهاز","حذف الإصدار"], a: 1, why: "can access the admin panel without a password." },
    { q: "No user interaction required تعني:", o: ["يجب أن يضغط المستخدم رابطاً","الهجوم لا يحتاج أي تفاعل من المستخدم","المستخدم محمي","الإدارة مطلوبة"], a: 1, why: "لا يحتاج المهاجم أن تضغط أو تفعل أي شيء، وهذا يزيد الخطورة." },
    { q: "هل استُغلت الثغرة فعلياً حسب التقرير؟", o: ["نعم على نطاق واسع","لا يوجد دليل على ذلك","نعم في دولة واحدة","التقرير لا يذكر"], a: 1, why: "There is no evidence that this vulnerability has been exploited in the wild." }
  ]
},
{
  id: "m4", stage: "s5", title: "صفحة كورس على منصة", kind: "الكورسات",
  intro: "وجدت هذا الكورس على منصة تعليمية خيالية اسمها Skillnest. قرر هل يناسبك قبل أن تدفع.",
  html: `
  <div class="sim-course" dir="ltr">
    <div class="c-hero">
      <span class="tag">Bestseller</span>
      <h3>Python for Network Engineers: Automate Everything</h3>
      <p>Stop configuring devices by hand. Write Python scripts that manage hundreds of routers in minutes.</p>
      <div class="c-meta"><b>4.7</b> ★★★★★ (3,912 ratings) • 21,480 students • Last updated 09/2026 • English [Auto subtitles]</div>
    </div>
    <div class="c-body">
      <div class="c-box"><h4>What you'll learn</h4><ul><li>Connect to network devices using SSH with Python</li><li>Back up configurations of 100+ devices automatically</li><li>Parse command output and generate Excel reports</li><li>Build a simple dashboard to monitor your network</li></ul></div>
      <div class="c-side"><div class="price">$14.99 <s>$84.99</s></div><div class="off">82% off • 2 days left at this price!</div><button type="button">Add to cart</button><small>30-Day Money-Back Guarantee</small><small>Includes: 18.5 hours on-demand video • 42 downloadable resources • Full lifetime access • Certificate of completion</small></div>
      <div class="c-box"><h4>Requirements</h4><ul><li>Basic knowledge of networking (IP addresses, subnets, VLANs)</li><li>No prior Python experience is needed</li></ul></div>
      <div class="c-box"><h4>Who this course is for</h4><ul><li>Network engineers who want to save time</li><li>Students preparing for networking certifications</li><li>Not for experienced Python developers looking for advanced topics</li></ul></div>
    </div>
  </div>`,
  tasks: [
    { q: "هل تحتاج خبرة سابقة في بايثون؟", o: ["نعم","لا","سنة على الأقل","غير مذكور"], a: 1, why: "No prior Python experience is needed." },
    { q: "ما المعرفة المطلوبة قبل البدء؟", o: ["تصميم الجرافيك","أساسيات الشبكات","البرمجة المتقدمة","لا شيء أبداً"], a: 1, why: "Basic knowledge of networking (IP addresses, subnets, VLANs)." },
    { q: "إلى متى يستمر هذا السعر المخفض؟", o: ["للأبد","يومان","30 يوماً","82 يوماً"], a: 1, why: "2 days left at this price!" },
    { q: "إذا لم يعجبك الكورس بعد أسبوعين، ماذا يمكنك أن تفعل؟", o: ["لا شيء","استرداد المال خلال 30 يوماً","تحويله لكورس آخر فقط","الحصول على الشهادة"], a: 1, why: "30-Day Money-Back Guarantee." }
  ]
},
{
  id: "m5", stage: "s6", title: "نافذة التسجيل والاشتراك", kind: "مواقع يومية",
  intro: "تريد التسجيل في منصة خيالية اسمها Learnly لتجربة كورس. اقرأ الشاشة بعناية قبل أن تضغط أي زر.",
  html: `
  <div class="sim-signup" dir="ltr">
    <div class="cookie"><p>We use cookies to improve your experience and to show personalized ads. You can change your choice at any time in Settings.</p><div><button type="button">Reject non-essential</button><button type="button">Manage preferences</button><button type="button" class="pri">Accept all</button></div></div>
    <div class="su-card">
      <h3>Start your 14-day free trial</h3>
      <p class="muted">Full access to 8,000+ courses. Cancel anytime before the trial ends and you won't be charged.</p>
      <label>Email address<input type="text" value="mo@example.com" readonly></label>
      <label>Password<input type="text" value="••••••••" readonly></label>
      <small class="muted">Must be at least 10 characters and include a number.</small>
      <label class="chk"><input type="checkbox" checked disabled> Send me tips, offers and product updates</label>
      <div class="plan">After your trial: <b>$29/month</b>, or <b>$199/year</b> (save 43%). Your plan renews automatically.</div>
      <button type="button" class="pri wide">Start free trial</button>
      <small class="muted">By signing up, you agree to our Terms of Use. A payment method is required to start the trial.</small>
    </div>
  </div>`,
  tasks: [
    { q: "هل تحتاج إدخال وسيلة دفع لبدء التجربة المجانية؟", o: ["لا","نعم، وسيلة دفع مطلوبة","فقط للخطة السنوية","غير مذكور"], a: 1, why: "A payment method is required to start the trial." },
    { q: "متى يجب أن تلغي حتى لا يُخصم منك شيء؟", o: ["بعد 14 يوماً","قبل انتهاء التجربة","بعد أول دفعة","لا يمكن الإلغاء"], a: 1, why: "Cancel anytime before the trial ends and you won't be charged." },
    { q: "أي زر يرفض الكوكيز غير الضرورية؟", o: ["Accept all","Manage preferences","Reject non-essential","Start free trial"], a: 2, why: "non-essential = غير ضرورية." },
    { q: "هناك خيار مُفعّل مسبقاً يجب أن تنتبه له، ما هو؟", o: ["إرسال نصائح وعروض لبريدك","حذف الحساب","الدفع السنوي","تغيير اللغة"], a: 0, why: "Send me tips, offers and product updates مُفعّل، وإن لم ترده ألغِ تحديده." }
  ]
}
];
