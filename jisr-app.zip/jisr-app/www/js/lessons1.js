/* المراحل والدروس — الجزء الأول (المراحل 1 إلى 3) */
window.STAGES = [
  { id: "s1", n: 1, title: "كسر الرهبة", sub: "تعامل مع النص الإنجليزي بثقة قبل أي قاعدة" },
  { id: "s2", n: 2, title: "مفاتيح الفهم", sub: "القواعد التي تحتاجها للقراءة فقط، بدون حشو" },
  { id: "s3", n: 3, title: "لغة البرمجة", sub: "رسائل الأخطاء، التوثيق، ومنتديات المبرمجين" },
  { id: "s4", n: 4, title: "الشبكات وأمن المعلومات", sub: "مصطلحات وتقارير الأمن كما تكتب فعلاً" },
  { id: "s5", n: 5, title: "داخل الكورس", sub: "صفحة الكورس، المحاضرة، والاختبارات" },
  { id: "s6", n: 6, title: "عام ومتنوع", sub: "ويكيبيديا، الأخبار، والمواقع اليومية" }
];

window.LESSONS = [
/* ================= المرحلة 1 ================= */
{
  id: "l1", stage: "s1", title: "لست مضطراً لفهم كل كلمة", minutes: 7,
  explain: `
  <p>أكبر سبب للرهبة من المواقع الإنجليزية هو الاعتقاد أنك يجب أن تفهم <b>كل كلمة</b>. القارئ المحترف نفسه لا يفعل ذلك. يكفيك أن تفهم <b>الكلمات الحاملة للمعنى</b>: الأفعال والأسماء الرئيسية.</p>
  <p>الكلمات الصغيرة مثل <span class="en">the, a, of, to, in</span> تشكل قرابة نصف أي نص، وهي تربط الكلام فقط. إذا تجاوزتها بعينك ستجد الجملة أقصر بكثير.</p>
  <p><b>القاعدة الذهبية:</b> إذا وقفت عند كلمة لا تعرفها، أكمل الجملة أولاً. في أغلب الأحيان يشرحها ما بعدها، أو لا تكون مهمة أصلاً.</p>`,
  examples: [
    { en: "Click the button at the top of the page to download the latest version.", ar: "اضغط الزر أعلى الصفحة لتنزيل أحدث إصدار.", note: "الكلمات الحاملة للمعنى: Click, button, top, page, download, latest version" },
    { en: "The installation may take a few minutes depending on your connection.", ar: "قد يستغرق التثبيت بضع دقائق حسب اتصالك.", note: "حتى لو لم تعرف depending، فهمت أن التثبيت يأخذ دقائق" },
    { en: "If you encounter any issues, please contact our support team.", ar: "إذا واجهت أي مشاكل، تواصل مع فريق الدعم.", note: "encounter غريبة؟ issues و support team تكفي لفهم الجملة" }
  ],
  reading: {
    title: "Download Python",
    paras: [
      { en: "Python is free to download and use. Visit the official website and choose the version for your operating system.", ar: "بايثون مجانية للتنزيل والاستخدام. زر الموقع الرسمي واختر الإصدار المناسب لنظام تشغيلك." },
      { en: "Windows users should check the box that says \"Add Python to PATH\" before they click Install. This small step saves a lot of trouble later.", ar: "يجب على مستخدمي ويندوز تحديد خيار \"Add Python to PATH\" قبل الضغط على تثبيت. هذه الخطوة الصغيرة توفر عليك متاعب كثيرة لاحقاً." },
      { en: "When the installation is complete, open a terminal and type python --version to confirm that everything works.", ar: "عند اكتمال التثبيت، افتح الطرفية واكتب python --version لتتأكد أن كل شيء يعمل." }
    ]
  },
  vocab: [["download","ينزّل / تنزيل"],["official","رسمي"],["version","إصدار"],["operating system","نظام التشغيل"],["check the box","ضع علامة في المربع"],["trouble","متاعب / مشكلة"],["complete","مكتمل"],["confirm","يتأكد / يؤكد"],["latest","الأحدث"],["issue","مشكلة"]],
  quiz: [
    { q: "ما الذي يجب على مستخدم ويندوز فعله قبل الضغط على Install؟", o: ["إعادة تشغيل الجهاز","تحديد خيار Add Python to PATH","فتح الطرفية","حذف الإصدار القديم"], a: 1, why: "النص يقول: should check the box that says \"Add Python to PATH\" before they click Install." },
    { q: "في جملة: If you encounter any issues... ما الكلمات التي تكفي لفهم المعنى؟", o: ["If, you, any","encounter فقط","issues, contact, support team","please, our"], a: 2, why: "حتى بدون معرفة encounter، الكلمات issues و support team توصل الفكرة: إذا عندك مشكلة كلم الدعم." },
    { q: "ما الهدف من كتابة python --version؟", o: ["تنزيل بايثون","التأكد أن التثبيت يعمل","حذف بايثون","تحديث النظام"], a: 1, why: "to confirm that everything works = لتتأكد أن كل شيء يعمل." }
  ]
},
{
  id: "l2", stage: "s1", title: "كلمات تعرفها من قبل", minutes: 6,
  explain: `
  <p>أنت تعرف مئات الكلمات الإنجليزية بدون أن تنتبه: <span class="en">computer, internet, server, file, program, email, password</span>. اللغة التقنية مليئة بكلمات دخلت العربية كما هي.</p>
  <p>وهناك كلمات تشبه أخواتها في كلمات تعرفها: <span class="en">install</span> تعرفها، إذن <span class="en">installation</span> = عملية التثبيت. <span class="en">secure</span> = آمن، إذن <span class="en">security</span> = الأمان.</p>
  <p><b>تمرين ذهني:</b> قبل أن تبحث عن كلمة، اسأل نفسك: هل تشبه كلمة أعرفها؟ هل سمعتها في سياق تقني؟</p>`,
  examples: [
    { en: "The server stores user data in a database.", ar: "يخزن الخادم بيانات المستخدم في قاعدة بيانات.", note: "server, user, data, database كلها كلمات مألوفة" },
    { en: "Reset your password from the settings menu.", ar: "أعد تعيين كلمة المرور من قائمة الإعدادات.", note: "reset, password, settings, menu تراها يومياً في الجوال" },
    { en: "This app requires a stable internet connection.", ar: "يتطلب هذا التطبيق اتصال إنترنت مستقر.", note: "app, internet, connection = تطبيق، إنترنت، اتصال" }
  ],
  reading: {
    title: "How a Website Works",
    paras: [
      { en: "When you type a website address in your browser, your computer sends a request to a server on the internet.", ar: "عندما تكتب عنوان موقع في متصفحك، يرسل جهازك طلباً إلى خادم على الإنترنت." },
      { en: "The server finds the files for that page, such as HTML, CSS, images and JavaScript, and sends them back to your browser.", ar: "يجد الخادم ملفات تلك الصفحة، مثل HTML وCSS والصور وجافاسكربت، ويرسلها إلى متصفحك." },
      { en: "Your browser then reads these files and displays the page on your screen. All of this usually happens in less than a second.", ar: "ثم يقرأ متصفحك هذه الملفات ويعرض الصفحة على شاشتك. كل هذا يحدث عادة في أقل من ثانية." }
    ]
  },
  vocab: [["browser","متصفح"],["request","طلب"],["server","خادم"],["address","عنوان"],["such as","مثل"],["display","يعرض"],["screen","شاشة"],["usually","عادةً"],["happen","يحدث"],["store","يخزّن"]],
  quiz: [
    { q: "ماذا يرسل جهازك إلى الخادم عندما تكتب عنوان موقع؟", o: ["ملفات HTML","طلب request","صورة","كلمة مرور"], a: 1, why: "your computer sends a request to a server." },
    { q: "كلمة installation مشتقة من أي كلمة تعرفها؟", o: ["instant","install","station","nation"], a: 1, why: "install = يثبّت، وإضافة -ation تحولها إلى اسم: عملية التثبيت." },
    { q: "من الذي يعرض الصفحة على شاشتك؟", o: ["الخادم","الإنترنت","المتصفح","قاعدة البيانات"], a: 2, why: "Your browser then reads these files and displays the page." }
  ]
},
{
  id: "l3", stage: "s1", title: "القراءة على ثلاث طبقات", minutes: 8,
  explain: `
  <p>لا تقرأ صفحة إنجليزية من أول كلمة لآخر كلمة بنفس السرعة. استخدم ثلاث طبقات:</p>
  <p><b>1. التصفح السريع (Skimming):</b> اقرأ العناوين، الكلمات العريضة، وأول جملة في كل فقرة. الهدف: عن ماذا تتحدث الصفحة؟</p>
  <p><b>2. البحث عن معلومة (Scanning):</b> عندك سؤال محدد مثل "كم سعر الكورس؟" أو "ما المتطلبات؟". ابحث بعينك عن كلمة مفتاحية مثل <span class="en">price</span> أو <span class="en">requirements</span>.</p>
  <p><b>3. القراءة العميقة:</b> فقط للجزء الذي يهمك فعلاً، مثل خطوات التثبيت أو شرح فكرة صعبة.</p>`,
  examples: [
    { en: "Requirements: Basic computer skills. No programming experience needed.", ar: "المتطلبات: مهارات حاسوب أساسية. لا تحتاج خبرة برمجية.", note: "بالمسح السريع تجد كلمة Requirements وتعرف الجواب فوراً" },
    { en: "In this course, you will build three real projects from scratch.", ar: "في هذا الكورس ستبني ثلاثة مشاريع حقيقية من الصفر.", note: "from scratch = من الصفر، تعبير شائع جداً في الكورسات" }
  ],
  reading: {
    title: "Course Overview",
    paras: [
      { en: "Web Development for Beginners. Learn HTML, CSS and JavaScript step by step and build your first website.", ar: "تطوير الويب للمبتدئين. تعلّم HTML وCSS وجافاسكربت خطوة بخطوة وابنِ أول موقع لك." },
      { en: "This course is designed for students with no prior experience. Each section ends with a short quiz and a practical exercise.", ar: "هذا الكورس مصمم للطلاب الذين ليس لديهم خبرة سابقة. كل قسم ينتهي باختبار قصير وتمرين عملي." },
      { en: "Requirements: a computer with internet access and a free code editor. Duration: 12 hours of video.", ar: "المتطلبات: حاسوب متصل بالإنترنت ومحرر أكواد مجاني. المدة: 12 ساعة فيديو." }
    ]
  },
  vocab: [["step by step","خطوة بخطوة"],["beginner","مبتدئ"],["designed for","مصمم لـ"],["prior experience","خبرة سابقة"],["section","قسم"],["practical exercise","تمرين عملي"],["requirements","المتطلبات"],["duration","المدة"],["from scratch","من الصفر"],["skills","مهارات"]],
  quiz: [
    { q: "بطريقة Scanning: كم مدة الكورس؟", o: ["3 ساعات","12 ساعة","12 أسبوع","غير مذكورة"], a: 1, why: "ابحث عن كلمة Duration: 12 hours of video." },
    { q: "هل يحتاج الكورس خبرة سابقة؟", o: ["نعم، خبرة في جافاسكربت","نعم، خبرة سنة","لا، مصمم لمن ليس لديه خبرة","غير واضح"], a: 2, why: "designed for students with no prior experience." },
    { q: "ماذا تقرأ أولاً عند التصفح السريع Skimming؟", o: ["كل كلمة بالترتيب","العناوين وأول جملة في الفقرات","آخر سطر فقط","الكلمات الصعبة"], a: 1, why: "التصفح السريع يعني العناوين والكلمات البارزة وبدايات الفقرات." }
  ]
},

/* ================= المرحلة 2 ================= */
{
  id: "l4", stage: "s2", title: "ابحث عن الفعل أولاً", minutes: 9,
  explain: `
  <p>الجملة الإنجليزية الطويلة تخيف، لكن لها هيكل ثابت تقريباً: <b>الفاعل ← الفعل ← المفعول/التكملة</b>.</p>
  <p class="formula" dir="ltr">[Who/What] + [does what] + [to what / how / where]</p>
  <p>الحيلة: <b>ابحث عن الفعل الرئيسي أولاً</b>. كل ما قبله غالباً هو الفاعل (حتى لو كان طويلاً)، وكل ما بعده هو التكملة.</p>
  <p>انتبه: في الإنجليزية <b>الصفة تأتي قبل الاسم</b>، وعكس العربية. <span class="en">the default configuration file</span> تقرأ من اليمين لليسار في ذهنك: file (ملف) ← configuration (الإعدادات) ← default (الافتراضي) = <b>ملف الإعدادات الافتراضي</b>.</p>`,
  examples: [
    { en: "The new version of the library supports older browsers.", ar: "الإصدار الجديد من المكتبة يدعم المتصفحات الأقدم.", note: "الفعل: supports. قبله الفاعل: The new version of the library" },
    { en: "Our free online security course teaches basic network protection.", ar: "كورسنا المجاني عبر الإنترنت في الأمن يعلّم أساسيات حماية الشبكة.", note: "الفعل: teaches. اقرأ network protection = حماية الشبكة" },
    { en: "A user login error message appears on the screen.", ar: "تظهر رسالة خطأ تسجيل دخول المستخدم على الشاشة.", note: "4 أسماء متتالية! ابدأ من الأخير: message ← error ← login ← user" }
  ],
  reading: {
    title: "Configuration",
    paras: [
      { en: "The application reads its settings from a configuration file called config.json in the project folder.", ar: "يقرأ التطبيق إعداداته من ملف إعدادات اسمه config.json في مجلد المشروع." },
      { en: "Each setting in this file controls one part of the program, for example the default language or the database connection string.", ar: "كل إعداد في هذا الملف يتحكم في جزء من البرنامج، مثل اللغة الافتراضية أو نص الاتصال بقاعدة البيانات." },
      { en: "Developers on large teams usually keep a separate configuration file for each environment.", ar: "المطورون في الفرق الكبيرة عادةً يحتفظون بملف إعدادات منفصل لكل بيئة تشغيل." }
    ]
  },
  vocab: [["application","تطبيق"],["settings","الإعدادات"],["configuration","تهيئة / إعدادات"],["folder","مجلد"],["control","يتحكم"],["default","افتراضي"],["connection string","نص الاتصال"],["developer","مطوّر"],["separate","منفصل"],["environment","بيئة (تشغيل)"],["support","يدعم"],["library","مكتبة (برمجية)"]],
  quiz: [
    { q: "ما الفعل الرئيسي في: Developers on large teams usually keep a separate configuration file?", o: ["teams","usually","keep","separate"], a: 2, why: "keep هو الفعل. Developers on large teams هو الفاعل كاملاً." },
    { q: "ما ترجمة: the database connection string؟", o: ["قاعدة اتصال النص","نص الاتصال بقاعدة البيانات","اتصال قاعدة النص","بيانات النص"], a: 1, why: "ابدأ من الأخير: string (نص) ← connection (الاتصال) ← database (قاعدة البيانات)." },
    { q: "من أين يقرأ التطبيق إعداداته؟", o: ["من الإنترنت","من ملف config.json","من قاعدة البيانات","من المستخدم"], a: 1, why: "reads its settings from a configuration file called config.json." }
  ]
},
{
  id: "l5", stage: "s2", title: "الأزمنة للقارئ فقط", minutes: 9,
  explain: `
  <p>لن نحفظ جداول أزمنة. كقارئ تحتاج أن <b>تعرف الزمن من الشكل</b>، وهذه أهم العلامات:</p>
  <table class="mini" dir="ltr"><tr><th>الشكل</th><th dir="rtl">المعنى</th></tr>
  <tr><td>works / runs</td><td dir="rtl">حقيقة أو عادة دائمة</td></tr>
  <tr><td>is running / are loading</td><td dir="rtl">يحدث الآن</td></tr>
  <tr><td>worked / ran / was</td><td dir="rtl">حدث وانتهى في الماضي</td></tr>
  <tr><td>has / have + released</td><td dir="rtl">حدث وما زال أثره قائماً (قد، لقد)</td></tr>
  <tr><td>will / is going to</td><td dir="rtl">مستقبل (سوف)</td></tr>
  <tr><td>had + finished</td><td dir="rtl">حدث قبل حدث آخر في الماضي</td></tr></table>
  <p>في التوثيق التقني أغلب الكلام بالمضارع البسيط لأنه يصف حقائق: <span class="en">This function returns a list.</span></p>`,
  examples: [
    { en: "The server is restarting. Please wait.", ar: "الخادم يعيد التشغيل الآن. انتظر من فضلك.", note: "is + ing = يحدث الآن" },
    { en: "We have fixed the bug in version 2.1.", ar: "لقد أصلحنا الخلل في الإصدار 2.1.", note: "have + fixed = تم وما زال الإصلاح قائماً" },
    { en: "Support for Windows 7 will end next year.", ar: "سينتهي دعم ويندوز 7 العام القادم.", note: "will = سوف" },
    { en: "The upload failed because the file was too large.", ar: "فشل الرفع لأن الملف كان كبيراً جداً.", note: "failed / was = ماضٍ منتهٍ" }
  ],
  reading: {
    title: "Release Notes v3.0",
    paras: [
      { en: "We have released version 3.0 with a completely new dashboard. The old dashboard will remain available until the end of the month.", ar: "لقد أصدرنا الإصدار 3.0 بلوحة تحكم جديدة كلياً. ستبقى اللوحة القديمة متاحة حتى نهاية الشهر." },
      { en: "In previous versions, the app crashed when users uploaded large images. This problem no longer happens.", ar: "في الإصدارات السابقة، كان التطبيق ينهار عندما يرفع المستخدمون صوراً كبيرة. هذه المشكلة لم تعد تحدث." },
      { en: "Our team is currently working on dark mode, and we are going to publish it in the next update.", ar: "فريقنا يعمل حالياً على الوضع الداكن، وسننشره في التحديث القادم." }
    ]
  },
  vocab: [["release","يُصدر / إصدار"],["dashboard","لوحة التحكم"],["remain","يبقى"],["available","متاح"],["previous","سابق"],["crash","ينهار / يتعطل"],["no longer","لم يعد"],["currently","حالياً"],["update","تحديث"],["bug","خلل برمجي"],["fix","يصلح"],["publish","ينشر"]],
  quiz: [
    { q: "هل ما زال التطبيق ينهار عند رفع الصور الكبيرة؟", o: ["نعم","لا، لم يعد يحدث","سيحدث في المستقبل","غير مذكور"], a: 1, why: "This problem no longer happens. و crashed بصيغة الماضي." },
    { q: "ما حالة الوضع الداكن dark mode؟", o: ["نُشر بالفعل","أُلغي","يعملون عليه الآن وسيُنشر لاحقاً","موجود في الإصدار القديم"], a: 2, why: "is currently working on = يعمل الآن، و are going to publish = سننشره." },
    { q: "صيغة have + released تعني:", o: ["سوف يصدرون","أصدروا وما زال قائماً","يصدرون كل يوم","كانوا سيصدرون"], a: 1, why: "have + الفعل الثالث = حدث وأثره قائم الآن." }
  ]
},
{
  id: "l6", stage: "s2", title: "المبني للمجهول: لغة التوثيق", minutes: 8,
  explain: `
  <p>التوثيق التقني يحب المبني للمجهول، لأنه يهتم بالشيء وليس بمن فعله. شكله ثابت:</p>
  <p class="formula" dir="ltr">is / are / was / be / been + V3 (installed, used, required)</p>
  <p>عندما ترى <span class="en">is + كلمة تنتهي بـ ed</span> فكّر بـ "يُفعَل" أو "تمّ".</p>
  <p>صيغ تراها كثيراً: <span class="en">can be configured</span> = يمكن تهيئته، <span class="en">is required</span> = مطلوب، <span class="en">has been deprecated</span> = تم إيقاف التوصية باستخدامه، <span class="en">is not supported</span> = غير مدعوم.</p>`,
  examples: [
    { en: "Node.js 20 or later is required.", ar: "يلزم Node.js إصدار 20 أو أحدث.", note: "is required = مطلوب" },
    { en: "This method has been deprecated and will be removed in the next version.", ar: "تم إيقاف التوصية بهذه الدالة وستُحذف في الإصدار القادم.", note: "deprecated كلمة مهمة جداً: لا تستخدمها في كود جديد" },
    { en: "Passwords are stored in encrypted form.", ar: "تُخزَّن كلمات المرور بشكل مشفّر.", note: "are stored = تُخزَّن" }
  ],
  reading: {
    title: "Database Backups",
    paras: [
      { en: "Backups are created automatically every night at 2:00 AM. Each backup is stored for thirty days and then deleted.", ar: "تُنشأ النسخ الاحتياطية تلقائياً كل ليلة الساعة 2:00 صباحاً. تُخزّن كل نسخة ثلاثين يوماً ثم تُحذف." },
      { en: "The backup schedule can be changed from the admin panel. Only users with the Owner role are allowed to restore a backup.", ar: "يمكن تغيير جدول النسخ الاحتياطي من لوحة الإدارة. فقط المستخدمون بدور المالك مسموح لهم باستعادة نسخة." },
      { en: "Note: manual backups are not included in the free plan.", ar: "ملاحظة: النسخ اليدوية غير مشمولة في الخطة المجانية." }
    ]
  },
  vocab: [["backup","نسخة احتياطية"],["automatically","تلقائياً"],["delete","يحذف"],["schedule","جدول / موعد"],["admin panel","لوحة الإدارة"],["role","دور / صلاحية"],["allowed","مسموح"],["restore","يستعيد"],["manual","يدوي"],["included","مشمول"],["required","مطلوب"],["deprecated","مُهمَل / غير موصى به"],["encrypted","مشفّر"]],
  quiz: [
    { q: "من يستطيع استعادة نسخة احتياطية؟", o: ["أي مستخدم","المستخدمون بدور Owner فقط","فريق الدعم","لا أحد"], a: 1, why: "Only users with the Owner role are allowed to restore a backup." },
    { q: "ماذا يحدث للنسخة بعد ثلاثين يوماً؟", o: ["تُنقل","تُشفّر","تُحذف","تُرسل للمستخدم"], a: 2, why: "is stored for thirty days and then deleted." },
    { q: "إذا قرأت أن دالة has been deprecated، ماذا تفعل؟", o: ["تستخدمها بكثرة","تتجنبها في الكود الجديد","تحذف المكتبة","تعيد تثبيت النظام"], a: 1, why: "deprecated تعني أنها قديمة وقد تُحذف، فيُنصح بالبديل." }
  ]
},
{
  id: "l7", stage: "s2", title: "which و that و who: الجمل الموصولة", minutes: 8,
  explain: `
  <p>هذه الكلمات تفتح <b>جملة داخل جملة</b> تشرح الاسم الذي قبلها مباشرة. ترجمها بـ "الذي / التي / الذين".</p>
  <p><span class="en">which / that</span> للأشياء، <span class="en">who</span> للأشخاص، <span class="en">where</span> للأماكن، <span class="en">whose</span> = الذي له.</p>
  <p><b>الحيلة:</b> ضع الجملة الموصولة بين قوسين في ذهنك، واقرأ الجملة الأساسية بدونها أولاً.</p>
  <p class="formula" dir="ltr">The file (that you downloaded) is corrupted.</p>
  <p>الجملة الأساسية: <span class="en">The file is corrupted</span> = الملف تالف. والقوس يحدد أي ملف.</p>
  <p>أحياناً تُحذف that تماماً: <span class="en">The file you downloaded</span> = الملف الذي نزّلته.</p>`,
  examples: [
    { en: "Users who forget their password can request a reset link.", ar: "المستخدمون الذين ينسون كلمة المرور يمكنهم طلب رابط إعادة تعيين.", note: "الأساسية: Users can request a reset link" },
    { en: "Choose a plan that fits your needs.", ar: "اختر خطة تناسب احتياجاتك.", note: "that fits your needs تصف الخطة" },
    { en: "The function you are calling returns null.", ar: "الدالة التي تستدعيها تُرجع null.", note: "that محذوفة بعد The function" }
  ],
  reading: {
    title: "Two-Factor Authentication",
    paras: [
      { en: "Two-factor authentication is a security feature that adds a second step to the login process.", ar: "المصادقة الثنائية ميزة أمان تضيف خطوة ثانية لعملية تسجيل الدخول." },
      { en: "After you enter your password, the system sends a code to the phone that is linked to your account.", ar: "بعد إدخال كلمة المرور، يرسل النظام رمزاً إلى الهاتف المرتبط بحسابك." },
      { en: "Attackers who steal your password still cannot access your account, because they do not have the code.", ar: "المهاجمون الذين يسرقون كلمة مرورك لا يزالون غير قادرين على دخول حسابك، لأنه ليس لديهم الرمز." }
    ]
  },
  vocab: [["authentication","المصادقة / التحقق من الهوية"],["feature","ميزة"],["login","تسجيل الدخول"],["process","عملية"],["enter","يُدخل"],["linked to","مرتبط بـ"],["account","حساب"],["attacker","مهاجم"],["steal","يسرق"],["access","يصل إلى / وصول"],["corrupted","تالف"],["fit","يناسب"]],
  quiz: [
    { q: "في: the phone that is linked to your account، ماذا تصف that؟", o: ["الحساب","الهاتف","الرمز","النظام"], a: 1, why: "that تصف الاسم الذي قبلها مباشرة: the phone." },
    { q: "ما الجملة الأساسية في: Attackers who steal your password still cannot access your account؟", o: ["Attackers steal your password","Attackers still cannot access your account","Your password is stolen","Who steal"], a: 1, why: "احذف (who steal your password) يبقى: Attackers still cannot access your account." },
    { q: "لماذا لا يستطيع المهاجم الدخول رغم معرفته كلمة المرور؟", o: ["لأن الحساب محذوف","لأنه ليس لديه الرمز","لأن كلمة المرور خاطئة","لأن الخادم معطل"], a: 1, why: "because they do not have the code." }
  ]
},
{
  id: "l8", stage: "s2", title: "فكّك الكلمة: البادئات واللواحق", minutes: 10,
  explain: `
  <p>كلمة واحدة تعرفها تفتح لك عشر كلمات. الإنجليزية تبني الكلمات من قطع:</p>
  <table class="mini" dir="ltr"><tr><th>القطعة</th><th dir="rtl">المعنى</th><th>مثال</th></tr>
  <tr><td>un- / in- / im- / dis-</td><td dir="rtl">غير، عدم</td><td>unavailable, invalid, disable</td></tr>
  <tr><td>re-</td><td dir="rtl">مرة أخرى</td><td>restart, reinstall</td></tr>
  <tr><td>pre-</td><td dir="rtl">قبل</td><td>preview, prerequisite</td></tr>
  <tr><td>-able / -ible</td><td dir="rtl">قابل لـ</td><td>readable, compatible</td></tr>
  <tr><td>-less</td><td dir="rtl">بدون</td><td>wireless, passwordless</td></tr>
  <tr><td>-tion / -ment</td><td dir="rtl">اسم العملية</td><td>installation, deployment</td></tr>
  <tr><td>-er / -or</td><td dir="rtl">الفاعل أو الأداة</td><td>compiler, editor</td></tr>
  <tr><td>-ize</td><td dir="rtl">يجعله</td><td>optimize, customize</td></tr>
  <tr><td>-ly</td><td dir="rtl">بشكل كذا</td><td>quickly, securely</td></tr></table>`,
  examples: [
    { en: "The file is unreadable.", ar: "الملف غير قابل للقراءة.", note: "un + read + able = غير + قراءة + قابل" },
    { en: "Reconnect your wireless keyboard.", ar: "أعد توصيل لوحة المفاتيح اللاسلكية.", note: "re + connect، و wire + less = بدون سلك" },
    { en: "The deployment was unsuccessful.", ar: "كان النشر غير ناجح.", note: "deploy + ment، و un + success + ful" }
  ],
  reading: {
    title: "Account Settings",
    paras: [
      { en: "You can customize your profile and disable notifications you do not need. Unused accounts are automatically deactivated after one year.", ar: "يمكنك تخصيص ملفك الشخصي وتعطيل الإشعارات التي لا تحتاجها. الحسابات غير المستخدمة تُعطَّل تلقائياً بعد سنة." },
      { en: "If your password is invalid, the login page will display a warning. You can reset it securely through your email.", ar: "إذا كانت كلمة المرور غير صالحة، ستعرض صفحة الدخول تحذيراً. يمكنك إعادة تعيينها بأمان عبر بريدك." },
      { en: "This feature is incompatible with older browsers, so we recommend updating before you continue.", ar: "هذه الميزة غير متوافقة مع المتصفحات القديمة، لذلك ننصح بالتحديث قبل المتابعة." }
    ]
  },
  vocab: [["customize","يخصّص"],["disable","يعطّل"],["enable","يفعّل"],["notification","إشعار"],["unused","غير مستخدم"],["deactivate","يلغي التفعيل"],["invalid","غير صالح"],["warning","تحذير"],["securely","بأمان"],["incompatible","غير متوافق"],["recommend","ينصح / يوصي"],["deployment","النشر"],["wireless","لاسلكي"],["prerequisite","متطلب مسبق"]],
  quiz: [
    { q: "ما معنى reinstall؟", o: ["يحذف","يثبت مرة أخرى","تثبيت مسبق","غير مثبت"], a: 1, why: "re = مرة أخرى + install = يثبت." },
    { q: "ماذا يحدث للحسابات غير المستخدمة بعد سنة؟", o: ["تُحذف","تُخصّص","يُلغى تفعيلها","تُرسل لها إشعارات"], a: 2, why: "Unused accounts are automatically deactivated: de + activate = إلغاء التفعيل." },
    { q: "كلمة incompatible تعني:", o: ["متوافق جداً","غير متوافق","قابل للتحديث","قديم"], a: 1, why: "in = غير، compat(ible) = متوافق." }
  ]
},
{
  id: "l9", stage: "s2", title: "كلمات الربط: إشارات المرور في النص", minutes: 8,
  explain: `
  <p>كلمات الربط تخبرك <b>إلى أين يتجه الكلام</b>. إذا فهمتها فهمت منطق الفقرة حتى لو فاتتك كلمات.</p>
  <table class="mini" dir="ltr"><tr><th>الإشارة</th><th dir="rtl">الاتجاه</th></tr>
  <tr><td>however, but, although, whereas</td><td dir="rtl">انتبه: عكس ما قبله</td></tr>
  <tr><td>therefore, so, as a result, thus</td><td dir="rtl">نتيجة</td></tr>
  <tr><td>because, since, due to</td><td dir="rtl">سبب</td></tr>
  <tr><td>also, in addition, moreover</td><td dir="rtl">إضافة</td></tr>
  <tr><td>for example, such as, e.g.</td><td dir="rtl">مثال</td></tr>
  <tr><td>unless, otherwise</td><td dir="rtl">إلا إذا / وإلا</td></tr>
  <tr><td>instead, rather than</td><td dir="rtl">بدلاً من</td></tr></table>
  <p><b>أهمها على الإطلاق: however.</b> ما بعدها غالباً هو الأهم.</p>`,
  examples: [
    { en: "The free plan is enough for students. However, it does not include certificates.", ar: "الخطة المجانية تكفي الطلاب. لكنها لا تشمل الشهادات.", note: "however = انتبه، معلومة معاكسة مهمة" },
    { en: "Do not close the window unless the update is complete.", ar: "لا تغلق النافذة إلا إذا اكتمل التحديث.", note: "unless = إلا إذا" },
    { en: "Use HTTPS instead of HTTP. Otherwise, your data can be intercepted.", ar: "استخدم HTTPS بدلاً من HTTP. وإلا قد تُعترض بياناتك.", note: "instead of = بدلاً من، otherwise = وإلا" }
  ],
  reading: {
    title: "SQL vs NoSQL",
    paras: [
      { en: "SQL databases store data in tables with fixed columns. As a result, they are excellent for financial systems where accuracy matters.", ar: "قواعد بيانات SQL تخزن البيانات في جداول ذات أعمدة ثابتة. ونتيجة لذلك، فهي ممتازة للأنظمة المالية حيث تهم الدقة." },
      { en: "NoSQL databases, on the other hand, are more flexible. For example, each record can have different fields.", ar: "أما قواعد NoSQL فهي أكثر مرونة. على سبيل المثال، يمكن أن يكون لكل سجل حقول مختلفة." },
      { en: "However, this flexibility has a cost: unless you plan your data carefully, it can become messy and difficult to query.", ar: "لكن لهذه المرونة ثمن: ما لم تخطط بياناتك بعناية، قد تصبح فوضوية وصعبة الاستعلام." }
    ]
  },
  vocab: [["however","لكن / ومع ذلك"],["therefore","لذلك"],["as a result","نتيجة لذلك"],["on the other hand","من ناحية أخرى"],["unless","إلا إذا / ما لم"],["otherwise","وإلا"],["instead of","بدلاً من"],["flexible","مرن"],["accuracy","دقة"],["record","سجل"],["field","حقل"],["messy","فوضوي"],["query","يستعلم / استعلام"],["although","رغم أن"]],
  quiz: [
    { q: "ما عيب قواعد NoSQL حسب النص؟", o: ["بطيئة جداً","قد تصبح فوضوية إن لم تخطط جيداً","لا تخزن البيانات","غالية"], a: 1, why: "الجواب بعد However: unless you plan your data carefully, it can become messy." },
    { q: "كلمة As a result تشير إلى:", o: ["سبب","نتيجة","مثال","عكس"], a: 1, why: "as a result = نتيجة لذلك." },
    { q: "Do not restart unless the admin asks you. متى تعيد التشغيل؟", o: ["دائماً","أبداً","فقط إذا طلب المدير","عندما تريد"], a: 2, why: "unless = إلا إذا طلب المدير." }
  ]
},
{
  id: "l10", stage: "s2", title: "must و should و may: درجات الأوامر", minutes: 7,
  explain: `
  <p>التوثيق والتعليمات مليئة بأفعال تحدد <b>قوة الطلب</b>. فهمها يفرق بين خطوة إلزامية وخطوة اختيارية:</p>
  <table class="mini" dir="ltr"><tr><th>الكلمة</th><th dir="rtl">القوة</th></tr>
  <tr><td>must / have to / required</td><td dir="rtl">إلزامي: يجب</td></tr>
  <tr><td>must not / never</td><td dir="rtl">ممنوع تماماً</td></tr>
  <tr><td>should / recommended</td><td dir="rtl">يُنصح به بقوة</td></tr>
  <tr><td>may / might / can</td><td dir="rtl">ممكن / اختياري</td></tr>
  <tr><td>optional</td><td dir="rtl">اختياري</td></tr></table>
  <p>تعبيرات شائعة: <span class="en">make sure</span> / <span class="en">ensure</span> = تأكد، <span class="en">avoid</span> = تجنب، <span class="en">keep in mind</span> = ضع في اعتبارك.</p>`,
  examples: [
    { en: "You must restart the computer to apply the changes.", ar: "يجب إعادة تشغيل الحاسوب لتطبيق التغييرات.", note: "must = إلزامي" },
    { en: "You should back up your files before upgrading.", ar: "يُنصح بنسخ ملفاتك احتياطياً قبل الترقية.", note: "should = نصيحة قوية" },
    { en: "Never share your private key with anyone.", ar: "لا تشارك مفتاحك الخاص مع أي أحد أبداً.", note: "never = ممنوع تماماً" }
  ],
  reading: {
    title: "Before You Begin",
    paras: [
      { en: "Make sure you have administrator rights on your computer. The installer must run with full permissions.", ar: "تأكد أن لديك صلاحيات المسؤول على حاسوبك. يجب أن يعمل المثبّت بصلاحيات كاملة." },
      { en: "You should close all other programs to avoid conflicts. Antivirus software may slow down the installation.", ar: "يُنصح بإغلاق كل البرامج الأخرى لتجنب التعارض. قد يبطئ برنامج مكافحة الفيروسات التثبيت." },
      { en: "Creating an account is optional. However, you must never turn off your computer during the update.", ar: "إنشاء حساب اختياري. لكن يجب ألا تطفئ حاسوبك أبداً أثناء التحديث." }
    ]
  },
  vocab: [["must","يجب"],["should","يُنصح / ينبغي"],["may","قد / يمكن"],["optional","اختياري"],["make sure","تأكد"],["ensure","يضمن / يتأكد"],["avoid","يتجنب"],["administrator rights","صلاحيات المسؤول"],["permission","إذن / صلاحية"],["conflict","تعارض"],["slow down","يبطئ"],["turn off","يطفئ"],["apply","يطبّق"],["keep in mind","ضع في اعتبارك"]],
  quiz: [
    { q: "أي خطوة اختيارية في النص؟", o: ["صلاحيات المسؤول","إنشاء حساب","عدم إطفاء الجهاز","تشغيل المثبت بصلاحيات كاملة"], a: 1, why: "Creating an account is optional." },
    { q: "Antivirus software may slow down... كلمة may تعني:", o: ["سيبطئ حتماً","قد يبطئ","يجب أن يبطئ","لن يبطئ"], a: 1, why: "may = احتمال وليس تأكيداً." },
    { q: "ما الشيء الممنوع تماماً؟", o: ["إغلاق البرامج","إطفاء الحاسوب أثناء التحديث","إنشاء حساب","تشغيل مكافح الفيروسات"], a: 1, why: "you must never turn off your computer during the update." }
  ]
},

/* ================= المرحلة 3 ================= */
{
  id: "l11", stage: "s3", title: "قراءة رسائل الأخطاء بدون خوف", minutes: 10,
  explain: `
  <p>رسالة الخطأ ليست عدوك، هي <b>أفضل صديق للمبرمج</b>. أغلبها مبني من قطع ثابتة تتكرر:</p>
  <table class="mini" dir="ltr"><tr><th>القطعة</th><th dir="rtl">معناها</th></tr>
  <tr><td>not found / does not exist</td><td dir="rtl">غير موجود</td></tr>
  <tr><td>permission denied / access denied</td><td dir="rtl">لا تملك صلاحية</td></tr>
  <tr><td>undefined / null</td><td dir="rtl">قيمة فارغة لم تُعرّف</td></tr>
  <tr><td>expected X but got Y</td><td dir="rtl">كان المتوقع X لكن وصل Y</td></tr>
  <tr><td>unexpected token</td><td dir="rtl">رمز في مكان غير متوقع (خطأ كتابة)</td></tr>
  <tr><td>timed out</td><td dir="rtl">انتهت المهلة</td></tr>
  <tr><td>failed to + فعل</td><td dir="rtl">فشل في ...</td></tr></table>
  <p><b>طريقة القراءة:</b> اقرأ <b>نوع الخطأ</b> (أول كلمة قبل النقطتين)، ثم <b>الرسالة</b>، ثم <b>اسم الملف ورقم السطر</b>.</p>`,
  examples: [
    { en: "FileNotFoundError: No such file or directory: 'data.csv'", ar: "خطأ ملف غير موجود: لا يوجد ملف أو مجلد بهذا الاسم 'data.csv'", note: "directory = مجلد" },
    { en: "TypeError: Cannot read properties of undefined (reading 'name')", ar: "خطأ نوع: لا يمكن قراءة خصائص قيمة غير معرّفة (أثناء قراءة 'name')", note: "المتغير الذي تقرأ منه name فارغ" },
    { en: "Error: listen EADDRINUSE: address already in use :::3000", ar: "خطأ: العنوان مستخدم بالفعل على المنفذ 3000", note: "already in use = مستخدم بالفعل: برنامج آخر يشغل المنفذ" }
  ],
  reading: {
    title: "Understanding a Stack Trace",
    paras: [
      { en: "When a program crashes, it often prints a stack trace. This is a list of the function calls that were active when the error occurred.", ar: "عندما ينهار برنامج، غالباً يطبع تتبع المكدس. وهو قائمة باستدعاءات الدوال التي كانت نشطة عند حدوث الخطأ." },
      { en: "Start reading from the line that mentions your own code, not the library code. That line usually shows the file name and the line number.", ar: "ابدأ القراءة من السطر الذي يذكر كودك أنت، وليس كود المكتبة. ذلك السطر عادة يعرض اسم الملف ورقم السطر." },
      { en: "If the message is still unclear, copy the first line of the error and search for it. Thousands of developers have probably seen the same error before.", ar: "إذا بقيت الرسالة غير واضحة، انسخ أول سطر من الخطأ وابحث عنه. على الأرجح رآه آلاف المطورين من قبل." }
    ]
  },
  vocab: [["error","خطأ"],["not found","غير موجود"],["directory","مجلد"],["permission denied","الإذن مرفوض"],["undefined","غير معرّف"],["expected","متوقع"],["unexpected","غير متوقع"],["token","رمز"],["timed out","انتهت المهلة"],["failed to","فشل في"],["already in use","مستخدم بالفعل"],["stack trace","تتبع المكدس"],["occur","يحدث"],["mention","يذكر"],["unclear","غير واضح"],["property","خاصية"]],
  quiz: [
    { q: "SyntaxError: Unexpected token '}' ماذا تعني غالباً؟", o: ["الملف غير موجود","يوجد قوس في مكان خاطئ أو ناقص","لا توجد صلاحية","الإنترنت مقطوع"], a: 1, why: "Unexpected token = رمز في مكان غير متوقع، غالباً قوس زائد أو ناقص." },
    { q: "Connection timed out معناها:", o: ["الاتصال ناجح","انتهت مهلة الاتصال","كلمة المرور خاطئة","الملف كبير"], a: 1, why: "timed out = انتهت المهلة قبل الرد." },
    { q: "من أين تبدأ قراءة stack trace حسب النص؟", o: ["من آخر سطر دائماً","من السطر الذي يذكر كودك أنت","من كود المكتبة","لا تقرأها"], a: 1, why: "Start reading from the line that mentions your own code." }
  ]
},
{
  id: "l12", stage: "s3", title: "قراءة التوثيق (Documentation)", minutes: 10,
  explain: `
  <p>أي توثيق تقني تقريباً له نفس الهيكل. إذا عرفت أسماء الأقسام عرفت أين تجد ما تريد:</p>
  <table class="mini" dir="ltr"><tr><th>القسم</th><th dir="rtl">ماذا تجد فيه</th></tr>
  <tr><td>Getting Started / Quickstart</td><td dir="rtl">أسرع طريق للتشغيل</td></tr>
  <tr><td>Prerequisites</td><td dir="rtl">ما يجب أن يكون عندك قبل البدء</td></tr>
  <tr><td>Installation</td><td dir="rtl">خطوات التثبيت</td></tr>
  <tr><td>Usage / Examples</td><td dir="rtl">كيف تستخدمه مع أمثلة</td></tr>
  <tr><td>API Reference</td><td dir="rtl">شرح كل دالة بالتفصيل</td></tr>
  <tr><td>Parameters / Arguments</td><td dir="rtl">المدخلات</td></tr>
  <tr><td>Returns</td><td dir="rtl">ما تُرجعه الدالة</td></tr>
  <tr><td>Troubleshooting / FAQ</td><td dir="rtl">حل المشاكل الشائعة</td></tr></table>`,
  examples: [
    { en: "Parameters: timeout (number, optional) — The maximum time to wait, in milliseconds. Defaults to 5000.", ar: "المعاملات: timeout (رقم، اختياري) — أقصى وقت للانتظار بالمللي ثانية. القيمة الافتراضية 5000.", note: "Defaults to = القيمة الافتراضية" },
    { en: "Returns: A Promise that resolves to the user object.", ar: "تُرجع: وعداً (Promise) ينتهي بكائن المستخدم.", note: "resolves to = ينتهي بنتيجة" },
    { en: "Throws: ValueError if the input is empty.", ar: "تُطلق: خطأ ValueError إذا كان المدخل فارغاً.", note: "throws = يرمي/يطلق خطأ" }
  ],
  reading: {
    title: "fetchUser(id, options)",
    paras: [
      { en: "Retrieves a single user from the server by their unique ID. This function is asynchronous and must be awaited.", ar: "تجلب مستخدماً واحداً من الخادم بواسطة معرفه الفريد. هذه الدالة غير متزامنة ويجب انتظارها بـ await." },
      { en: "The options argument is optional. If you pass cache: true, the result is saved locally and reused for later calls.", ar: "المعامل options اختياري. إذا مررت cache: true، تُحفظ النتيجة محلياً ويُعاد استخدامها في الاستدعاءات اللاحقة." },
      { en: "If no user matches the given ID, the function returns null instead of throwing an error.", ar: "إذا لم يطابق أي مستخدم المعرّف المعطى، تُرجع الدالة null بدلاً من إطلاق خطأ." }
    ]
  },
  vocab: [["documentation","التوثيق"],["getting started","البدء"],["prerequisites","المتطلبات المسبقة"],["usage","الاستخدام"],["reference","مرجع"],["parameter","معامل"],["argument","وسيط / معامل"],["return","يُرجع"],["throw","يطلق (خطأ)"],["defaults to","القيمة الافتراضية"],["retrieve","يجلب / يسترجع"],["unique","فريد"],["asynchronous","غير متزامن"],["pass","يمرّر"],["locally","محلياً"],["match","يطابق"],["troubleshooting","حل المشكلات"]],
  quiz: [
    { q: "ماذا تُرجع fetchUser إذا لم تجد المستخدم؟", o: ["خطأ","null","مصفوفة فارغة","false"], a: 1, why: "returns null instead of throwing an error." },
    { q: "في أي قسم تبحث إذا ظهرت لك مشكلة شائعة؟", o: ["Installation","API Reference","Troubleshooting","Prerequisites"], a: 2, why: "Troubleshooting = حل المشكلات." },
    { q: "Defaults to 5000 تعني:", o: ["الحد الأدنى 5000","القيمة الافتراضية 5000 إن لم تحدد غيرها","يجب أن تكون 5000","تنتهي بعد 5000 يوم"], a: 1, why: "defaults to = القيمة التي تُستخدم تلقائياً." }
  ]
},
{
  id: "l13", stage: "s3", title: "لغة منتديات المبرمجين", minutes: 9,
  explain: `
  <p>في مواقع الأسئلة البرمجية، الأسئلة والأجوبة لها عبارات تتكرر. إذا عرفتها ستعرف بسرعة إن كان هذا الحل يناسبك:</p>
  <table class="mini" dir="ltr"><tr><th>العبارة</th><th dir="rtl">المعنى</th></tr>
  <tr><td>I'm trying to...</td><td dir="rtl">أحاول أن... (هدف السائل)</td></tr>
  <tr><td>works fine, but...</td><td dir="rtl">يعمل جيداً لكن... (المشكلة بعدها)</td></tr>
  <tr><td>What am I missing?</td><td dir="rtl">ما الذي فاتني؟</td></tr>
  <tr><td>EDIT: / UPDATE:</td><td dir="rtl">تعديل لاحق من السائل، اقرأه!</td></tr>
  <tr><td>Possible duplicate of</td><td dir="rtl">سؤال مكرر، الجواب في رابط آخر</td></tr>
  <tr><td>This worked for me</td><td dir="rtl">هذا نجح معي</td></tr>
  <tr><td>workaround</td><td dir="rtl">حل التفافي مؤقت</td></tr>
  <tr><td>as of version X</td><td dir="rtl">ابتداءً من الإصدار X</td></tr></table>
  <p><b>نصيحة ذهبية:</b> انظر إلى <b>تاريخ الجواب</b> ورقم الإصدار. جواب من 2015 قد يكون قديماً.</p>`,
  examples: [
    { en: "I'm trying to center a div, but nothing seems to work.", ar: "أحاول توسيط عنصر div، لكن لا شيء يبدو أنه يعمل.", note: "seems to = يبدو أنه" },
    { en: "As of React 18, this approach is no longer necessary.", ar: "ابتداءً من React 18، هذه الطريقة لم تعد ضرورية.", note: "approach = طريقة/أسلوب" },
    { en: "This is a workaround, not a real fix.", ar: "هذا حل التفافي وليس إصلاحاً حقيقياً.", note: "" }
  ],
  reading: {
    title: "Q: CSS changes not showing up",
    paras: [
      { en: "I'm trying to update the colors on my website. The changes work fine on my laptop, but on my phone the old styles still appear. What am I missing?", ar: "أحاول تحديث الألوان في موقعي. التغييرات تعمل جيداً على اللابتوب، لكن على الجوال لا تزال الأنماط القديمة تظهر. ما الذي فاتني؟" },
      { en: "Answer: Your phone is probably showing a cached version of the CSS file. Try clearing the browser cache, or add a version number to the file name.", ar: "الجواب: جوالك على الأرجح يعرض نسخة مخزنة مؤقتاً من ملف CSS. جرّب مسح ذاكرة التخزين المؤقت للمتصفح، أو أضف رقم إصدار لاسم الملف." },
      { en: "EDIT: Clearing the cache solved it. Thanks! This answer saved me hours.", ar: "تعديل: مسح الذاكرة المؤقتة حل المشكلة. شكراً! هذا الجواب وفّر علي ساعات." }
    ]
  },
  vocab: [["I'm trying to","أحاول أن"],["works fine","يعمل جيداً"],["What am I missing","ما الذي فاتني"],["duplicate","مكرر"],["workaround","حل التفافي"],["as of","ابتداءً من"],["approach","طريقة / أسلوب"],["seem","يبدو"],["cache","ذاكرة مؤقتة"],["cached","مخزّن مؤقتاً"],["clear","يمسح"],["solve","يحل"],["probably","على الأرجح"],["necessary","ضروري"]],
  quiz: [
    { q: "ما المشكلة الأصلية للسائل؟", o: ["الموقع لا يفتح","تغييرات CSS لا تظهر على الجوال","اللابتوب معطل","الألوان تظهر في كل مكان"], a: 1, why: "work fine on my laptop, but on my phone the old styles still appear." },
    { q: "ماذا حل المشكلة في النهاية؟", o: ["إعادة كتابة الكود","مسح ذاكرة المتصفح المؤقتة","تغيير الجوال","حذف الموقع"], a: 1, why: "EDIT: Clearing the cache solved it." },
    { q: "Possible duplicate of... تعني:", o: ["الجواب خاطئ","السؤال مكرر وله جواب في مكان آخر","السؤال ممتاز","تم حذف السؤال"], a: 1, why: "duplicate = مكرر." }
  ]
},
{
  id: "l14", stage: "s3", title: "ملف README وكلمات Git", minutes: 8,
  explain: `
  <p>عند فتح أي مشروع مفتوح المصدر أول ما تراه ملف <b>README</b>. وهو يجيب عن: ما هذا المشروع؟ كيف أثبّته؟ كيف أستخدمه؟ كيف أساهم؟</p>
  <p>كلمات Git الأساسية:</p>
  <table class="mini" dir="ltr"><tr><th>الكلمة</th><th dir="rtl">المعنى</th></tr>
  <tr><td>repository (repo)</td><td dir="rtl">مستودع المشروع</td></tr>
  <tr><td>clone</td><td dir="rtl">نسخ المستودع لجهازك</td></tr>
  <tr><td>fork</td><td dir="rtl">نسخة منه في حسابك لتعدّل عليها</td></tr>
  <tr><td>commit</td><td dir="rtl">حفظ مجموعة تغييرات برسالة</td></tr>
  <tr><td>branch</td><td dir="rtl">فرع تطوير منفصل</td></tr>
  <tr><td>pull request (PR)</td><td dir="rtl">طلب دمج تعديلاتك</td></tr>
  <tr><td>issue</td><td dir="rtl">بلاغ عن مشكلة أو اقتراح</td></tr>
  <tr><td>contribute</td><td dir="rtl">يساهم</td></tr>
  <tr><td>license</td><td dir="rtl">الرخصة: ما المسموح لك</td></tr></table>`,
  examples: [
    { en: "Clone the repository and install the dependencies.", ar: "انسخ المستودع وثبّت الاعتماديات.", note: "dependencies = المكتبات التي يعتمد عليها المشروع" },
    { en: "Contributions are welcome! Please open an issue first to discuss what you would like to change.", ar: "المساهمات مرحب بها! من فضلك افتح بلاغاً أولاً لمناقشة ما تريد تغييره.", note: "" },
    { en: "This project is licensed under the MIT License.", ar: "هذا المشروع مرخص برخصة MIT.", note: "MIT رخصة متساهلة: يمكنك الاستخدام التجاري" }
  ],
  reading: {
    title: "README.md — quicknote",
    paras: [
      { en: "quicknote is a lightweight note-taking app that runs entirely in the terminal. It stores your notes as plain text files, so you never lose your data.", ar: "quicknote تطبيق خفيف لتدوين الملاحظات يعمل بالكامل داخل الطرفية. يخزن ملاحظاتك كملفات نصية عادية، فلن تفقد بياناتك أبداً." },
      { en: "To get started, clone this repo, then run npm install to install the dependencies. After that, run npm start.", ar: "للبدء، انسخ هذا المستودع، ثم شغّل npm install لتثبيت الاعتماديات. بعد ذلك شغّل npm start." },
      { en: "Found a bug? Please open an issue. Pull requests are welcome, but for major changes, please discuss them first.", ar: "وجدت خللاً؟ من فضلك افتح بلاغاً. طلبات الدمج مرحب بها، لكن للتغييرات الكبيرة ناقشها أولاً من فضلك." }
    ]
  },
  vocab: [["repository","مستودع"],["clone","ينسخ (مستودعاً)"],["fork","ينسخ لحسابه / تفرّع"],["commit","حفظ تغييرات"],["branch","فرع"],["pull request","طلب دمج"],["contribute","يساهم"],["contribution","مساهمة"],["license","رخصة"],["dependencies","الاعتماديات"],["lightweight","خفيف"],["entirely","بالكامل"],["plain text","نص عادي"],["welcome","مرحب به"],["major","كبير / رئيسي"],["discuss","يناقش"]],
  quiz: [
    { q: "ماذا تفعل إذا وجدت خللاً في quicknote؟", o: ["تحذف المشروع","تفتح issue","تعمل fork فقط","ترسل بريداً"], a: 1, why: "Found a bug? Please open an issue." },
    { q: "ما الأمر الذي يثبت الاعتماديات؟", o: ["npm start","git clone","npm install","git commit"], a: 2, why: "run npm install to install the dependencies." },
    { q: "Pull requests are welcome تعني:", o: ["يُمنع التعديل","طلبات دمج تعديلاتك مرحب بها","يجب الدفع أولاً","المشروع مغلق"], a: 1, why: "welcome = مرحب به." }
  ]
}
];
