/* بنك المفردات — الكلمات العامة (3) */
window.WORDBANK_RAW = window.WORDBANK_RAW || [];
window.WORDBANK_RAW.push({ cat: "general", title: "أشياء وأماكن من حولنا", text: `
table|طاولة / جدول|Put the book on the table.
chair|كرسي|Sit on a comfortable chair.
window|نافذة|Close the window.
wall|جدار|The map is on the wall.
floor|أرضية / طابق|The office is on the third floor.
street|شارع|The shop is on this street.
road|طريق|The road is closed.
building|مبنى|This building has ten floors.
market|سوق|The market for apps is growing.
shop|متجر|Visit our online shop.
store|متجر|The app is in the store.
bank|بنك|Open a bank account.
hospital|مستشفى|She works at a hospital.
airport|مطار|I read on the way to the airport.
station|محطة|Meet me at the station.
village|قرية|He grew up in a small village.
town|بلدة|It's a quiet town.
land|أرض|The land is very dry.
sea|بحر|The house is near the sea.
river|نهر|The river crosses the city.
mountain|جبل|We climbed a mountain.
tree|شجرة|Plant a tree.
sun|شمس|The sun is shining.
weather|طقس|The weather is nice today.
rain|مطر|It's raining.
fire|نار / حريق|There was a fire in the building.
air|هواء|Fresh air helps you think.
light|ضوء / خفيف|Turn on the light.
paper|ورق|Write it on paper.
picture|صورة|Look at the picture.
image|صورة|Upload an image.
box|صندوق|Check the box.
bag|حقيبة|Put the laptop in your bag.
key|مفتاح|I lost my keys.
food|طعام|Healthy food helps your brain.
bread|خبز|We bought fresh bread.
coffee|قهوة|I drink coffee while studying.
tea|شاي|Would you like some tea?
clothes|ملابس|Pack your clothes.
machine|آلة|The machine stopped working.
tool|أداة|This tool is very useful.
object|شيء / كائن|Each object has a name.
material|مادة|Download the course materials.
equipment|معدات|We need new equipment.
vehicle|مركبة|Electric vehicles are popular.
ticket|تذكرة|Buy a ticket online.
gift|هدية|This book was a gift.
price|سعر|Check the price.
cost|تكلفة / يكلّف|How much does it cost?
bill|فاتورة|Pay the bill online.
` });

window.WORDBANK_RAW.push({ cat: "general", title: "الأفعال المركبة الأكثر شيوعاً", text: `
find out|يكتشف / يعرف|Find out what the word means.
look up|يبحث عن (في قاموس)|Look up the word in a dictionary.
look for|يبحث عن|I'm looking for a good book.
look forward to|يتطلع إلى|I look forward to the next lesson.
give up|يستسلم|Never give up.
go on|يستمر|Go on, you're doing well.
come back|يعود|Come back tomorrow.
get up|يستيقظ / ينهض|I get up at six.
pick up|يلتقط / يتعلم بسهولة|You will pick up new words quickly.
turn on|يشغّل|Turn on the subtitles.
turn off|يطفئ|Turn off notifications.
set up|يُعدّ / يجهّز|Set up your account.
carry out|ينفّذ|Carry out the plan.
point out|يشير إلى / ينبّه|The teacher pointed out my mistake.
figure out|يفهم / يكتشف الحل|I figured out the answer.
work out|ينجح / يحل|It will work out.
come up with|يبتكر / يأتي بـ|Come up with a new idea.
deal with|يتعامل مع|How do you deal with stress?
go through|يمر بـ / يراجع|Go through the list again.
keep up|يواكب|Keep up the good work.
catch up|يلحق بـ|I need to catch up on my lessons.
fill in|يملأ|Fill in the blanks.
fill out|يعبّئ (نموذجاً)|Fill out this form.
sign up|يسجّل|Sign up for free.
log in|يسجّل الدخول|Log in to your account.
log out|يسجّل الخروج|Don't forget to log out.
check out|يتفقد / يدفع|Check out this website.
back up|ينسخ احتياطياً|Back up your files.
shut down|يُغلق (جهاز)|Shut down the computer.
break down|يتعطل / يفكك|Break down the sentence into parts.
run out of|ينفد منه|We ran out of time.
put off|يؤجل|Don't put off your practice.
take off|يقلع / يخلع|The plane took off.
take over|يتولى|A new manager took over.
bring up|يطرح (موضوعاً)|He brought up a good point.
end up|ينتهي به الأمر|I ended up reading the whole book.
show up|يظهر / يحضر|The error shows up on startup.
sort out|يرتّب / يحل|Let's sort out this problem.
stand out|يبرز|Your work stands out.
think about|يفكر في|Think about your goal.
rely on|يعتمد على|Don't rely on luck.
belong to|ينتمي إلى|This file belongs to the admin.
focus on|يركز على|Focus on the main idea.
depend on|يعتمد على|It depends on the context.
refer to|يشير إلى|"It" refers to the server.
consist of|يتكون من|The test consists of ten questions.
result in|يؤدي إلى|The bug resulted in data loss.
lead to|يؤدي إلى|Practice leads to progress.
get rid of|يتخلص من|Get rid of bad habits.
make sure|يتأكد|Make sure you saved the file.
` });

window.WORDBANK_RAW.push({ cat: "general", title: "تعابير تتكرر في الكتب والمقالات", text: `
in fact|في الواقع|In fact, it's easier than it looks.
of course|بالطبع|Of course you can.
for example|على سبيل المثال|For example, look at this sentence.
for instance|مثلاً|For instance, the word "run".
in addition|بالإضافة إلى ذلك|In addition, the app is free.
on the other hand|من ناحية أخرى|On the other hand, it's slow.
as a result|نتيجة لذلك|As a result, sales increased.
in general|بشكل عام|In general, the course is easy.
at least|على الأقل|Read at least one page.
at first|في البداية|At first, it was difficult.
at the same time|في الوقت نفسه|Listen and read at the same time.
in other words|بعبارة أخرى|In other words, practice daily.
in terms of|من حيث|In terms of price, it's the best.
in the end|في النهاية|In the end, I understood.
by the way|بالمناسبة|By the way, the app is free.
as well|أيضاً|I want to learn Python as well.
so far|حتى الآن|So far, so good.
no longer|لم يعد|This feature is no longer available.
more or less|تقريباً|It's more or less the same.
in particular|بشكل خاص|I like science books in particular.
on purpose|عمداً|He did it on purpose.
by mistake|عن طريق الخطأ|I deleted it by mistake.
in advance|مسبقاً|Thanks in advance.
on time|في الوقت المحدد|Submit your work on time.
at once|فوراً / دفعة واحدة|Don't learn everything at once.
step by step|خطوة بخطوة|Learn step by step.
little by little|شيئاً فشيئاً|Little by little, you will improve.
over and over|مراراً وتكراراً|Repeat the word over and over.
from now on|من الآن فصاعداً|From now on, I will read daily.
as usual|كالعادة|As usual, the class started on time.
in short|باختصار|In short, it works.
after all|في النهاية / رغم كل شيء|After all, practice is the key.
above all|قبل كل شيء|Above all, be patient.
on average|في المتوسط|On average, I learn ten words a day.
in my opinion|في رأيي|In my opinion, this is the best book.
to be honest|بصراحة|To be honest, I was afraid at first.
it is worth|يستحق|It is worth the effort.
take part in|يشارك في|Take part in the discussion.
pay attention to|ينتبه إلى|Pay attention to the details.
make progress|يحرز تقدماً|You are making progress.
make a decision|يتخذ قراراً|Make a decision today.
take advantage of|يستفيد من|Take advantage of free resources.
have to|يجب عليه|I have to finish this today.
used to|كان معتاداً على|I used to fear English.
be able to|يكون قادراً على|You will be able to read books.
be about to|على وشك|The class is about to start.
according to|وفقاً لـ|According to the study, reading helps.
due to|بسبب|The delay was due to an error.
in spite of|على الرغم من|In spite of the rain, we went out.
as far as|بقدر ما|As far as I know, it's free.
` });

window.WORDBANK_RAW.push({ cat: "general", title: "أسماء مجردة شائعة", text: `
society|مجتمع|Technology changes society.
culture|ثقافة|Language is part of culture.
economy|اقتصاد|The digital economy is growing.
market|سوق|The job market needs English.
industry|صناعة / قطاع|The tech industry is huge.
government|حكومة|The government passed a new law.
policy|سياسة|Read our privacy policy.
rule|قاعدة|Learn the basic rules.
right|حق|You have the right to know.
freedom|حرية|Freedom of choice.
responsibility|مسؤولية|Security is everyone's responsibility.
role|دور|What is your role in the team?
relationship|علاقة|The relationship between words.
environment|بيئة|Create a good study environment.
situation|موقف / وضع|Read the situation carefully.
condition|حالة / شرط|Read the terms and conditions.
process|عملية|Learning is a long process.
activity|نشاط|Reading is a calm activity.
event|حدث / فعالية|Join the online event.
action|إجراء / فعل|Take action now.
behavior|سلوك|The behavior of the app changed.
quality|جودة|The video quality is high.
value|قيمة|What is the value of x?
standard|معيار|This is the industry standard.
feature|ميزة|This feature is new.
character|شخصية / حرف|The password needs 8 characters.
nature|طبيعة|The nature of the problem is complex.
structure|بنية / هيكل|Understand the sentence structure.
pattern|نمط|Find the pattern.
model|نموذج|This is the new model.
form|شكل / نموذج|Fill in the form.
type|نوع|What type of file is it?
sort|نوع / يرتب|Sort the list by name.
style|أسلوب|I like his writing style.
version|إصدار|Update to the latest version.
copy|نسخة / ينسخ|Make a copy of the file.
source|مصدر|Check the source of the news.
resource|مورد|Free resources for learners.
reference|مرجع|Use this book as a reference.
link|رابط|Click the link.
access|وصول|You have full access.
control|تحكم|You are in control.
security|أمان / أمن|Security is important.
safety|سلامة|Safety first.
privacy|خصوصية|We respect your privacy.
risk|خطر / مخاطرة|There is a small risk.
danger|خطر|Danger! High voltage.
damage|ضرر|The virus caused damage.
benefit|فائدة|The benefits of reading.
advantage|ميزة / فائدة|English is a big advantage.
` });

window.WORDBANK_RAW.push({ cat: "general", title: "أسماء مجردة أخرى", text: `
disadvantage|عيب|The main disadvantage is the price.
difference|فرق|What's the difference?
similarity|تشابه|Notice the similarity.
relation|علاقة|In relation to this topic.
connection|اتصال / صلة|There is a connection between them.
position|موقع / منصب|Change the position of the image.
direction|اتجاه|Go in the right direction.
movement|حركة|The movement of data.
balance|توازن / رصيد|Keep a balance between work and study.
pressure|ضغط|Work under pressure.
support|دعم|Thanks for your support.
help|مساعدة|Do you need help?
effort|جهد|It takes effort.
attempt|محاولة|First attempt.
achievement|إنجاز|Finishing the course is an achievement.
award|جائزة|She won an award.
reward|مكافأة|Give yourself a reward.
prize|جائزة|The prize is a free course.
competition|منافسة|There is strong competition.
agreement|اتفاق|We reached an agreement.
contract|عقد|Sign the contract.
permission|إذن|Ask for permission.
choice|اختيار|It's your choice.
preference|تفضيل|Save your preferences.
need|حاجة|There is a need for teachers.
demand|طلب|High demand.
supply|عرض / إمداد|Supply and demand.
product|منتج|Our new product.
production|إنتاج|Production starts next month.
project|مشروع|My first project.
plan|خطة|What's your plan?
task|مهمة|Complete the task.
duty|واجب|It's my duty.
responsibility|مسؤولية|Take responsibility.
management|إدارة|Project management.
organization|منظمة / تنظيم|A non-profit organization.
department|قسم|The IT department.
career|مسيرة مهنية|English helps your career.
salary|راتب|A good salary.
income|دخل|Extra income.
cost|تكلفة|The cost is low.
budget|ميزانية|We have a small budget.
investment|استثمار|Learning is the best investment.
profit|ربح|The company made a profit.
trade|تجارة|International trade.
customer|عميل|Happy customers.
client|عميل|Meet the client.
owner|مالك|The owner of the account.
leader|قائد|A good leader listens.
partner|شريك|My business partner.
` });

window.WORDBANK_RAW.push({ cat: "general", title: "أضداد مفيدة للقراءة", text: `
increase|يزيد|Prices increase every year.
decrease|ينقص|Errors decreased after the update.
include|يشمل|The price includes tax.
exclude|يستثني|The price excludes shipping.
accept|يقبل|Accept the invitation.
refuse|يرفض|Refuse the request.
arrive|يصل|The package arrived.
depart|يغادر|The train departs at nine.
borrow|يستعير|Borrow a book from the library.
lend|يُعير|Can you lend me your pen?
buy|يشتري|Buy now.
sell|يبيع|Sell your old phone.
win|يفوز|Win the game.
lose|يخسر|Lose the match.
push|يدفع|Push the button.
pull|يسحب|Pull the door.
enter|يدخل|Enter your password.
exit|يخرج|Exit the program.
import|يستورد|Import your contacts.
export|يصدّر|Export the data as PDF.
upload|يرفع|Upload a photo.
download|ينزّل|Download the app.
save|يحفظ|Save your work.
delete|يحذف|Delete the file.
show|يُظهر|Show more.
hide|يخفي|Hide details.
enable|يفعّل|Enable notifications.
disable|يعطّل|Disable the camera.
connect|يتصل|Connect to Wi-Fi.
disconnect|يقطع الاتصال|Disconnect the device.
lock|يقفل|Lock your phone.
unlock|يفتح القفل|Unlock the next level.
expand|يوسّع|Expand the section.
collapse|يطوي / ينهار|Collapse all sections.
include|يتضمن|Include your name.
allow|يسمح|Allow access.
deny|يمنع / يرفض|Access denied.
public|عام|Public profile.
private|خاص|Private message.
simple|بسيط|Simple design.
complex|معقد|Complex system.
cheap|رخيص|A cheap option.
expensive|غالٍ|This course is expensive.
narrow|ضيق|A narrow street.
wide|واسع|A wide screen.
deep|عميق|A deep understanding.
shallow|سطحي|A shallow explanation.
inner|داخلي|The inner loop.
outer|خارجي|The outer layer.
upper|علوي|Upper case letters.
` });

window.WORDBANK_RAW.push({ cat: "general", title: "العمل والحياة المهنية", text: `
apply|يتقدم لـ|Apply for the job.
application|طلب / تطبيق|Fill out the application.
interview|مقابلة|I have a job interview.
hire|يوظف|They hired two developers.
employee|موظف|The company has 50 employees.
employer|صاحب العمل|My employer pays for courses.
colleague|زميل|Ask your colleague.
manager|مدير|Talk to your manager.
meeting|اجتماع|The meeting starts at ten.
report|تقرير|Write a weekly report.
document|مستند|Open the document.
file|ملف|Save the file.
folder|مجلد|Create a new folder.
deadline|موعد نهائي|Meet the deadline.
schedule|جدول زمني|Check the schedule.
goal|هدف|Set clear goals.
target|هدف / يستهدف|Our target is 1000 users.
performance|أداء|Improve your performance.
quality|جودة|High quality.
feedback|ملاحظات / تقييم|Give feedback.
experience|خبرة|Five years of experience.
qualification|مؤهل|What are your qualifications?
requirement|متطلب|Job requirements.
responsible|مسؤول|Who is responsible?
professional|محترف / مهني|A professional developer.
remote|عن بعد|I work remotely.
freelance|عمل حر|I do freelance work.
contract|عقد|A one-year contract.
promotion|ترقية|She got a promotion.
resign|يستقيل|He resigned last month.
retire|يتقاعد|He retired at 60.
earn|يكسب|Earn more money.
benefit|ميزة / فائدة|Health benefits.
training|تدريب|Training for new staff.
workshop|ورشة عمل|Join the workshop.
conference|مؤتمر|A tech conference.
presentation|عرض تقديمي|Prepare a presentation.
proposal|اقتراح / عرض|Send the proposal.
negotiate|يتفاوض|Negotiate the price.
deal|صفقة|It's a good deal.
partner|شريك|A business partner.
startup|شركة ناشئة|Join a startup.
launch|يطلق|Launch the product.
brand|علامة تجارية|A famous brand.
marketing|التسويق|Digital marketing.
sales|المبيعات|Sales increased.
customer service|خدمة العملاء|Call customer service.
support team|فريق الدعم|Contact the support team.
schedule a meeting|يحدد موعد اجتماع|Let's schedule a meeting.
office hours|ساعات العمل|Office hours are 9 to 5.
` });

window.WORDBANK_RAW.push({ cat: "general", title: "العلم والطبيعة والصحة", text: `
science|علم|Computer science.
scientist|عالِم|Scientists discovered a new planet.
experiment|تجربة علمية|Do a simple experiment.
data|بيانات|Collect the data.
analysis|تحليل|Data analysis.
observe|يلاحظ / يراقب|Observe the results.
energy|طاقة|Solar energy.
heat|حرارة|Heat makes metal expand.
temperature|درجة الحرارة|Check the temperature.
planet|كوكب|Earth is our planet.
space|فضاء / مساحة|Free up disk space.
earth|الأرض|The Earth moves around the Sun.
nature|طبيعة|Walk in nature.
animal|حيوان|Wild animals.
plant|نبات / مصنع|Water the plants.
species|نوع (كائنات)|A rare species.
climate|مناخ|Climate change.
pollution|تلوث|Air pollution.
resource|مورد|Natural resources.
health|صحة|Mental health.
disease|مرض|Heart disease.
medicine|دواء / طب|Take your medicine.
doctor|طبيب|See a doctor.
patient|مريض|The doctor checked the patient.
treatment|علاج|A new treatment.
brain|دماغ|The brain loves repetition.
memory|ذاكرة|Long-term memory.
sleep|نوم|Sleep helps learning.
exercise|تمرين رياضي|Exercise every day.
diet|نظام غذائي|A healthy diet.
cell|خلية|Body cells.
blood|دم|Blood pressure.
growth|نمو|Plant growth.
evolution|تطور|The evolution of technology.
discovery|اكتشاف|A great discovery.
invention|اختراع|The invention of the internet.
technology|تقنية|Modern technology.
digital|رقمي|Digital skills.
electric|كهربائي|Electric cars.
device|جهاز|Mobile devices.
signal|إشارة|Weak signal.
wave|موجة|Radio waves.
light|ضوء|The speed of light.
speed|سرعة|Internet speed.
pressure|ضغط|Air pressure.
surface|سطح|The surface of the screen.
layer|طبقة|The top layer.
sample|عينة|A sample of the data.
method|طريقة|Scientific method.
result|نتيجة|The results are clear.
` });
