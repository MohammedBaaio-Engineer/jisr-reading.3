/* بنك المفردات — الكلمات العامة (1): أكثر الكلمات تكراراً في الإنجليزية
   الصيغة: الكلمة|المعنى|مثال */
window.WORDBANK_RAW = window.WORDBANK_RAW || [];
window.WORDBANK_RAW.push({ cat: "general", title: "أفعال لا يخلو منها نص", text: `
be|يكون|Learning a new language can be fun.
have|يملك / لديه|I have two questions about this lesson.
do|يفعل|What do you do every morning?
say|يقول|The teacher said the test is easy.
get|يحصل على|You will get a certificate at the end.
make|يصنع / يجعل|Small steps make a big difference.
go|يذهب|Let's go to the next page.
know|يعرف|I know the answer to this question.
take|يأخذ|Take a short break after each lesson.
see|يرى|Can you see the button on the left?
come|يأتي|Come back tomorrow for a new lesson.
think|يفكر / يظن|I think this book is very useful.
look|ينظر / يبدو|Look at the first line of the error.
want|يريد|I want to read English books.
give|يعطي|Give yourself time to learn.
use|يستخدم|You can use this tool for free.
find|يجد|I can't find my notes.
tell|يخبر|Tell me what you learned today.
ask|يسأل / يطلب|Don't be afraid to ask questions.
work|يعمل / عمل|The program works on all phones.
seem|يبدو|The problem seems simple.
feel|يشعر|I feel more confident now.
try|يحاول / يجرب|Try to read one page every day.
leave|يغادر / يترك|Please leave a comment below.
call|يتصل / يسمّي|We call this function at the start.
need|يحتاج|You need a computer for this course.
mean|يعني|What does this word mean?
keep|يحافظ / يستمر|Keep practicing every day.
let|يدع / يسمح|Let me explain the idea again.
begin|يبدأ|The course begins next week.
help|يساعد|This guide will help you.
show|يعرض / يُظهر|The chart shows our progress.
hear|يسمع|I heard about this course from a friend.
play|يلعب / يشغّل|Press play to start the video.
run|يجري / يشغّل|Run the program and check the result.
move|يتحرك / ينقل|Move the file to another folder.
like|يحب / مثل|I like short and clear lessons.
live|يعيش|Many developers live in big cities.
believe|يعتقد / يصدق|I believe you can do it.
bring|يُحضر|Bring your laptop to the class.
happen|يحدث|What happens when I click here?
write|يكتب|Write the new words in your notebook.
provide|يوفّر|The website provides free lessons.
sit|يجلس|Sit in a quiet place to study.
stand|يقف / يتحمل|Stand up and take a short walk.
lose|يفقد / يخسر|Don't lose your password.
pay|يدفع|You pay once and keep the course forever.
meet|يقابل|We meet every Monday online.
include|يشمل|The price includes all updates.
continue|يستمر / يتابع|Click Continue to go to the next step.
` });

window.WORDBANK_RAW.push({ cat: "general", title: "أفعال يومية شائعة", text: `
set|يضبط / يضع|Set a goal for this week.
learn|يتعلم|I learn ten new words every day.
change|يغيّر|You can change the language in settings.
lead|يقود / يؤدي إلى|Practice leads to better results.
understand|يفهم|Now I understand the main idea.
watch|يشاهد|Watch the video before the quiz.
follow|يتبع|Follow the steps in order.
stop|يتوقف / يوقف|Stop the video and try it yourself.
create|ينشئ|Create a new account.
speak|يتحدث|She speaks three languages.
read|يقرأ|I read an article every night.
allow|يسمح|The app allows offline reading.
add|يضيف|Add this word to your list.
spend|يقضي / ينفق|I spend twenty minutes on English daily.
grow|ينمو|Your vocabulary grows with practice.
open|يفتح|Open the book at page ten.
walk|يمشي|I walk to work every morning.
win|يفوز|Our team won the competition.
offer|يعرض / يقدّم|The site offers a free trial.
remember|يتذكر|I remember this word now.
love|يحب|I love learning new things.
consider|يعتبر / يفكر في|Consider your goals before you start.
appear|يظهر|A message will appear on the screen.
buy|يشتري|I bought a new laptop.
wait|ينتظر|Wait until the download finishes.
serve|يخدم|The server serves thousands of users.
die|يموت / يتوقف|The battery died during the call.
send|يرسل|Send me the link, please.
expect|يتوقع|I expected the test to be harder.
build|يبني|We will build a website together.
stay|يبقى|Stay focused for twenty minutes.
fall|يسقط|Prices fell last month.
cut|يقطع / يقلل|Cut the long sentence into parts.
reach|يصل إلى|We reached our goal early.
kill|يقتل / ينهي|Kill the process if it stops responding.
remain|يبقى / يظل|One question remains open.
suggest|يقترح|I suggest reading the summary first.
raise|يرفع / يثير|Raise your hand if you have a question.
pass|ينجح / يمرر|I passed the exam.
sell|يبيع|They sell courses online.
require|يتطلب|This job requires good English.
report|يبلّغ / تقرير|Report any problem to the team.
decide|يقرر|Decide what you want to learn first.
pull|يسحب|Pull the latest changes from the server.
return|يعود / يُرجع|Return to the main menu.
explain|يشرح|Can you explain this sentence?
hope|يأمل|I hope this helps you.
develop|يطوّر|We develop apps for students.
carry|يحمل|This bag carries my laptop.
break|يكسر / استراحة|Take a break every hour.
` });

window.WORDBANK_RAW.push({ cat: "general", title: "أفعال الفهم والتفكير", text: `
receive|يستلم|You will receive an email soon.
agree|يوافق|I agree with your idea.
support|يدعم|The app supports Arabic.
hit|يضرب / يصيب|Hit Enter to search.
produce|ينتج|The factory produces phones.
eat|يأكل|We eat lunch at one o'clock.
cover|يغطي|This lesson covers basic grammar.
catch|يمسك / يلتقط|Catch the error before it crashes.
draw|يرسم / يسحب|Draw a simple diagram.
choose|يختار|Choose the correct answer.
cause|يسبب|What caused the problem?
point|يشير|Point to the word you don't know.
listen|يستمع|Listen to the sentence twice.
realize|يدرك|I realized my mistake.
place|يضع / مكان|Place the cursor at the end.
close|يغلق / قريب|Close all other windows.
involve|يتضمن / يشمل|The job involves a lot of reading.
increase|يزيد|Reading increases your vocabulary.
reduce|يقلل|Short lessons reduce stress.
describe|يصف|Describe the picture in one sentence.
prove|يثبت|Prove that your code works.
plan|يخطط|Plan your week on Sunday.
apply|يطبّق / يتقدم|Apply the rule to a new example.
compare|يقارن|Compare the two versions.
accept|يقبل|Accept the terms to continue.
improve|يحسّن|Daily reading improves your English.
prepare|يحضّر|Prepare your questions before the meeting.
discover|يكتشف|I discovered a great website.
ensure|يضمن|Ensure that the file is saved.
check|يفحص / يتأكد|Check your spelling.
fill|يملأ|Fill in the form.
manage|يدير / يتمكن|She manages a small team.
note|يلاحظ / ملاحظة|Note the date at the top.
join|ينضم|Join our community online.
avoid|يتجنب|Avoid long breaks between lessons.
imagine|يتخيل|Imagine reading English easily.
mention|يذكر|The article mentions three ideas.
contain|يحتوي|The box contains ten items.
enjoy|يستمتع|Enjoy the process of learning.
wonder|يتساءل|I wonder how this works.
attempt|يحاول / محاولة|This is my second attempt.
recognize|يتعرف على|I recognize this word now.
represent|يمثّل|Each dot represents a user.
identify|يحدد / يتعرف|Identify the main verb.
focus|يركز|Focus on one skill at a time.
depend|يعتمد|It depends on your goal.
solve|يحل|We solved the problem together.
answer|يجيب / جواب|Answer all the questions.
fix|يصلح|They fixed the bug quickly.
share|يشارك|Share your notes with friends.
` });

window.WORDBANK_RAW.push({ cat: "general", title: "أسماء يومية أساسية", text: `
time|وقت|I don't have much time today.
year|سنة|I started learning last year.
people|ناس|Many people learn English online.
way|طريقة / طريق|This is the best way to learn.
day|يوم|Read one page a day.
man|رجل|The man in the video is the teacher.
thing|شيء|The first thing to do is relax.
woman|امرأة|The woman explained the idea clearly.
life|حياة|English changed my life.
child|طفل|Every child can learn a language.
world|عالم|English is used around the world.
school|مدرسة|I studied English at school.
state|حالة / ولاية|Save the current state of the app.
family|عائلة|My family supports my studies.
student|طالب|Every student gets a certificate.
group|مجموعة|Join a study group.
country|دولة|Which country are you from?
problem|مشكلة|Every problem has a solution.
hand|يد|Raise your hand.
part|جزء|This is the hardest part.
place|مكان|Find a quiet place to read.
case|حالة / قضية|In this case, restart the app.
week|أسبوع|The course takes four weeks.
company|شركة|He works for a tech company.
system|نظام|The system is down for maintenance.
program|برنامج|Install the program on your PC.
question|سؤال|That is a good question.
work|عمل|I go to work at eight.
number|رقم / عدد|Enter your phone number.
night|ليلة / مساء|I study at night.
point|نقطة|You earn points for each lesson.
home|منزل|I study at home.
water|ماء|Drink water while you study.
room|غرفة|My room is quiet.
mother|أم|My mother speaks English well.
area|منطقة / مجال|This area is new to me.
money|مال|Save money with the yearly plan.
story|قصة|I read a short story in English.
fact|حقيقة|It is a fact that practice helps.
month|شهر|Pay monthly or yearly.
lot|كثير (a lot)|I learned a lot today.
right|حق / صحيح|You have the right to cancel.
study|دراسة / يدرس|This study shows good results.
book|كتاب|This book is easy to read.
eye|عين|Rest your eyes after reading.
job|وظيفة|English helped me get a job.
word|كلمة|Learn ten words a day.
business|عمل تجاري|She runs an online business.
issue|مشكلة / قضية|We fixed the issue.
side|جانب|Click the icon on the left side.
` });

window.WORDBANK_RAW.push({ cat: "general", title: "أسماء الناس والمجتمع", text: `
kind|نوع / لطيف|What kind of books do you like?
head|رأس / رئيس|He is the head of the team.
house|بيت|Their house is near the school.
service|خدمة|Contact customer service for help.
friend|صديق|My friend recommended this app.
father|أب|My father works as an engineer.
power|قوة / طاقة|Turn off the power before you start.
hour|ساعة|The video is one hour long.
game|لعبة|Learning feels like a game.
line|سطر / خط|Read the first line carefully.
end|نهاية|Read until the end of the page.
member|عضو|Members get free updates.
law|قانون|The new law protects user data.
car|سيارة|I listen to lessons in the car.
city|مدينة|The city has a big library.
community|مجتمع|Our community helps beginners.
name|اسم|Write your full name.
president|رئيس|The president of the company spoke.
team|فريق|Our team works remotely.
minute|دقيقة|Give me five minutes.
idea|فكرة|I have an idea for an app.
kid|طفل|Kids learn languages quickly.
body|جسم / متن|Write the message in the body.
information|معلومات|Find more information on our website.
parent|والد|Parents can track their children's progress.
face|وجه / يواجه|We face many challenges.
others|الآخرون|Help others when you can.
level|مستوى|You reached a new level.
office|مكتب|I work from the office on Mondays.
door|باب|Close the door to avoid noise.
health|صحة|Sleep is important for your health.
person|شخص|Each person learns differently.
art|فن|Programming is an art.
war|حرب|The book is about the war.
history|تاريخ|Check the history of changes.
party|حفلة / طرف|Both parties must agree.
result|نتيجة|Check the result of the test.
morning|صباح|I study in the morning.
reason|سبب|What is the reason for the error?
research|بحث|Research shows that sleep helps memory.
girl|فتاة|The girl won the prize.
guy|شخص / رجل|This guy explains things very well.
moment|لحظة|Wait a moment.
teacher|معلم|The teacher answered all questions.
force|قوة / يجبر|Don't force yourself to memorize everything.
education|تعليم|Education opens many doors.
user|مستخدم|The user forgot the password.
customer|عميل|The customer asked for a refund.
staff|موظفون|Our staff will help you.
expert|خبير|Ask an expert for advice.
` });

window.WORDBANK_RAW.push({ cat: "general", title: "الصفات الأكثر استخداماً", text: `
good|جيد|This is a good start.
new|جديد|Learn a new word today.
first|أول|My first lesson was easy.
last|أخير / ماضٍ|The last chapter is the best.
long|طويل|This sentence is too long.
great|عظيم / رائع|Great job!
little|صغير / قليل|I know a little English.
own|خاص (بي)|Use your own words.
other|آخر|Try the other option.
old|قديم / كبير السن|Delete the old version.
big|كبير|This is a big project.
high|عالٍ|The price is too high.
different|مختلف|Every learner is different.
small|صغير|Start with small goals.
large|كبير|Large files take longer to upload.
next|التالي|Go to the next lesson.
early|مبكر|I wake up early to study.
young|شاب / صغير|Young people use this app a lot.
important|مهم|This is an important rule.
few|قليل (عدد)|Only a few people finished the course.
public|عام|This is a public page.
bad|سيئ|It's not a bad idea.
same|نفس|We have the same problem.
able|قادر|You will be able to read articles.
free|مجاني / حر|The course is free.
sure|متأكد|Are you sure?
real|حقيقي|We work on real projects.
best|الأفضل|This is the best method.
better|أفضل|Your English is getting better.
easy|سهل|The first lessons are easy.
hard|صعب / بجد|Work hard and stay patient.
possible|ممكن|Is it possible to change my answer?
clear|واضح|The instructions are clear.
whole|كامل|I read the whole book.
special|خاص / مميز|This is a special offer.
certain|متأكد / معين|Certain words appear in every text.
full|ممتلئ / كامل|Read the full article.
simple|بسيط|Keep your sentences simple.
low|منخفض|The battery is low.
strong|قوي|Use a strong password.
main|رئيسي|What is the main idea?
true|صحيح|Is this sentence true or false?
short|قصير|Read short texts first.
open|مفتوح|The library is open until eight.
common|شائع|This is a common mistake.
current|حالي|What is your current level?
available|متاح|The app is available on Android.
similar|مشابه|These two words are similar.
quick|سريع|Here is a quick tip.
recent|حديث|Read the recent news.
` });

window.WORDBANK_RAW.push({ cat: "general", title: "صفات للوصف والحكم", text: `
whole|كامل|The whole team agreed.
human|إنساني / إنسان|Humans make mistakes.
local|محلي|Save the file on your local drive.
late|متأخر|Sorry, I'm late.
hard|صعب|The last question was hard.
major|رئيسي / كبير|This is a major update.
personal|شخصي|Keep your personal data safe.
wrong|خاطئ|That answer is wrong.
national|وطني|It is a national holiday.
natural|طبيعي|It is natural to feel nervous.
physical|جسدي / مادي|Physical activity helps your brain.
final|نهائي|This is the final exam.
huge|ضخم|The internet is a huge library.
ready|جاهز|Are you ready to start?
private|خاص|Your notes are private.
serious|جاد / خطير|This is a serious problem.
happy|سعيد|I'm happy with my progress.
difficult|صعب|Grammar is not as difficult as it looks.
popular|شائع / مشهور|Python is a popular language.
basic|أساسي|Start with basic words.
modern|حديث|This is a modern design.
safe|آمن|Is this website safe?
useful|مفيد|This dictionary is very useful.
successful|ناجح|The launch was successful.
ancient|قديم جداً|We read about ancient history.
exact|دقيق / بالضبط|Write the exact words.
complex|معقد|This is a complex topic.
global|عالمي|English is a global language.
correct|صحيح|Choose the correct answer.
empty|فارغ|The list is empty.
entire|كامل|I read the entire chapter.
fair|عادل|The test was fair.
fresh|طازج / جديد|Start each day fresh.
heavy|ثقيل|The laptop is heavy.
nice|لطيف|Nice to meet you.
poor|فقير / ضعيف|The connection is poor.
proper|مناسب / صحيح|Use the proper format.
quiet|هادئ|I need a quiet room.
rich|غني|English has a rich vocabulary.
similar|مشابه|Try a similar example.
smart|ذكي|This is a smart solution.
specific|محدد|Give a specific example.
strange|غريب|I heard a strange noise.
typical|نموذجي / معتاد|A typical day starts at eight.
various|متنوع|We offer various courses.
whole|كل / كامل|Read the whole sentence first.
wide|واسع|The app has a wide range of features.
wonderful|رائع|What a wonderful idea!
worth|يستحق|This book is worth reading.
aware|مدرك / واعٍ|Be aware of fake websites.
` });

window.WORDBANK_RAW.push({ cat: "general", title: "ظروف وكلمات توجيه الجملة", text: `
also|أيضاً|I also study at night.
very|جداً|This is very useful.
often|غالباً|I often read before bed.
however|ومع ذلك / لكن|It's hard. However, it's possible.
too|أيضاً / جداً|This book is too long.
usually|عادةً|I usually study in the morning.
really|حقاً|I really enjoyed the lesson.
early|مبكراً|Come early to get a seat.
never|أبداً|Never share your password.
always|دائماً|Always read the instructions.
sometimes|أحياناً|Sometimes I watch videos in English.
together|معاً|Let's solve it together.
likely|من المحتمل|It is likely to rain today.
simply|ببساطة|Simply click the button.
generally|عموماً|Generally, short lessons work better.
instead|بدلاً من ذلك|Read instead of watching TV.
actually|في الواقع|Actually, it's easier than it looks.
already|بالفعل|I already finished the lesson.
enough|كافٍ / بما يكفي|Is ten minutes enough?
both|كلاهما|Both answers are correct.
probably|على الأرجح|You probably know this word.
quickly|بسرعة|Answer quickly.
almost|تقريباً|I'm almost done.
especially|خصوصاً|Read every day, especially in the morning.
finally|أخيراً|I finally understood the rule.
recently|مؤخراً|I recently started reading books.
directly|مباشرة|Contact us directly.
certainly|بالتأكيد|You will certainly improve.
clearly|بوضوح|Speak clearly.
exactly|بالضبط|That's exactly right.
nearly|تقريباً|Nearly everyone passed the test.
rather|بالأحرى / إلى حد ما|The lesson was rather short.
quite|تماماً / إلى حد كبير|The text is quite easy.
perhaps|ربما|Perhaps we can try again.
therefore|لذلك|I practice daily; therefore, I improve.
thus|وبالتالي|Thus, the result is correct.
indeed|بالفعل / حقاً|It was indeed a great course.
anyway|على أي حال|Anyway, let's continue.
otherwise|وإلا|Save your work; otherwise, you will lose it.
meanwhile|في هذه الأثناء|Meanwhile, read the next page.
suddenly|فجأة|The screen suddenly turned black.
immediately|فوراً|Update immediately.
eventually|في النهاية|Eventually, you will read fluently.
completely|تماماً|I completely forgot.
currently|حالياً|I am currently on level three.
easily|بسهولة|You can easily change the settings.
fully|بالكامل|The app is fully free.
mostly|غالباً|The text is mostly easy.
slowly|ببطء|Read slowly at first.
regularly|بانتظام|Review your words regularly.
` });

window.WORDBANK_RAW.push({ cat: "general", title: "أدوات الربط والعلاقات", text: `
because|لأن|I study because I want a better job.
although|رغم أن|Although it is hard, I enjoy it.
unless|إلا إذا|Don't stop unless you are tired.
while|بينما|Listen while you read.
whether|سواء / ما إذا|I don't know whether it works.
since|منذ / بما أن|I have studied since January.
until|حتى|Wait until the end.
though|مع أن|It's late, though I'm not tired.
whereas|بينما (مقارنة)|Some learn fast, whereas others need time.
despite|بالرغم من|Despite the noise, I finished reading.
besides|بالإضافة إلى|Besides English, I study math.
according|وفقاً (according to)|According to the report, sales grew.
throughout|طوال|Stay focused throughout the lesson.
within|خلال / ضمن|Reply within two days.
without|بدون|You can learn without a teacher.
toward|نحو|Every lesson is a step toward your goal.
beyond|ما وراء|Think beyond the basics.
among|بين (أكثر من اثنين)|English is popular among students.
upon|عند / على|Upon arrival, call me.
against|ضد|Protect your device against viruses.
due|بسبب (due to)|The delay was due to bad weather.
except|باستثناء|All lessons are free except the last one.
including|بما في ذلك|Ten items, including the book.
regarding|بخصوص|I have a question regarding the course.
via|عبر|Send the file via email.
per|لكل|Ten dollars per month.
whenever|كلما|Ask whenever you need help.
wherever|أينما|Study wherever you are.
whatever|أياً كان|Do whatever works for you.
either|إما / أيٌّ من|You can choose either option.
neither|لا هذا ولا ذاك|Neither answer is correct.
nor|ولا|I have neither time nor money.
yet|بعد / حتى الآن|I haven't finished yet.
still|لا يزال|I'm still learning.
even|حتى|Even experts make mistakes.
just|فقط / للتو|I just finished the quiz.
only|فقط|Only one answer is correct.
once|مرة / بمجرد|Once you finish, click Submit.
twice|مرتين|Read the text twice.
again|مرة أخرى|Try again.
instead of|بدلاً من|Use your phone instead of paper.
as well as|بالإضافة إلى|Reading as well as listening.
in order to|من أجل|I read in order to learn.
so that|لكي|Speak slowly so that I understand.
even though|رغم أن|Even though it rained, we went out.
as long as|طالما|You will improve as long as you practice.
as soon as|بمجرد أن|Call me as soon as you arrive.
in case|في حال|Save a copy in case of problems.
rather than|بدلاً من|Read rather than translate.
such as|مثل|Languages such as English and French.
` });
