/* بنك المفردات — الكلمات التقنية (2): الشبكات والأمن والكورسات */
window.WORDBANK_RAW = window.WORDBANK_RAW || [];
window.WORDBANK_RAW.push({ cat: "tech", title: "الشبكات: المكونات", text: `
network|شبكة|Connect to the network.
internet|الإنترنت|The internet is down.
connection|اتصال|A slow connection.
router|موجّه (راوتر)|Restart the router.
switch|مبدّل|A network switch.
modem|مودم|The modem lights are blinking.
access point|نقطة وصول|Install a wireless access point.
Wi-Fi|شبكة لاسلكية|Connect to Wi-Fi.
wireless|لاسلكي|A wireless network.
wired|سلكي|A wired connection is faster.
Ethernet|إيثرنت (شبكة سلكية)|Use an Ethernet cable.
cable|كابل|A fiber cable.
fiber|ألياف ضوئية|Fiber internet.
node|عقدة|Each device is a node.
host|مضيف|A host on the network.
server|خادم|A web server.
client|عميل|The client connects to the server.
peer|نظير|Peer-to-peer network.
gateway|بوابة|The default gateway.
interface|واجهة شبكة|The network interface.
adapter|محوّل / بطاقة شبكة|A network adapter.
topology|مخطط الشبكة|A star topology.
LAN|شبكة محلية|A small office LAN.
WAN|شبكة واسعة|Connect offices over a WAN.
VPN|شبكة افتراضية خاصة|Connect through a VPN.
VLAN|شبكة محلية افتراضية|Create a VLAN for guests.
subnet|شبكة فرعية|Divide the network into subnets.
segment|قطاع|A network segment.
infrastructure|بنية تحتية|Network infrastructure.
data center|مركز بيانات|A large data center.
rack|خزانة أجهزة|Install the server in the rack.
link|وصلة|The link is down.
uplink|وصلة صاعدة|The uplink port.
backbone|العمود الفقري للشبكة|The internet backbone.
coverage|تغطية|Wi-Fi coverage.
signal strength|قوة الإشارة|Check the signal strength.
interference|تداخل|Wireless interference.
range|مدى|Out of range.
hub|موزع|An old network hub.
repeater|مكرر إشارة|Use a repeater to extend Wi-Fi.
load balancer|موازن الأحمال|A load balancer spreads traffic.
proxy|وكيل|A proxy server.
firewall|جدار ناري|Configure the firewall.
cloud|سحابة|Cloud networking.
virtual|افتراضي|A virtual network.
physical|مادي|The physical layer.
device|جهاز|Connected devices.
endpoint|جهاز طرفي|Protect every endpoint.
online|متصل|The server is online.
offline|غير متصل|The printer is offline.
` });

window.WORDBANK_RAW.push({ cat: "tech", title: "الشبكات: البروتوكولات والعناوين", text: `
protocol|بروتوكول|TCP is a protocol.
packet|حزمة|Packets travel across the network.
frame|إطار|An Ethernet frame.
header|ترويسة|The packet header.
payload|الحمولة (البيانات)|The payload contains the data.
IP address|عنوان IP|Find your IP address.
MAC address|العنوان الفيزيائي|Each card has a MAC address.
port|منفذ|Port 80 is for HTTP.
DNS|نظام أسماء النطاقات|DNS translates names to IPs.
DHCP|بروتوكول توزيع العناوين|DHCP assigns IP addresses.
TCP|بروتوكول التحكم بالنقل|TCP is reliable.
UDP|بروتوكول بيانات المستخدم|UDP is fast.
HTTP|بروتوكول نقل النص|HTTP is not encrypted.
HTTPS|HTTP الآمن|Always use HTTPS.
SSH|اتصال آمن عن بعد|Connect with SSH.
FTP|بروتوكول نقل الملفات|Upload via FTP.
handshake|المصافحة|The TCP handshake.
session|جلسة|A secure session.
routing|التوجيه|Routing tables.
route|مسار / يوجّه|The best route.
hop|قفزة|The packet made five hops.
address|عنوان|A private address.
static|ثابت|A static IP.
dynamic|متغير|A dynamic IP.
IPv4|الإصدار 4 من IP|An IPv4 address.
IPv6|الإصدار 6 من IP|IPv6 has more addresses.
mask|قناع|The subnet mask.
NAT|ترجمة العناوين|NAT hides private IPs.
broadcast|بث لكل الأجهزة|A broadcast message.
multicast|بث لمجموعة|Multicast traffic.
unicast|إرسال لجهاز واحد|Unicast traffic.
layer|طبقة|The OSI model has seven layers.
OSI model|نموذج OSI|Learn the OSI model.
transport|النقل|The transport layer.
application layer|طبقة التطبيقات|HTTP works at the application layer.
encapsulation|التغليف|Data encapsulation.
bandwidth|عرض النطاق|High bandwidth.
throughput|معدل النقل الفعلي|Measure the throughput.
latency|زمن التأخير|Low latency.
ping|أمر فحص الاتصال|Ping the server.
traceroute|تتبع المسار|Run traceroute.
packet loss|فقدان الحزم|High packet loss.
jitter|تذبذب التأخير|Jitter affects calls.
congestion|ازدحام|Network congestion.
traffic|حركة البيانات|Monitor the traffic.
configure|يهيّئ / يضبط|Configure the router.
configuration|الإعدادات|Save the configuration.
troubleshoot|يحل المشكلات|Troubleshoot the network.
diagnose|يشخّص|Diagnose the problem.
reachable|يمكن الوصول إليه|The host is not reachable.
` });

window.WORDBANK_RAW.push({ cat: "tech", title: "أمن المعلومات: المفاهيم", text: `
security|الأمن|Information security.
cybersecurity|الأمن السيبراني|A career in cybersecurity.
threat|تهديد|A new threat.
risk|خطر|Assess the risk.
vulnerability|ثغرة|Patch the vulnerability.
exploit|استغلال|A public exploit.
attack|هجوم|A brute-force attack.
attacker|مهاجم|The attacker gained access.
hacker|مخترق|An ethical hacker.
breach|اختراق / تسرب|A data breach.
incident|حادثة أمنية|Report the incident.
compromise|يخترق / اختراق|The server was compromised.
confidentiality|السرية|Protect confidentiality.
integrity|السلامة / عدم التلاعب|Data integrity.
availability|التوافر|High availability.
authentication|المصادقة|Two-factor authentication.
authorization|التفويض|Check authorization.
identity|الهوية|Verify your identity.
credential|بيانات الاعتماد|Stolen credentials.
privilege|صلاحية|Admin privileges.
least privilege|أقل صلاحية ممكنة|Follow least privilege.
access control|التحكم بالوصول|Strong access control.
policy|سياسة|A password policy.
encryption|التشفير|End-to-end encryption.
decryption|فك التشفير|Decryption key.
encrypt|يشفّر|Encrypt the file.
decrypt|يفك التشفير|Decrypt the message.
key|مفتاح|A private key.
public key|مفتاح عام|Share your public key.
private key|مفتاح خاص|Never share your private key.
certificate|شهادة رقمية|An SSL certificate.
hash|تجزئة|Store the password hash.
salt|ملح (قيمة عشوائية)|Add a salt to the hash.
signature|توقيع|A digital signature.
trust|ثقة|Zero trust.
secure|آمن|A secure connection.
insecure|غير آمن|An insecure website.
sensitive|حساس|Sensitive data.
confidential|سري|Confidential information.
leak|تسريب|A password leak.
audit|تدقيق|A security audit.
compliance|الامتثال|Compliance with the law.
defense|دفاع|Defense in depth.
protect|يحمي|Protect your network.
prevent|يمنع|Prevent attacks.
detect|يكتشف|Detect intrusions.
respond|يستجيب|Respond to incidents.
recover|يتعافى|Recover from the attack.
mitigate|يخفف|Mitigate the risk.
patch|ترقيع|Install the security patch.
` });

window.WORDBANK_RAW.push({ cat: "tech", title: "أمن المعلومات: الهجمات والأدوات", text: `
malware|برمجيات خبيثة|Scan for malware.
virus|فيروس|A computer virus.
worm|دودة|A network worm.
trojan|حصان طروادة|A trojan hides inside apps.
ransomware|برمجية الفدية|Ransomware encrypts your files.
spyware|برمجية تجسس|Remove the spyware.
adware|برمجية إعلانية|Annoying adware.
botnet|شبكة أجهزة مخترقة|A large botnet.
backdoor|باب خلفي|The attacker left a backdoor.
rootkit|أداة إخفاء جذرية|Rootkits are hard to detect.
keylogger|مسجّل لوحة المفاتيح|A keylogger steals passwords.
phishing|التصيد الاحتيالي|A phishing email.
spoofing|انتحال|Email spoofing.
social engineering|الهندسة الاجتماعية|Beware of social engineering.
brute force|القوة الغاشمة (تخمين)|A brute-force attack.
DDoS|هجوم حجب الخدمة الموزع|The site was hit by a DDoS attack.
denial of service|حجب الخدمة|A denial of service attack.
injection|حقن|SQL injection.
cross-site scripting|البرمجة عبر المواقع (XSS)|Prevent cross-site scripting.
man-in-the-middle|هجوم الوسيط|A man-in-the-middle attack.
sniffing|التنصت على الحزم|Packet sniffing.
eavesdrop|يتنصت|Attackers can eavesdrop on Wi-Fi.
zero-day|ثغرة يوم الصفر|A zero-day vulnerability.
payload|حمولة خبيثة|The malicious payload.
malicious|خبيث|A malicious link.
suspicious|مشبوه|A suspicious email.
fake|مزيف|A fake website.
scam|احتيال|An online scam.
fraud|احتيال|Credit card fraud.
antivirus|مضاد الفيروسات|Update your antivirus.
firewall|جدار ناري|Enable the firewall.
IDS|نظام كشف التسلل|The IDS raised an alert.
intrusion|تسلل|Intrusion detection.
scanner|ماسح|A vulnerability scanner.
scan|يفحص|Scan the network.
penetration testing|اختبار الاختراق|Learn penetration testing.
red team|الفريق المهاجم|The red team found a weakness.
blue team|الفريق المدافع|The blue team responded.
forensics|التحليل الجنائي الرقمي|Digital forensics.
sandbox|بيئة معزولة|Run the file in a sandbox.
quarantine|عزل|The file was quarantined.
blacklist|قائمة الحظر|Add the IP to the blacklist.
whitelist|قائمة السماح|Whitelist trusted apps.
log|سجل|Review the security logs.
alert|تنبيه|A security alert.
backup|نسخة احتياطية|Keep offline backups.
two-factor|ثنائي العوامل|Turn on two-factor authentication.
password manager|مدير كلمات المرور|Use a password manager.
strong password|كلمة مرور قوية|Create a strong password.
update|تحديث|Keep your system updated.
` });

window.WORDBANK_RAW.push({ cat: "tech", title: "لغة الكورسات والمنصات التعليمية", text: `
enroll|يلتحق|Enroll in the course.
curriculum|منهج|The course curriculum.
syllabus|خطة المقرر|Read the syllabus.
module|وحدة دراسية|Module 1: Introduction.
section|قسم|Section 3.
lecture|محاضرة|Watch lecture 5.
quiz|اختبار قصير|Take the quiz.
exercise|تمرين|Practice exercise.
lab|مختبر عملي|A hands-on lab.
hands-on|عملي / تطبيقي|Hands-on experience.
project|مشروع|Final project.
assignment|واجب|Submit the assignment.
grade|درجة|Your grade is A.
score|نتيجة|Your score is 90%.
pass|ينجح|You passed!
fail|يرسب|You failed the quiz.
certificate|شهادة|Download your certificate.
completion|إتمام|Certificate of completion.
progress|تقدم|Course progress.
instructor|مدرب|Ask the instructor.
prerequisite|متطلب سابق|No prerequisites.
beginner-friendly|مناسب للمبتدئين|A beginner-friendly course.
overview|نظرة عامة|Course overview.
introduction|مقدمة|Watch the introduction.
outline|مخطط|Course outline.
objective|هدف|Learning objectives.
outcome|نتيجة / مخرج|Learning outcomes.
recap|ملخص سريع|A quick recap.
summary|ملخص|Chapter summary.
resources|موارد|Downloadable resources.
transcript|نص مكتوب للمحاضرة|Read the transcript.
subtitles|ترجمة نصية|Turn on subtitles.
caption|تعليق نصي|Closed captions.
playback speed|سرعة التشغيل|Change the playback speed.
bookmark|إشارة مرجعية|Bookmark this lesson.
forum|منتدى|Ask in the forum.
Q&A|أسئلة وأجوبة|Post in the Q&A.
peer review|تقييم الأقران|Peer review assignment.
deadline|موعد نهائي|The deadline is Sunday.
self-paced|بالسرعة الذاتية|A self-paced course.
lifetime access|وصول مدى الحياة|Get lifetime access.
refund|استرداد المال|Request a refund.
enrollment|التسجيل|Enrollment is open.
cohort|دفعة|The next cohort starts in May.
bootcamp|معسكر تدريبي|A coding bootcamp.
workshop|ورشة|A live workshop.
webinar|ندوة عبر الإنترنت|Join the webinar.
tutorial|درس تعليمي|A video tutorial.
walkthrough|شرح خطوة بخطوة|A full walkthrough.
cheat sheet|ورقة مختصرة|Download the cheat sheet.
` });

window.WORDBANK_RAW.push({ cat: "tech", title: "كلمات الكتب التقنية والأكاديمية", text: `
abstract|ملخص بحث / مجرد|Read the abstract first.
appendix|ملحق|See Appendix A.
figure|شكل / رسم|See Figure 2.
diagram|مخطط|Draw a diagram.
chart|رسم بياني|A bar chart.
table of contents|فهرس المحتويات|Check the table of contents.
index|فهرس|Look it up in the index.
glossary|مسرد مصطلحات|See the glossary.
footnote|حاشية|Read the footnote.
reference|مرجع|List of references.
citation|استشهاد|Add a citation.
definition|تعريف|The definition of a protocol.
term|مصطلح|A technical term.
terminology|المصطلحات|Learn the terminology.
concept|مفهوم|A key concept.
framework|إطار|A security framework.
model|نموذج|A data model.
architecture|البنية المعمارية|System architecture.
component|مكوّن|Each component has a role.
mechanism|آلية|A security mechanism.
implementation|تنفيذ|The implementation details.
specification|مواصفات|Read the specification.
requirement|متطلب|System requirements.
assumption|افتراض|Our assumptions.
constraint|قيد|Time constraints.
limitation|قيد / حدود|Known limitations.
scenario|سيناريو|A real-world scenario.
case study|دراسة حالة|Read the case study.
best practice|أفضل ممارسة|Follow best practices.
approach|منهج|A practical approach.
technique|تقنية / أسلوب|A useful technique.
tool|أداة|Security tools.
feature|ميزة|Key features.
functionality|وظائف|Basic functionality.
scalability|قابلية التوسع|Cloud scalability.
reliability|الموثوقية|Network reliability.
efficiency|الكفاءة|Energy efficiency.
accuracy|الدقة|Improve accuracy.
complexity|التعقيد|Reduce complexity.
overview|نظرة عامة|A brief overview.
in practice|عملياً|In practice, it works well.
in theory|نظرياً|In theory, it's simple.
respectively|على الترتيب|A and B are 1 and 2, respectively.
namely|أي / وهي|Two protocols, namely TCP and UDP.
i.e.|أي (يعني)|The client, i.e. the browser.
e.g.|مثلاً|Languages, e.g. Python.
etc.|إلخ|HTML, CSS, etc.
vs.|مقابل|TCP vs. UDP.
note that|لاحظ أن|Note that the order matters.
refer to|ارجع إلى|Refer to Chapter 3.
` });
