/* بنك المفردات — الكلمات التقنية (1): استخدام الحاسوب والبرمجة */
window.WORDBANK_RAW = window.WORDBANK_RAW || [];
window.WORDBANK_RAW.push({ cat: "tech", title: "واجهات البرامج والأجهزة", text: `
click|ينقر|Click the blue button.
double-click|ينقر نقراً مزدوجاً|Double-click the file to open it.
right-click|ينقر بالزر الأيمن|Right-click and choose Copy.
tap|ينقر (بالإصبع)|Tap the icon.
swipe|يسحب بالإصبع|Swipe left to delete.
scroll|يمرر الصفحة|Scroll down to see more.
drag|يسحب|Drag the file into the folder.
drop|يُفلت|Drop the image here.
select|يحدد / يختار|Select the text.
highlight|يميّز / يظلل|Highlight the important words.
cursor|المؤشر|Move the cursor to the end.
icon|أيقونة|Click the gear icon.
menu|قائمة|Open the menu.
toolbar|شريط الأدوات|The toolbar is at the top.
sidebar|الشريط الجانبي|Open the sidebar.
tab|تبويب|Open a new tab.
window|نافذة|Close the window.
dialog|نافذة حوار|A dialog will appear.
popup|نافذة منبثقة|Block popups.
dropdown|قائمة منسدلة|Choose from the dropdown.
checkbox|مربع اختيار|Tick the checkbox.
field|حقل|This field is required.
placeholder|نص توضيحي مؤقت|The placeholder says "Search".
label|تسمية|Each field has a label.
input|إدخال|Enter your input here.
output|إخراج / مخرجات|The output appears below.
screen|شاشة|Clean your screen.
display|يعرض / شاشة|The display is bright.
keyboard|لوحة المفاتيح|Use the keyboard shortcut.
shortcut|اختصار|Press Ctrl+C, the copy shortcut.
mouse|فأرة|Move the mouse.
storage|التخزين|You are running out of storage.
memory|الذاكرة|The app uses too much memory.
battery|بطارية|Low battery.
charger|شاحن|Plug in the charger.
device|جهاز|Connect your device.
hardware|العتاد الصلب|A hardware problem.
software|البرمجيات|Update the software.
operating system|نظام التشغيل|Choose your operating system.
desktop|سطح المكتب|Save it on the desktop.
laptop|حاسوب محمول|My laptop is fast.
smartphone|هاتف ذكي|Use the app on your smartphone.
tablet|جهاز لوحي|It works on tablets too.
printer|طابعة|The printer is offline.
monitor|شاشة / يراقب|I use two monitors.
drive|قرص / محرك أقراص|Save it to the D drive.
USB|منفذ / ذاكرة USB|Insert the USB stick.
cable|كابل|Connect the cable.
port|منفذ|Plug it into the USB port.
reboot|يعيد التشغيل|Reboot your computer.
` });

window.WORDBANK_RAW.push({ cat: "tech", title: "الملفات والإعدادات", text: `
file|ملف|Open the file.
folder|مجلد|Create a folder.
directory|دليل / مجلد|Change the directory.
path|مسار|Copy the file path.
extension|امتداد|The extension is .txt.
format|صيغة / يهيّئ|Save in PDF format.
document|مستند|A Word document.
attachment|مرفق|Open the attachment.
archive|أرشيف / ملف مضغوط|Extract the archive.
compress|يضغط|Compress the folder.
extract|يستخرج / يفك الضغط|Extract the zip file.
rename|يعيد التسمية|Rename the file.
duplicate|يكرر / نسخة مكررة|Duplicate the slide.
paste|يلصق|Paste the text here.
cut|يقص|Cut and paste.
undo|يتراجع|Undo the last action.
redo|يعيد|Redo the change.
preview|معاينة|Preview the page.
print|يطبع|Print the document.
share|يشارك|Share the link.
sync|يزامن|Sync your data.
settings|الإعدادات|Open settings.
preferences|التفضيلات|Change your preferences.
option|خيار|More options.
default|افتراضي|Restore default settings.
custom|مخصص|Use a custom theme.
customize|يخصّص|Customize your profile.
theme|سمة / مظهر|Dark theme.
mode|وضع|Airplane mode.
toggle|مفتاح تبديل / يبدّل|Toggle dark mode.
notification|إشعار|Turn on notifications.
alert|تنبيه|An alert appeared.
permission|إذن|Allow camera permission.
account|حساب|Create an account.
profile|ملف شخصي|Edit your profile.
username|اسم المستخدم|Choose a username.
password|كلمة المرور|Change your password.
login|تسجيل الدخول|Login failed.
logout|تسجيل الخروج|Click Logout.
register|يسجل|Register now.
subscribe|يشترك|Subscribe to the channel.
unsubscribe|يلغي الاشتراك|Unsubscribe from emails.
install|يثبّت|Install the app.
uninstall|يزيل التثبيت|Uninstall the old version.
update|تحديث|A new update is available.
upgrade|ترقية|Upgrade to Pro.
version|إصدار|Version 2.0.
download|تنزيل|Download speed.
upload|رفع|Upload failed.
offline|غير متصل|You are offline.
` });

window.WORDBANK_RAW.push({ cat: "tech", title: "أساسيات البرمجة", text: `
code|كود / شيفرة|Write clean code.
program|برنامج|Run the program.
programming|البرمجة|Programming is a useful skill.
developer|مطور|A web developer.
language|لغة برمجة|Python is a programming language.
syntax|بناء الجملة البرمجية|Check the syntax.
variable|متغير|Declare a variable.
constant|ثابت|PI is a constant.
value|قيمة|Assign a value.
assign|يُسند|Assign 5 to x.
declare|يعلن / يصرّح|Declare the variable first.
data type|نوع البيانات|What is the data type?
integer|عدد صحيح|Age is an integer.
float|عدد عشري|3.14 is a float.
string|سلسلة نصية|"Hello" is a string.
boolean|قيمة منطقية|True or false is a boolean.
array|مصفوفة|Store the names in an array.
list|قائمة|A list of numbers.
dictionary|قاموس (بنية بيانات)|A Python dictionary.
object|كائن|Create a new object.
class|صنف (كلاس)|Define a class.
instance|نسخة / كائن من صنف|An instance of the class.
property|خاصية|The length property.
attribute|سمة|Add an attribute.
method|دالة تابعة (ميثود)|Call the method.
function|دالة|Write a function.
parameter|معامل|The function takes two parameters.
argument|وسيط|Pass an argument.
return|يُرجع|The function returns a value.
call|يستدعي|Call the function.
loop|حلقة تكرار|Use a for loop.
iterate|يكرر / يمر على|Iterate over the list.
condition|شرط|Check the condition.
statement|تعليمة|An if statement.
expression|تعبير|A math expression.
operator|عامل (+ - *)|The plus operator.
comment|تعليق في الكود|Add a comment.
indentation|إزاحة / مسافة بادئة|Python uses indentation.
bracket|قوس|A missing bracket.
semicolon|فاصلة منقوطة|End the line with a semicolon.
keyword|كلمة محجوزة|"if" is a keyword.
scope|نطاق|Variable scope.
global|عام / شامل|A global variable.
local|محلي|A local variable.
module|وحدة|Import the module.
package|حزمة|Install the package.
library|مكتبة|Use a library.
framework|إطار عمل|React is a framework.
import|يستورد|Import the library.
export|يصدّر|Export the function.
` });

window.WORDBANK_RAW.push({ cat: "tech", title: "البرمجة: التنفيذ والأخطاء", text: `
compile|يترجم (الكود)|Compile the code.
compiler|المترجم|The compiler found an error.
interpreter|المفسّر|Python uses an interpreter.
execute|ينفذ|Execute the script.
runtime|وقت التشغيل|A runtime error.
build|يبني / نسخة مبنية|Build the project.
debug|يصحح الأخطاء|Debug the program.
debugger|مصحح الأخطاء|Use the debugger.
breakpoint|نقطة توقف|Set a breakpoint.
bug|خلل|Report a bug.
error|خطأ|Syntax error.
exception|استثناء|Handle the exception.
throw|يطلق (خطأ)|Throw an error.
catch|يلتقط|Catch the exception.
log|سجل / يسجّل|Check the log.
console|وحدة التحكم|Print to the console.
print|يطبع|Print the result.
input|مُدخل|Read user input.
test|اختبار|Write unit tests.
refactor|يعيد هيكلة الكود|Refactor the old code.
optimize|يحسّن الأداء|Optimize the query.
performance|الأداء|Improve performance.
efficient|فعّال|An efficient algorithm.
algorithm|خوارزمية|A sorting algorithm.
logic|منطق|The logic is wrong.
recursion|الاستدعاء الذاتي|Use recursion.
index|فهرس / موقع|Array index starts at 0.
element|عنصر|The first element.
key|مفتاح|A key-value pair.
null|فارغ (لا قيمة)|The value is null.
undefined|غير معرّف|The variable is undefined.
instance|نسخة|Create an instance.
inheritance|الوراثة|Class inheritance.
interface|واجهة|Implement the interface.
abstract|مجرد|An abstract class.
static|ساكن / ثابت|A static method.
public|عام|A public method.
private|خاص|A private field.
async|غير متزامن|An async function.
await|ينتظر|Await the result.
callback|دالة رد النداء|Pass a callback.
promise|وعد|The promise resolved.
thread|خيط تنفيذ|Run it in a new thread.
process|عملية|Kill the process.
memory leak|تسرب الذاكرة|There is a memory leak.
crash|ينهار / انهيار|The app crashed.
freeze|يتجمد|The screen froze.
hang|يتوقف عن الاستجابة|The program hangs.
stable|مستقر|A stable version.
legacy|قديم موروث|Legacy code.
` });

window.WORDBANK_RAW.push({ cat: "tech", title: "أدوات المطور والعمل الجماعي", text: `
editor|محرر|A code editor.
IDE|بيئة تطوير متكاملة|Install an IDE.
terminal|الطرفية|Open the terminal.
command|أمر|Type the command.
command line|سطر الأوامر|Use the command line.
script|سكربت|Run the script.
shell|الصدفة (واجهة الأوامر)|A bash shell.
environment|بيئة|The development environment.
environment variable|متغير بيئة|Set an environment variable.
dependency|اعتمادية|Install the dependencies.
package manager|مدير الحزم|npm is a package manager.
version control|التحكم بالإصدارات|Git is a version control system.
repository|مستودع|Clone the repository.
commit|يحفظ التغييرات|Commit your changes.
push|يدفع (للمستودع)|Push to GitHub.
pull|يسحب|Pull the latest code.
merge|يدمج|Merge the branch.
branch|فرع|Create a new branch.
conflict|تعارض|Resolve the merge conflict.
fork|نسخ المستودع لحسابك|Fork the project.
clone|ينسخ المستودع|Clone the repo.
pull request|طلب دمج|Open a pull request.
review|مراجعة|Code review.
issue|بلاغ / مشكلة|Open an issue.
release|إصدار|A new release.
changelog|سجل التغييرات|Read the changelog.
documentation|توثيق|Read the documentation.
tutorial|درس تعليمي|A beginner tutorial.
guide|دليل|A quick guide.
example|مثال|Code example.
snippet|مقتطف كود|A useful snippet.
template|قالب|Use a template.
boilerplate|كود جاهز مبدئي|Start with a boilerplate.
open source|مفتوح المصدر|An open source project.
license|رخصة|MIT license.
contributor|مساهم|Thanks to all contributors.
maintainer|المشرف على المشروع|Contact the maintainer.
deploy|ينشر (للخادم)|Deploy the website.
deployment|النشر|Automatic deployment.
production|بيئة الإنتاج|Don't test in production.
staging|بيئة الاختبار قبل النشر|Deploy to staging first.
pipeline|خط معالجة / تسلسل آلي|The CI pipeline failed.
container|حاوية|Run it in a Docker container.
virtual machine|آلة افتراضية|Create a virtual machine.
cloud|السحابة|Host it in the cloud.
host|يستضيف / مضيف|Host your website.
server|خادم|The server is down.
client|عميل|The client sends a request.
backend|الواجهة الخلفية|A backend developer.
frontend|الواجهة الأمامية|A frontend framework.
` });

window.WORDBANK_RAW.push({ cat: "tech", title: "الويب وقواعد البيانات", text: `
website|موقع إلكتروني|Build a website.
web page|صفحة ويب|Load the web page.
browser|متصفح|Open your browser.
URL|عنوان الصفحة|Copy the URL.
domain|نطاق (اسم موقع)|Buy a domain name.
link|رابط|A broken link.
HTML|لغة ترميز الصفحات|HTML defines the structure.
CSS|لغة تنسيق الصفحات|CSS adds style.
JavaScript|جافاسكربت|JavaScript adds interaction.
responsive|متجاوب مع الشاشات|A responsive design.
layout|تخطيط|Change the layout.
component|مكوّن|A reusable component.
element|عنصر|An HTML element.
tag|وسم|The <p> tag.
style|نمط|Inline style.
font|خط|Change the font.
image|صورة|Optimize the images.
form|نموذج|Submit the form.
submit|يرسل|Click Submit.
request|طلب|An HTTP request.
response|استجابة|The server response.
API|واجهة برمجة التطبيقات|Call the API.
endpoint|نقطة نهاية API|The endpoint returns JSON.
JSON|صيغة بيانات JSON|Parse the JSON.
query|استعلام|Write a SQL query.
database|قاعدة بيانات|Connect to the database.
table|جدول|Create a table.
record|سجل|Insert a new record.
column|عمود|Add a column.
row|صف|Delete the row.
primary key|مفتاح أساسي|Each table has a primary key.
insert|يُدرج|Insert data.
select|يختار (SELECT)|Select all users.
delete|يحذف|Delete old records.
update|يحدّث|Update the record.
schema|مخطط|The database schema.
migration|ترحيل|Run the migration.
backup|نسخة احتياطية|Daily backup.
restore|يستعيد|Restore from backup.
cache|ذاكرة مؤقتة|Clear the cache.
cookie|ملف تعريف ارتباط|Accept cookies.
session|جلسة|The session expired.
token|رمز|An access token.
authentication|المصادقة|User authentication.
load|يحمّل|The page loads slowly.
render|يعرض / يرسم|Render the page.
fetch|يجلب|Fetch the data.
parse|يحلل|Parse the response.
validate|يتحقق من صحة|Validate the input.
redirect|يعيد التوجيه|Redirect to login.
` });

window.WORDBANK_RAW.push({ cat: "tech", title: "رسائل الأخطاء والتحذيرات", text: `
failed|فشل|The build failed.
invalid|غير صالح|Invalid email address.
missing|مفقود|A missing file.
not found|غير موجود|404 Not Found.
denied|مرفوض|Access denied.
forbidden|ممنوع|403 Forbidden.
unauthorized|غير مصرح|401 Unauthorized.
timeout|انتهاء المهلة|Request timeout.
unavailable|غير متاح|Service unavailable.
unexpected|غير متوقع|Unexpected token.
unknown|غير معروف|Unknown error.
deprecated|مُهمل / غير موصى به|This method is deprecated.
outdated|قديم|Your browser is outdated.
corrupted|تالف|The file is corrupted.
overflow|فيض / تجاوز|Stack overflow.
limit|حد|Rate limit exceeded.
exceeded|تم تجاوزه|Quota exceeded.
expired|منتهي الصلاحية|Your session expired.
required|مطلوب|This field is required.
optional|اختياري|Phone number is optional.
mismatch|عدم تطابق|Password mismatch.
duplicate|مكرر|Duplicate entry.
conflict|تعارض|Version conflict.
incompatible|غير متوافق|Incompatible version.
unsupported|غير مدعوم|Unsupported file type.
retry|يعيد المحاولة|Click Retry.
abort|يلغي / يُجهض|Operation aborted.
cancel|يلغي|Cancel the download.
warning|تحذير|Warning: low disk space.
fatal|قاتل / فادح|Fatal error.
critical|حرج|Critical update.
debug|تصحيح|Debug mode.
verbose|مفصّل|Verbose output.
status|حالة|Check the status.
pending|قيد الانتظار|Payment pending.
in progress|قيد التنفيذ|Upload in progress.
completed|مكتمل|Download completed.
successful|ناجح|Payment successful.
loading|جارٍ التحميل|Loading, please wait.
processing|جارٍ المعالجة|Processing your request.
please wait|يرجى الانتظار|Please wait.
try again|حاول مرة أخرى|Something went wrong. Try again.
something went wrong|حدث خطأ ما|Oops! Something went wrong.
check your connection|تحقق من اتصالك|No internet. Check your connection.
are you sure|هل أنت متأكد|Are you sure you want to delete?
cannot be undone|لا يمكن التراجع عنه|This action cannot be undone.
out of memory|نفدت الذاكرة|Error: out of memory.
permission|صلاحية|Permission denied.
crash report|تقرير الانهيار|Send a crash report.
stack trace|تتبع المكدس|Read the stack trace.
` });
