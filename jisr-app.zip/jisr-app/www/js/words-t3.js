/* بنك المفردات — الكلمات التقنية (3): لينكس والسحابة والبيانات والذكاء الاصطناعي */
window.WORDBANK_RAW = window.WORDBANK_RAW || [];
window.WORDBANK_RAW.push({ cat: "tech", title: "لينكس وأنظمة التشغيل", text: `
kernel|النواة|The Linux kernel.
distribution|توزيعة|Ubuntu is a Linux distribution.
root|المستخدم الجذر / الجذر|Log in as root.
sudo|تنفيذ بصلاحيات المدير|Run the command with sudo.
superuser|المستخدم الخارق|Superuser privileges.
file system|نظام الملفات|The Linux file system.
mount|يركّب (قرصاً)|Mount the USB drive.
partition|قسم من القرص|Create a new partition.
boot|الإقلاع / يقلع|The system boots in ten seconds.
bootloader|محمّل الإقلاع|Update the bootloader.
daemon|خدمة خلفية|The SSH daemon.
service|خدمة|Restart the service.
background|الخلفية|Run it in the background.
foreground|الواجهة|Bring the job to the foreground.
permissions|الأذونات|Change file permissions.
owner|المالك|Change the file owner.
executable|قابل للتنفيذ|Make the script executable.
binary|ملف تنفيذي / ثنائي|Download the binary.
source code|الكود المصدري|Read the source code.
package|حزمة|Install the package with apt.
repository|مستودع الحزم|Add a new repository.
dependency|اعتمادية|Missing dependency.
cron job|مهمة مجدولة|Set up a cron job.
pipe|أنبوب (تمرير المخرجات)|Pipe the output to grep.
redirect|يعيد التوجيه|Redirect the output to a file.
argument|وسيط|Pass the file name as an argument.
flag|خيار سطر الأوامر|Use the -r flag.
manual|دليل الاستخدام|Read the manual page.
home directory|مجلد المستخدم الرئيسي|Go to your home directory.
hidden file|ملف مخفي|Hidden files start with a dot.
symbolic link|رابط رمزي|Create a symbolic link.
process ID|معرّف العملية|Find the process ID.
kill|ينهي (عملية)|Kill the process.
memory usage|استهلاك الذاكرة|Check memory usage.
CPU|المعالج|High CPU usage.
disk space|مساحة القرص|Free up disk space.
swap|ذاكرة التبديل|Increase swap space.
uptime|مدة التشغيل المتواصل|Check the server uptime.
shutdown|إيقاف التشغيل|Schedule a shutdown.
restart|إعادة التشغيل|Restart now.
environment|بيئة التشغيل|Set up the environment.
virtualization|المحاكاة الافتراضية|Enable virtualization in BIOS.
driver|برنامج تعريف|Install the latest driver.
firmware|البرنامج الثابت|Update the firmware.
BIOS|نظام الإدخال والإخراج الأساسي|Enter the BIOS settings.
log file|ملف سجل|Check the log file.
config file|ملف إعدادات|Edit the config file.
text editor|محرر نصوص|Open it in a text editor.
open-source|مفتوح المصدر|Linux is open-source.
command prompt|موجّه الأوامر|Open the command prompt.
` });

window.WORDBANK_RAW.push({ cat: "tech", title: "السحابة والبنية التحتية", text: `
cloud computing|الحوسبة السحابية|Learn cloud computing.
provider|مزوّد|A cloud provider.
instance|نسخة خادم|Launch a new instance.
region|منطقة|Choose a region close to users.
zone|نطاق / منطقة توافر|Availability zone.
scalable|قابل للتوسع|A scalable system.
scale|يوسّع / يتوسع|Scale up the server.
load|الحمل|Heavy load.
capacity|السعة|Increase capacity.
resource|مورد|Cloud resources.
storage|التخزين|Cloud storage.
bucket|حاوية تخزين|Upload files to the bucket.
serverless|بدون خادم|A serverless function.
microservice|خدمة مصغّرة|Split the app into microservices.
monolith|تطبيق موحّد ضخم|Break the monolith.
orchestration|التنسيق الآلي|Container orchestration.
cluster|مجموعة خوادم|A Kubernetes cluster.
image|صورة (حاوية)|Build a Docker image.
registry|سجل|Push the image to the registry.
CI/CD|التكامل والنشر المستمر|Set up CI/CD.
automation|الأتمتة|Automation saves time.
automate|يؤتمت|Automate the tests.
infrastructure as code|البنية التحتية ككود|Use infrastructure as code.
provision|يجهّز (موارد)|Provision a new server.
monitoring|المراقبة|Server monitoring.
metrics|المقاييس|Collect metrics.
dashboard|لوحة متابعة|Open the dashboard.
alerting|التنبيهات|Set up alerting.
downtime|فترة التوقف|Planned downtime.
outage|انقطاع|A cloud outage.
failover|التحويل التلقائي عند العطل|Automatic failover.
redundancy|التكرار الاحتياطي|Add redundancy.
high availability|التوافر العالي|A high availability setup.
disaster recovery|التعافي من الكوارث|A disaster recovery plan.
latency|زمن الاستجابة|Reduce latency.
CDN|شبكة توصيل المحتوى|Use a CDN for images.
DNS record|سجل DNS|Add a DNS record.
SSL|طبقة المقابس الآمنة|Install an SSL certificate.
certificate|شهادة|The certificate expired.
billing|الفوترة|Check your billing.
pricing|التسعير|Pay-as-you-go pricing.
quota|حصة|You reached your quota.
free tier|الطبقة المجانية|Use the free tier.
subscription|اشتراك|Monthly subscription.
SaaS|برمجيات كخدمة|A SaaS product.
API key|مفتاح API|Keep your API key secret.
secret|سر / قيمة سرية|Store secrets safely.
environment variables|متغيرات البيئة|Load environment variables.
logs|السجلات|View the logs.
rollback|التراجع لإصدار سابق|Roll back the deployment.
` });

window.WORDBANK_RAW.push({ cat: "tech", title: "البيانات والذكاء الاصطناعي", text: `
artificial intelligence|الذكاء الاصطناعي|Artificial intelligence is everywhere.
machine learning|تعلم الآلة|A machine learning course.
model|نموذج|Train the model.
train|يدرّب|Train the model on data.
training data|بيانات التدريب|Clean the training data.
dataset|مجموعة بيانات|A public dataset.
feature|خاصية (في البيانات)|Select the features.
label|تصنيف|Each image has a label.
prediction|تنبؤ|The model's prediction.
accuracy|الدقة|The accuracy is 95%.
neural network|شبكة عصبية|A deep neural network.
deep learning|التعلم العميق|Deep learning needs GPUs.
GPU|معالج رسوميات|Training on a GPU.
prompt|طلب نصي للنموذج|Write a clear prompt.
chatbot|روبوت محادثة|Build a chatbot.
large language model|نموذج لغوي كبير|Large language models generate text.
generate|يولّد|Generate an image.
output|المخرجات|Check the output.
bias|تحيّز|Data bias.
overfitting|فرط التخصيص|Avoid overfitting.
evaluate|يقيّم|Evaluate the model.
statistics|الإحصاء|Basic statistics.
probability|الاحتمالية|Probability theory.
mean|المتوسط|Calculate the mean.
median|الوسيط|Find the median.
variance|التباين|High variance.
correlation|ارتباط|A strong correlation.
trend|اتجاه|Sales trend.
visualization|تصوير البيانات|Data visualization.
spreadsheet|جدول بيانات|Open the spreadsheet.
cell|خلية|Edit the cell.
formula|صيغة|Enter a formula.
filter|يرشّح / مرشّح|Filter the results.
sort|يرتب|Sort by date.
aggregate|يجمّع|Aggregate the data.
clean|ينظف|Clean the data.
raw data|بيانات خام|Raw data.
pipeline|خط معالجة|A data pipeline.
big data|البيانات الضخمة|Big data tools.
analytics|التحليلات|Web analytics.
insight|استنتاج / رؤية|Valuable insights.
algorithm|خوارزمية|A search algorithm.
automation|الأتمتة|Task automation.
robot|روبوت|Industrial robots.
sensor|مستشعر|A temperature sensor.
IoT|إنترنت الأشياء|IoT devices.
real-time|في الوقت الفعلي|Real-time data.
accurate|دقيق|Accurate results.
reliable|موثوق|A reliable source.
ethical|أخلاقي|Ethical AI.
` });

window.WORDBANK_RAW.push({ cat: "tech", title: "تطوير التطبيقات والجوال", text: `
app|تطبيق|Download the app.
mobile|محمول / جوال|Mobile development.
native|أصلي (للمنصة)|A native app.
cross-platform|متعدد المنصات|Flutter is cross-platform.
platform|منصة|Android and iOS platforms.
emulator|محاكي|Run the app on an emulator.
simulator|محاكي|The iOS simulator.
SDK|حزمة تطوير البرمجيات|Install the Android SDK.
APK|ملف تطبيق أندرويد|Build the APK.
screen|شاشة|The login screen.
widget|عنصر واجهة|A Flutter widget.
state|الحالة|Manage the app state.
navigation|التنقل|Bottom navigation.
route|مسار|Define the routes.
gesture|إيماءة|Swipe gesture.
animation|حركة|A smooth animation.
splash screen|شاشة البداية|Show a splash screen.
push notification|إشعار فوري|Send a push notification.
in-app purchase|شراء داخل التطبيق|Enable in-app purchases.
permission|إذن|Request camera permission.
orientation|الاتجاه|Portrait orientation.
resolution|الدقة|Screen resolution.
pixel|بكسل|100 pixels wide.
asset|ملف مورد|Add the image to assets.
manifest|ملف البيان|Edit the Android manifest.
signing|التوقيع|App signing.
release build|نسخة الإصدار|Create a release build.
debug build|نسخة التصحيح|Install the debug build.
store listing|صفحة المتجر|Update the store listing.
review process|عملية المراجعة|The app is in the review process.
rating|تقييم|Five-star rating.
crash|انهيار|Fix the crash.
user interface|واجهة المستخدم|A clean user interface.
user experience|تجربة المستخدم|Improve the user experience.
accessibility|إمكانية الوصول|Accessibility matters.
localization|توطين (ترجمة التطبيق)|Arabic localization.
right-to-left|من اليمين لليسار|Support right-to-left text.
dark mode|الوضع الداكن|Add dark mode.
onboarding|التعريف الأولي بالتطبيق|A short onboarding flow.
feedback|ملاحظات|Send feedback.
beta|نسخة تجريبية|Join the beta.
prototype|نموذج أولي|Build a prototype.
mockup|تصميم مبدئي|Show me the mockup.
wireframe|مخطط هيكلي|Draw a wireframe.
iteration|تكرار / دورة تطوير|The next iteration.
requirement|متطلب|Gather requirements.
user story|قصة مستخدم|Write a user story.
sprint|دورة عمل قصيرة|A two-week sprint.
backlog|قائمة المهام المؤجلة|Add it to the backlog.
milestone|مرحلة رئيسية|We reached a milestone.
` });
