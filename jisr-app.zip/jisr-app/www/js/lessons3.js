/* المرحلة 7: آفاق تقنية — دروس جديدة تربط بنك الكلمات التقنية بنصوص حقيقية */
window.STAGES.push({ id: "s7", n: 7, title: "آفاق تقنية", sub: "لينكس، السحابة، الذكاء الاصطناعي، والكتب التقنية" });
window.LESSONS.push(
{
  id: "x1", stage: "s7", title: "قراءة صفحة دليل في لينكس (man page)", minutes: 9,
  explain: `
  <p>في لينكس كل أمر له صفحة دليل تفتحها بـ <span class="en">man</span>. شكلها مخيف أول مرة، لكنها مقسمة دائماً لنفس الأقسام:</p>
  <table class="mini" dir="ltr"><tr><th>القسم</th><th dir="rtl">ماذا تجد فيه</th></tr>
  <tr><td>NAME</td><td dir="rtl">اسم الأمر ووظيفته في سطر</td></tr>
  <tr><td>SYNOPSIS</td><td dir="rtl">طريقة الكتابة: ما بين [ ] اختياري</td></tr>
  <tr><td>DESCRIPTION</td><td dir="rtl">شرح مفصل</td></tr>
  <tr><td>OPTIONS</td><td dir="rtl">الخيارات مثل -r و --help</td></tr>
  <tr><td>EXAMPLES</td><td dir="rtl">أمثلة جاهزة، ابدأ منها!</td></tr>
  <tr><td>EXIT STATUS</td><td dir="rtl">الرقم الذي يُرجعه الأمر: 0 يعني نجاح</td></tr>
  <tr><td>SEE ALSO</td><td dir="rtl">أوامر مشابهة</td></tr></table>
  <p><b>نصيحة:</b> اقرأ NAME ثم اقفز إلى EXAMPLES مباشرة، وارجع إلى OPTIONS عند الحاجة فقط.</p>`,
  examples: [
    { en: "cp - copy files and directories", ar: "cp - نسخ الملفات والمجلدات", note: "قسم NAME: سطر واحد يكفيك لتعرف وظيفة الأمر" },
    { en: "-r, --recursive: copy directories recursively", ar: "-r: انسخ المجلدات بكل ما بداخلها", note: "recursively = بشكل متداخل: المجلد وما بداخله" },
    { en: "If the destination file already exists, it is overwritten without warning.", ar: "إذا كان الملف الهدف موجوداً بالفعل، يُكتب فوقه بدون تحذير.", note: "overwritten = يُستبدل بالكتابة فوقه" }
  ],
  reading: {
    title: "rm(1) — Linux manual page",
    paras: [
      { en: "NAME: rm - remove files or directories. SYNOPSIS: rm [OPTION]... [FILE]...", ar: "الاسم: rm - حذف الملفات أو المجلدات. الصيغة: rm [خيار]... [ملف]..." },
      { en: "By default, rm does not remove directories. Use the -r option to remove each listed directory, too, along with all of its contents.", ar: "افتراضياً لا يحذف rm المجلدات. استخدم الخيار -r لحذف كل مجلد مذكور أيضاً مع كل محتوياته." },
      { en: "Note that if you use rm to remove a file, it might be possible to recover some of its contents. However, there is no undo command, so be careful when running rm as root.", ar: "لاحظ أنه إذا استخدمت rm لحذف ملف، قد يكون ممكناً استعادة بعض محتوياته. لكن لا يوجد أمر تراجع، لذلك كن حذراً عند تشغيل rm بصلاحيات root." }
    ]
  },
  vocab: [["synopsis","الصيغة المختصرة"],["recursive","متداخل / تكراري"],["recursively","بشكل متداخل"],["overwrite","يكتب فوق"],["destination","الهدف / الوجهة"],["exit status","رمز الخروج"],["along with","مع / إلى جانب"],["contents","المحتويات"],["listed","مذكور"],["careful","حذر"],["see also","انظر أيضاً"],["option","خيار"]],
  quiz: [
    { q: "كيف تحذف مجلداً بكل محتوياته بأمر rm؟", o: ["rm وحده","rm -r","rm --help","لا يمكن"], a: 1, why: "Use the -r option to remove each listed directory, too, along with all of its contents." },
    { q: "ما القسم الذي تقفز إليه بعد NAME لتتعلم بسرعة؟", o: ["SEE ALSO","EXIT STATUS","EXAMPLES","SYNOPSIS"], a: 2, why: "الأمثلة الجاهزة أسرع طريق للفهم." },
    { q: "لماذا يحذّر الدليل من rm بصلاحيات root؟", o: ["لأنه بطيء","لأنه لا يوجد أمر تراجع","لأنه لا يعمل","لأنه يحتاج إنترنت"], a: 1, why: "there is no undo command, so be careful." }
  ]
},
{
  id: "x2", stage: "s7", title: "توثيق السحابة وDevOps", minutes: 9,
  explain: `
  <p>توثيق الخدمات السحابية مليء بكلمات تصف <b>التكلفة والحدود والتوافر</b>. هذه أهم الصيغ:</p>
  <table class="mini" dir="ltr"><tr><th>العبارة</th><th dir="rtl">المعنى</th></tr>
  <tr><td>Pay as you go</td><td dir="rtl">تدفع حسب استخدامك</td></tr>
  <tr><td>Free tier includes...</td><td dir="rtl">الطبقة المجانية تشمل...</td></tr>
  <tr><td>Up to 5 GB / per month</td><td dir="rtl">حتى 5 جيجا / شهرياً</td></tr>
  <tr><td>Quota / Rate limit</td><td dir="rtl">حصة / حد عدد الطلبات</td></tr>
  <tr><td>Scales automatically</td><td dir="rtl">يتوسع تلقائياً</td></tr>
  <tr><td>Region / Availability zone</td><td dir="rtl">منطقة / نطاق توافر</td></tr>
  <tr><td>Charges may apply</td><td dir="rtl">قد تُفرض رسوم</td></tr></table>
  <p><b>انتبه دائماً لـ:</b> <span class="en">beyond</span> (بعد تجاوز) و <span class="en">additional charges</span> (رسوم إضافية).</p>`,
  examples: [
    { en: "The free tier includes 750 hours per month for 12 months.", ar: "تشمل الطبقة المجانية 750 ساعة شهرياً لمدة 12 شهراً.", note: "اقرأ المدة جيداً: for 12 months" },
    { en: "Usage beyond the free limit is billed per second.", ar: "الاستخدام بعد تجاوز الحد المجاني يُحاسب بالثانية.", note: "beyond = بعد تجاوز" },
    { en: "Deploy your container and it scales automatically with traffic.", ar: "انشر حاويتك وستتوسع تلقائياً حسب حركة البيانات.", note: "" }
  ],
  reading: {
    title: "Quickstart: Deploy a Container",
    paras: [
      { en: "In this quickstart, you will build a container image, push it to the registry and deploy it as a service. The whole process takes about ten minutes.", ar: "في هذا البدء السريع ستبني صورة حاوية، وترفعها إلى السجل، وتنشرها كخدمة. تستغرق العملية كلها نحو عشر دقائق." },
      { en: "Before you begin, make sure that billing is enabled for your project. New customers get free credits, but some resources used in this guide may incur charges.", ar: "قبل أن تبدأ، تأكد أن الفوترة مفعّلة لمشروعك. العملاء الجدد يحصلون على رصيد مجاني، لكن بعض الموارد المستخدمة في هذا الدليل قد تترتب عليها رسوم." },
      { en: "To avoid unexpected costs, delete the service when you finish. If a deployment fails, you can roll back to the previous revision from the console.", ar: "لتجنب تكاليف غير متوقعة، احذف الخدمة عند الانتهاء. إذا فشل النشر يمكنك الرجوع إلى المراجعة السابقة من لوحة التحكم." }
    ]
  },
  vocab: [["quickstart","البدء السريع"],["pay as you go","الدفع حسب الاستخدام"],["beyond","بعد تجاوز"],["billed","يُحاسب عليه"],["incur charges","تترتب عليه رسوم"],["credits","رصيد"],["unexpected costs","تكاليف غير متوقعة"],["revision","مراجعة / نسخة"],["console","لوحة التحكم"],["charges may apply","قد تُفرض رسوم"],["rate limit","حد معدل الطلبات"],["availability zone","نطاق التوافر"]],
  quiz: [
    { q: "ما الذي يجب تفعيله قبل البدء؟", o: ["الوضع الداكن","الفوترة billing","الإشعارات","الحاوية"], a: 1, why: "make sure that billing is enabled for your project." },
    { q: "كيف تتجنب تكاليف غير متوقعة؟", o: ["ترفع صورة أكبر","تحذف الخدمة عند الانتهاء","تغيّر المنطقة","تشتري رصيداً"], a: 1, why: "To avoid unexpected costs, delete the service when you finish." },
    { q: "may incur charges تعني:", o: ["مجاني دائماً","قد تترتب عليه رسوم","سيُرد المال","ممنوع"], a: 1, why: "incur = يتحمل / تترتب عليه." }
  ]
},
{
  id: "x3", stage: "s7", title: "مقالات الذكاء الاصطناعي والبيانات", minutes: 9,
  explain: `
  <p>مقالات الذكاء الاصطناعي تكثر فيها <b>لغة الحذر والاحتمال</b>، لأن النتائج ليست مضمونة دائماً. تعلّم التمييز بين اليقين والاحتمال:</p>
  <table class="mini" dir="ltr"><tr><th>العبارة</th><th dir="rtl">درجة اليقين</th></tr>
  <tr><td>shows / proves</td><td dir="rtl">قوية: يُظهر / يثبت</td></tr>
  <tr><td>suggests / indicates</td><td dir="rtl">متوسطة: يشير إلى</td></tr>
  <tr><td>may / might / could</td><td dir="rtl">ضعيفة: قد</td></tr>
  <tr><td>tends to</td><td dir="rtl">يميل إلى (غالباً)</td></tr>
  <tr><td>to some extent</td><td dir="rtl">إلى حد ما</td></tr>
  <tr><td>it is unclear whether</td><td dir="rtl">ليس واضحاً ما إذا كان</td></tr></table>
  <p>هذه الكلمات مهمة جداً: الفرق بين <span class="en">proves</span> و <span class="en">suggests</span> هو الفرق بين حقيقة وفرضية.</p>`,
  examples: [
    { en: "The results suggest that larger models tend to make fewer mistakes.", ar: "تشير النتائج إلى أن النماذج الأكبر تميل إلى ارتكاب أخطاء أقل.", note: "suggest + tend to = احتمال، ليس يقيناً" },
    { en: "It is unclear whether the method works on other languages.", ar: "ليس واضحاً ما إذا كانت الطريقة تعمل على لغات أخرى.", note: "" },
    { en: "Biased training data may lead to unfair predictions.", ar: "بيانات التدريب المتحيزة قد تؤدي إلى تنبؤات غير عادلة.", note: "may = قد" }
  ],
  reading: {
    title: "Can Machines Read Like Humans?",
    paras: [
      { en: "Large language models are trained on huge amounts of text. As a result, they can answer questions, summarize articles and translate between languages.", ar: "النماذج اللغوية الكبيرة تُدرَّب على كميات ضخمة من النصوص. ونتيجة لذلك، تستطيع الإجابة عن الأسئلة وتلخيص المقالات والترجمة بين اللغات." },
      { en: "However, several studies suggest that these models sometimes produce confident answers that are simply wrong. Researchers call this problem hallucination.", ar: "لكن عدة دراسات تشير إلى أن هذه النماذج تنتج أحياناً إجابات واثقة تكون خاطئة ببساطة. يسمي الباحثون هذه المشكلة الهلوسة." },
      { en: "For this reason, experts recommend checking important facts against reliable sources. To some extent, a good reader still needs human judgment.", ar: "لهذا السبب ينصح الخبراء بالتحقق من الحقائق المهمة بمقارنتها بمصادر موثوقة. فإلى حد ما، لا يزال القارئ الجيد يحتاج إلى حكم بشري." }
    ]
  },
  vocab: [["suggest","يشير إلى"],["indicate","يدل على"],["tend to","يميل إلى"],["to some extent","إلى حد ما"],["unclear","غير واضح"],["hallucination","هلوسة (إجابة مختلقة)"],["researcher","باحث"],["judgment","حكم / تقدير"],["confident","واثق"],["summarize","يلخص"],["huge amounts","كميات ضخمة"],["for this reason","لهذا السبب"]],
  quiz: [
    { q: "ما المقصود بـ hallucination في النص؟", o: ["سرعة النموذج","إجابات واثقة لكنها خاطئة","ترجمة صحيحة","نوع من البيانات"], a: 1, why: "confident answers that are simply wrong. Researchers call this problem hallucination." },
    { q: "several studies suggest... هل هذه حقيقة مثبتة؟", o: ["نعم مثبتة تماماً","هي إشارة قوية لكنها ليست إثباتاً","كذب","لا علاقة لها"], a: 1, why: "suggest = تشير، أضعف من prove." },
    { q: "ماذا ينصح الخبراء؟", o: ["الثقة الكاملة بالنموذج","التحقق من الحقائق المهمة بمصادر موثوقة","عدم القراءة","حذف النموذج"], a: 1, why: "experts recommend checking important facts against reliable sources." }
  ]
},
{
  id: "x4", stage: "s7", title: "قراءة كتاب تقني كامل", minutes: 10,
  explain: `
  <p>الكتاب التقني ليس رواية. لا تقرأه من الغلاف للغلاف بنفس السرعة. هذه خطة قراءة عملية:</p>
  <p><b>1. Preface / Introduction:</b> اقرأ فيها فقرة <span class="en">Who this book is for</span> و <span class="en">How this book is organized</span>.</p>
  <p><b>2. Table of Contents:</b> اختر الفصول التي تحتاجها الآن. الفصول التقنية غالباً مستقلة.</p>
  <p><b>3. داخل الفصل:</b> اقرأ العناوين، ثم الأشكال <span class="en">Figure</span> والجداول، ثم الملخص <span class="en">Summary</span> في آخر الفصل، ثم ارجع للتفاصيل.</p>
  <p><b>4. الصناديق الجانبية:</b> <span class="en">Note</span> (ملاحظة)، <span class="en">Tip</span> (نصيحة)، <span class="en">Warning</span> (تحذير). لا تتجاوز Warning أبداً!</p>
  <p><b>5. Exercises:</b> حل تمريناً واحداً على الأقل من كل فصل.</p>`,
  examples: [
    { en: "This book assumes basic familiarity with the command line.", ar: "يفترض هذا الكتاب إلماماً أساسياً بسطر الأوامر.", note: "assumes = يفترض أنك تعرف" },
    { en: "Readers who are new to networking may want to start with Chapter 2.", ar: "القراء الجدد على الشبكات قد يرغبون في البدء من الفصل الثاني.", note: "may want to = قد ترغب" },
    { en: "The remaining chapters can be read in any order.", ar: "يمكن قراءة الفصول المتبقية بأي ترتيب.", note: "" }
  ],
  reading: {
    title: "Preface: How This Book Is Organized",
    paras: [
      { en: "This book is divided into three parts. Part I covers the fundamentals, Part II focuses on practical projects, and Part III discusses advanced topics.", ar: "ينقسم هذا الكتاب إلى ثلاثة أجزاء. الجزء الأول يغطي الأساسيات، والثاني يركز على المشاريع العملية، والثالث يناقش موضوعات متقدمة." },
      { en: "Each chapter ends with a summary and a set of exercises. Solutions to selected exercises are provided in Appendix B.", ar: "ينتهي كل فصل بملخص ومجموعة تمارين. حلول تمارين مختارة موجودة في الملحق ب." },
      { en: "If you are already comfortable with the basics, feel free to skip Part I. However, we strongly recommend reading Chapter 4, because the rest of the book builds on it.", ar: "إذا كنت مرتاحاً بالفعل مع الأساسيات، لا تتردد في تجاوز الجزء الأول. لكننا نوصي بشدة بقراءة الفصل الرابع، لأن بقية الكتاب تُبنى عليه." }
    ]
  },
  vocab: [["preface","تمهيد / مقدمة الكتاب"],["fundamentals","الأساسيات"],["familiarity","إلمام / معرفة"],["remaining","المتبقي"],["selected","مختار"],["solution","حل"],["appendix","ملحق"],["skip","يتجاوز"],["strongly recommend","يوصي بشدة"],["builds on","يُبنى على"],["organized","منظم"],["part","جزء"]],
  quiz: [
    { q: "أين تجد حلول بعض التمارين؟", o: ["في الفصل 4","في الملحق B","في المقدمة","غير موجودة"], a: 1, why: "Solutions to selected exercises are provided in Appendix B." },
    { q: "لماذا يجب قراءة الفصل الرابع حتى لو تجاوزت الجزء الأول؟", o: ["لأنه قصير","لأن بقية الكتاب تُبنى عليه","لأنه مجاني","لأنه آخر فصل"], a: 1, why: "because the rest of the book builds on it." },
    { q: "ما الذي يركز عليه الجزء الثاني؟", o: ["الأساسيات","المشاريع العملية","المواضيع المتقدمة","التمارين فقط"], a: 1, why: "Part II focuses on practical projects." }
  ]
}
);
