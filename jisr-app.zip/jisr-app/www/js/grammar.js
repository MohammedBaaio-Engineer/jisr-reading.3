/* دروس قواعد إضافية تُدرج في المرحلة الثانية بترتيب متدرج */
(function () {
  const G = {
g1: {
  id: "g1", stage: "s2", title: "it و they و this: على ماذا تعود؟", minutes: 7,
  explain: `
  <p>كثير من سوء الفهم سببه سؤال بسيط: <b>على ماذا يعود الضمير؟</b> الكاتب الإنجليزي لا يكرر الاسم، بل يستبدله بضمير.</p>
  <table class="mini" dir="ltr"><tr><th>الضمير</th><th dir="rtl">يعود على</th></tr>
  <tr><td>it / its</td><td dir="rtl">شيء واحد (الملف، الخادم، البرنامج)</td></tr>
  <tr><td>they / them / their</td><td dir="rtl">جمع: أشخاص أو أشياء</td></tr>
  <tr><td>this / that</td><td dir="rtl">فكرة كاملة ذُكرت قبلها</td></tr>
  <tr><td>these / those</td><td dir="rtl">جمع قريب / بعيد</td></tr>
  <tr><td>one / ones</td><td dir="rtl">بدل اسم مذكور: the new one = الجديد</td></tr>
  <tr><td>the former / the latter</td><td dir="rtl">الأول / الأخير من شيئين</td></tr></table>
  <p><b>الحيلة:</b> عندما ترى <span class="en">it</span> ارجع للخلف وابحث عن <b>أقرب اسم مفرد</b> يناسب المعنى.</p>`,
  examples: [
    { en: "Download the file and open it.", ar: "نزّل الملف وافتحه.", note: "it = the file" },
    { en: "Users can change their passwords. They should do this every year.", ar: "يمكن للمستخدمين تغيير كلمات مرورهم. يجب أن يفعلوا ذلك كل سنة.", note: "They = Users، this = تغيير كلمة المرور" },
    { en: "We tested Python and Java. The former is easier for beginners.", ar: "جربنا بايثون وجافا. الأولى أسهل للمبتدئين.", note: "the former = Python" }
  ],
  reading: {
    title: "Cookies",
    paras: [
      { en: "A cookie is a small text file. Websites save it in your browser so they can remember you.", ar: "ملف تعريف الارتباط ملف نصي صغير. تحفظه المواقع في متصفحك حتى تتذكرك." },
      { en: "Some cookies are useful, because they keep you logged in. Others track what you do, and this worries many users.", ar: "بعض هذه الملفات مفيد، لأنها تبقيك مسجّل الدخول. وأخرى تتتبع ما تفعله، وهذا يقلق كثيراً من المستخدمين." },
      { en: "You can delete them at any time. However, if you delete the first kind, you will need to log in again.", ar: "يمكنك حذفها في أي وقت. لكن إذا حذفت النوع الأول ستحتاج لتسجيل الدخول مجدداً." }
    ]
  },
  vocab: [["it","هو / هي (لغير العاقل)"],["they","هم"],["their","خاصتهم"],["this","هذا"],["these","هؤلاء / هذه"],["those","أولئك"],["the former","الأول (من اثنين)"],["the latter","الأخير (من اثنين)"],["remember","يتذكر"],["track","يتتبع"],["worry","يقلق"],["kind","نوع"]],
  quiz: [
    { q: "Websites save it in your browser. على ماذا تعود it؟", o: ["الموقع","ملف cookie","المتصفح","المستخدم"], a: 1, why: "أقرب اسم مفرد يناسب المعنى: A cookie ... a small text file." },
    { q: "and this worries many users. ما الذي يقلق المستخدمين؟", o: ["الملفات المفيدة","تتبع ما يفعلونه","تسجيل الدخول","حذف الملفات"], a: 1, why: "this تعود على الفكرة كلها قبلها: Others track what you do." },
    { q: "if you delete the first kind... ما النوع الأول؟", o: ["الملفات التي تتتبعك","الملفات التي تبقيك مسجّل الدخول","المتصفح","كلمة المرور"], a: 1, why: "أول نوع ذُكر: Some cookies are useful, because they keep you logged in." }
  ]
},
g2: {
  id: "g2", stage: "s2", title: "حروف الجر الصغيرة التي تغيّر المعنى", minutes: 8,
  explain: `
  <p>حروف الجر قصيرة لكنها تحدد <b>المكان والزمن والطريقة</b>. هذه أهمها في النصوص التقنية:</p>
  <table class="mini" dir="ltr"><tr><th>الحرف</th><th dir="rtl">المعنى</th><th>مثال</th></tr>
  <tr><td>in</td><td dir="rtl">داخل / خلال</td><td>in the folder, in 5 minutes</td></tr>
  <tr><td>on</td><td dir="rtl">على / في يوم</td><td>on the screen, on Monday</td></tr>
  <tr><td>at</td><td dir="rtl">عند / في ساعة</td><td>at the top, at 9 PM</td></tr>
  <tr><td>to</td><td dir="rtl">إلى</td><td>send it to the server</td></tr>
  <tr><td>from</td><td dir="rtl">من</td><td>download from the site</td></tr>
  <tr><td>for</td><td dir="rtl">لـ / لمدة</td><td>for beginners, for 2 hours</td></tr>
  <tr><td>with</td><td dir="rtl">مع / باستخدام</td><td>open it with Notepad</td></tr>
  <tr><td>by</td><td dir="rtl">بواسطة / قبل موعد</td><td>created by Google, by Friday</td></tr>
  <tr><td>of</td><td dir="rtl">من / الإضافة</td><td>the end of the file</td></tr>
  <tr><td>about</td><td dir="rtl">عن / حوالي</td><td>about security, about 10 MB</td></tr></table>`,
  examples: [
    { en: "The button is at the bottom of the page.", ar: "الزر في أسفل الصفحة.", note: "at the bottom of = في أسفل" },
    { en: "Submit your project by Friday.", ar: "سلّم مشروعك قبل يوم الجمعة (بحد أقصى).", note: "by + موعد = قبله أو فيه" },
    { en: "This tool was built by developers for developers.", ar: "هذه الأداة بناها مطورون من أجل المطورين.", note: "by = بواسطة، for = من أجل" }
  ],
  reading: {
    title: "Sharing Files",
    paras: [
      { en: "To share a file with your team, upload it to the shared folder on the server.", ar: "لمشاركة ملف مع فريقك، ارفعه إلى المجلد المشترك على الخادم." },
      { en: "Files in this folder are deleted after 30 days. If you need a file for a longer period, move it to your personal folder.", ar: "الملفات في هذا المجلد تُحذف بعد 30 يوماً. إذا احتجت ملفاً لمدة أطول، انقله إلى مجلدك الشخصي." },
      { en: "The link at the top of the page lets people download the file without an account.", ar: "الرابط في أعلى الصفحة يتيح للناس تنزيل الملف بدون حساب." }
    ]
  },
  vocab: [["in","في / داخل"],["on","على"],["at","عند / في"],["to","إلى"],["from","من"],["for","لـ / لمدة"],["with","مع / باستخدام"],["by","بواسطة / قبل"],["of","من / لـ"],["about","عن / حوالي"],["at the top of","في أعلى"],["at the bottom of","في أسفل"],["shared","مشترك"],["without","بدون"]],
  quiz: [
    { q: "Files in this folder are deleted after 30 days. أين الملفات؟", o: ["على الخادم بعد 30 يوماً","داخل هذا المجلد","في المجلد الشخصي","في البريد"], a: 1, why: "in this folder = داخل هذا المجلد." },
    { q: "for a longer period تعني:", o: ["من أجل فترة أقصر","لمدة أطول","بعد فترة","قبل فترة"], a: 1, why: "for + مدة = لمدة." },
    { q: "Submit it by Monday تعني:", o: ["سلّمه بواسطة الاثنين","سلّمه قبل الاثنين أو فيه","سلّمه بعد الاثنين","سلّمه كل اثنين"], a: 1, why: "by + موعد = في موعد أقصاه." }
  ]
},
g3: {
  id: "g3", stage: "s2", title: "صيغة ing و to + فعل", minutes: 8,
  explain: `
  <p>الفعل الإنجليزي يتنكّر بأشكال كثيرة، وأشهرها:</p>
  <p><b>1. الفعل + ing كاسم:</b> <span class="en">Reading is useful</span> = القراءة مفيدة. هنا <span class="en">Reading</span> اسم (مصدر)، وليس فعلاً يحدث الآن.</p>
  <p><b>2. بعد حرف جر يأتي ing دائماً:</b> <span class="en">before installing</span> = قبل التثبيت، <span class="en">without saving</span> = بدون حفظ، <span class="en">by clicking</span> = بالضغط.</p>
  <p><b>3. to + فعل = لكي / أن:</b> <span class="en">Click here to continue</span> = اضغط هنا لكي تتابع. <span class="en">I want to learn</span> = أريد أن أتعلم.</p>
  <p><b>4. ing بعد اسم = يصفه:</b> <span class="en">the running process</span> = العملية التي تعمل، <span class="en">users visiting the site</span> = المستخدمون الذين يزورون الموقع.</p>`,
  examples: [
    { en: "Learning a new language takes time.", ar: "تعلّم لغة جديدة يستغرق وقتاً.", note: "Learning = التعلم (اسم)، الفعل الرئيسي takes" },
    { en: "Back up your data before updating the system.", ar: "انسخ بياناتك احتياطياً قبل تحديث النظام.", note: "before + ing" },
    { en: "Use a VPN to protect your connection.", ar: "استخدم VPN لحماية اتصالك.", note: "to protect = لكي تحمي" }
  ],
  reading: {
    title: "Writing Good Passwords",
    paras: [
      { en: "Creating a strong password is the first step to protecting your accounts.", ar: "إنشاء كلمة مرور قوية هو الخطوة الأولى لحماية حساباتك." },
      { en: "Avoid using your name or birthday. Instead, try combining three random words to make a long phrase.", ar: "تجنّب استخدام اسمك أو تاريخ ميلادك. بدلاً من ذلك جرّب دمج ثلاث كلمات عشوائية لتصنع عبارة طويلة." },
      { en: "Before saving it in your browser, think about using a password manager. People using these tools rarely forget their passwords.", ar: "قبل حفظها في متصفحك، فكّر في استخدام مدير كلمات مرور. الناس الذين يستخدمون هذه الأدوات نادراً ما ينسون كلمات مرورهم." }
    ]
  },
  vocab: [["creating","الإنشاء"],["protecting","الحماية"],["avoid using","تجنّب استخدام"],["combine","يدمج"],["random","عشوائي"],["phrase","عبارة"],["before saving","قبل الحفظ"],["think about","يفكر في"],["rarely","نادراً"],["in order to","لكي"],["by clicking","بالضغط على"],["without","بدون"]],
  quiz: [
    { q: "Creating a strong password is the first step. ما الفعل الرئيسي؟", o: ["Creating","is","strong","step"], a: 1, why: "Creating هنا اسم (الإنشاء)، والفعل الرئيسي is." },
    { q: "to make a long phrase تعني:", o: ["صنع عبارة","لكي تصنع عبارة طويلة","عبارة مصنوعة","يصنع عبارة"], a: 1, why: "to + فعل بعد جملة = لكي." },
    { q: "People using these tools rarely forget... من هم؟", o: ["الناس الذين يستخدمون هذه الأدوات","الناس الذين سيستخدمونها","الأدوات","كلمات المرور"], a: 0, why: "ing بعد اسم تصفه: الناس الذين يستخدمون." }
  ]
},
g4: {
  id: "g4", stage: "s2", title: "المقارنة: faster و more secure و the best", minutes: 7,
  explain: `
  <p>المقالات التقنية تقارن دائماً: أسرع، أكثر أماناً، الأفضل. الشكل ثابت:</p>
  <table class="mini" dir="ltr"><tr><th>النوع</th><th>مثال</th><th dir="rtl">المعنى</th></tr>
  <tr><td>كلمة قصيرة + er</td><td>faster than</td><td dir="rtl">أسرع من</td></tr>
  <tr><td>more + كلمة طويلة</td><td>more secure than</td><td dir="rtl">أكثر أماناً من</td></tr>
  <tr><td>less + صفة</td><td>less expensive</td><td dir="rtl">أقل تكلفة</td></tr>
  <tr><td>the + est</td><td>the fastest</td><td dir="rtl">الأسرع</td></tr>
  <tr><td>the most + صفة</td><td>the most popular</td><td dir="rtl">الأكثر شهرة</td></tr>
  <tr><td>as ... as</td><td>as fast as</td><td dir="rtl">بنفس سرعة</td></tr>
  <tr><td>شاذة</td><td>good → better → best، bad → worse → worst</td><td dir="rtl">جيد / أفضل / الأفضل</td></tr></table>`,
  examples: [
    { en: "SSD drives are much faster than old hard drives.", ar: "أقراص SSD أسرع بكثير من الأقراص الصلبة القديمة.", note: "much + er = أكثر بكثير" },
    { en: "Python is one of the most popular languages in the world.", ar: "بايثون واحدة من أكثر اللغات شهرة في العالم.", note: "one of the most = واحدة من أكثر" },
    { en: "The new version is not as stable as the old one.", ar: "الإصدار الجديد ليس مستقراً مثل القديم.", note: "not as ... as = ليس بقدر" }
  ],
  reading: {
    title: "Choosing a Laptop for Programming",
    paras: [
      { en: "For programming, memory is more important than a powerful graphics card. 16 GB of RAM is better than 8 GB, especially if you use virtual machines.", ar: "للبرمجة، الذاكرة أهم من بطاقة رسوميات قوية. 16 جيجا من الذاكرة أفضل من 8، خصوصاً إذا كنت تستخدم آلات افتراضية." },
      { en: "A lighter laptop is easier to carry, but it is usually more expensive.", ar: "اللابتوب الأخف أسهل في الحمل، لكنه عادة أغلى." },
      { en: "The best choice is not always the newest model. Older models are often cheaper and almost as fast.", ar: "أفضل اختيار ليس دائماً أحدث طراز. الطرازات الأقدم غالباً أرخص وسريعة تقريباً بالقدر نفسه." }
    ]
  },
  vocab: [["faster","أسرع"],["more important than","أهم من"],["better","أفضل"],["the best","الأفضل"],["worse","أسوأ"],["the most","الأكثر"],["less","أقل"],["as ... as","بنفس قدر"],["powerful","قوي"],["lighter","أخف"],["cheaper","أرخص"],["newest","الأحدث"],["especially","خصوصاً"]],
  quiz: [
    { q: "ما الأهم للبرمجة حسب النص؟", o: ["بطاقة الرسوميات","الذاكرة RAM","الوزن","اللون"], a: 1, why: "memory is more important than a powerful graphics card." },
    { q: "almost as fast تعني:", o: ["أسرع بكثير","سريعة تقريباً بنفس القدر","أبطأ بكثير","الأسرع"], a: 1, why: "as fast = بنفس السرعة، و almost = تقريباً." },
    { q: "ما عيب اللابتوب الأخف؟", o: ["أبطأ","عادة أغلى","أثقل","لا يعمل"], a: 1, why: "it is usually more expensive." }
  ]
},
g5: {
  id: "g5", stage: "s2", title: "الشرط: if و when و unless", minutes: 7,
  explain: `
  <p>التعليمات التقنية مليئة بالشرط: <b>إذا حدث كذا، افعل كذا</b>.</p>
  <table class="mini" dir="ltr"><tr><th>الشكل</th><th dir="rtl">المعنى</th></tr>
  <tr><td>If + حاضر, will / افعل</td><td dir="rtl">شرط واقعي: إذا ... فـ</td></tr>
  <tr><td>When + حاضر</td><td dir="rtl">عندما (سيحدث بالتأكيد)</td></tr>
  <tr><td>Unless</td><td dir="rtl">إلا إذا</td></tr>
  <tr><td>If ... were / would</td><td dir="rtl">شرط افتراضي: لو كان ... لـ</td></tr>
  <tr><td>If ... had + V3, would have</td><td dir="rtl">ندم على الماضي: لو كان فعل ... لكان</td></tr>
  <tr><td>In case / Otherwise</td><td dir="rtl">في حال / وإلا</td></tr></table>
  <p><b>نصيحة:</b> جملة الشرط قد تأتي في آخر الجملة: <span class="en">The app crashes if the file is too large.</span></p>`,
  examples: [
    { en: "If you forget your password, click Reset.", ar: "إذا نسيت كلمة المرور، اضغط إعادة تعيين.", note: "شرط واقعي" },
    { en: "If I had more time, I would learn Go.", ar: "لو كان لدي وقت أكثر لتعلمت لغة Go.", note: "شرط افتراضي: ليس لدي وقت حالياً" },
    { en: "If we had tested the code, the bug would have been found.", ar: "لو كنا اختبرنا الكود لاكتُشف الخلل.", note: "ماضٍ لم يحدث" }
  ],
  reading: {
    title: "Troubleshooting Wi-Fi",
    paras: [
      { en: "If your laptop cannot connect to Wi-Fi, first make sure that airplane mode is off.", ar: "إذا لم يستطع حاسوبك الاتصال بالشبكة اللاسلكية، تأكد أولاً أن وضع الطيران مغلق." },
      { en: "When the router restarts, wait about two minutes before you try again. Unless the problem continues, you do not need to call support.", ar: "عندما يعيد الموجّه التشغيل، انتظر دقيقتين تقريباً قبل المحاولة مجدداً. إلا إذا استمرت المشكلة، فلا حاجة للاتصال بالدعم." },
      { en: "If you had updated the network driver last month, this error would probably not have appeared.", ar: "لو كنت حدّثت تعريف الشبكة الشهر الماضي، لما ظهر هذا الخطأ على الأرجح." }
    ]
  },
  vocab: [["if","إذا"],["when","عندما"],["unless","إلا إذا"],["would","كان سـ / لـ"],["would have","لكان"],["in case","في حال"],["otherwise","وإلا"],["airplane mode","وضع الطيران"],["restart","يعيد التشغيل"],["driver","برنامج التعريف"],["call support","يتصل بالدعم"],["make sure","يتأكد"]],
  quiz: [
    { q: "ما أول خطوة إذا لم يتصل اللابتوب؟", o: ["الاتصال بالدعم","التأكد أن وضع الطيران مغلق","شراء موجه","حذف التعريف"], a: 1, why: "first make sure that airplane mode is off." },
    { q: "متى تحتاج الاتصال بالدعم؟", o: ["دائماً","إذا استمرت المشكلة","أبداً","قبل إعادة التشغيل"], a: 1, why: "Unless the problem continues, you do not need to call support." },
    { q: "If you had updated the driver... هل حدّث المستخدم التعريف؟", o: ["نعم","لا، لم يحدّثه","سيحدّثه","غير واضح"], a: 1, why: "If + had + V3 تتحدث عن شيء لم يحدث في الماضي." }
  ]
},
g6: {
  id: "g6", stage: "s2", title: "الأفعال المركبة: set up و log in", minutes: 8,
  explain: `
  <p>الأفعال المركبة (Phrasal verbs) = فعل + كلمة صغيرة، و<b>المعنى يتغير كلياً</b>. لا تترجم كل كلمة وحدها!</p>
  <p><span class="en">set</span> = يضع، لكن <span class="en">set up</span> = يُعدّ ويجهّز. <span class="en">find</span> = يجد، لكن <span class="en">find out</span> = يكتشف ويعرف.</p>
  <table class="mini" dir="ltr"><tr><th>الفعل</th><th dir="rtl">المعنى</th></tr>
  <tr><td>log in / sign up / sign out</td><td dir="rtl">يدخل / يسجّل حساباً / يخرج</td></tr>
  <tr><td>set up</td><td dir="rtl">يُعدّ / يجهّز</td></tr>
  <tr><td>back up</td><td dir="rtl">ينسخ احتياطياً</td></tr>
  <tr><td>figure out</td><td dir="rtl">يفهم / يجد الحل</td></tr>
  <tr><td>run out of</td><td dir="rtl">ينفد منه</td></tr>
  <tr><td>shut down / boot up</td><td dir="rtl">يطفئ / يقلع</td></tr>
  <tr><td>look up</td><td dir="rtl">يبحث عن معلومة</td></tr>
  <tr><td>break down</td><td dir="rtl">يتعطل / يقسّم ويشرح</td></tr>
  <tr><td>roll back</td><td dir="rtl">يرجع لإصدار سابق</td></tr></table>
  <p><b>الحيلة:</b> إذا ترجمت الجملة كلمة كلمة وخرج معنى غريب، ابحث عن فعل مركب.</p>`,
  examples: [
    { en: "It took me an hour to figure out the problem.", ar: "استغرقني ساعة لأفهم المشكلة وأجد حلها.", note: "figure out ≠ figure" },
    { en: "The server ran out of memory and shut down.", ar: "نفدت ذاكرة الخادم فتوقف عن العمل.", note: "ran out of = نفد" },
    { en: "Let's break this sentence down into smaller parts.", ar: "لنقسّم هذه الجملة إلى أجزاء أصغر.", note: "break down مفصولة بكلمة this sentence" }
  ],
  reading: {
    title: "Your First Server",
    paras: [
      { en: "Setting up your first server can feel scary, but the process is simpler than it looks.", ar: "إعداد أول خادم لك قد يبدو مخيفاً، لكن العملية أبسط مما تبدو." },
      { en: "First, sign up for a cloud account and log in to the dashboard. Then create a server and write down its IP address.", ar: "أولاً، سجّل في حساب سحابي وادخل إلى لوحة التحكم. ثم أنشئ خادماً ودوّن عنوان IP الخاص به." },
      { en: "Back up your data regularly. If something goes wrong after an update, you can roll back to the previous version instead of starting over.", ar: "انسخ بياناتك احتياطياً بانتظام. إذا حدث خطأ بعد تحديث، يمكنك الرجوع إلى الإصدار السابق بدلاً من البدء من جديد." }
    ]
  },
  vocab: [["set up","يُعدّ / يجهّز"],["sign up","يسجّل حساباً"],["log in","يدخل للحساب"],["write down","يدوّن"],["back up","ينسخ احتياطياً"],["go wrong","يحدث خطأ"],["roll back","يرجع لإصدار سابق"],["start over","يبدأ من جديد"],["figure out","يكتشف الحل"],["run out of","ينفد منه"],["shut down","يطفئ / يتوقف"],["break down","يقسّم / يتعطل"],["scary","مخيف"]],
  quiz: [
    { q: "write down its IP address تعني:", o: ["اكتب للأسفل","دوّن عنوان IP","احذف العنوان","غيّر العنوان"], a: 1, why: "write down = يدوّن، فعل مركب." },
    { q: "ماذا تفعل إذا حدث خطأ بعد تحديث؟", o: ["تبدأ من جديد","ترجع للإصدار السابق","تشتري خادماً","تحذف الحساب"], a: 1, why: "you can roll back to the previous version instead of starting over." },
    { q: "The battery ran out تعني:", o: ["البطارية ركضت","البطارية نفدت","البطارية جديدة","البطارية خرجت"], a: 1, why: "run out = نفد." }
  ]
}
  };
  const L = window.LESSONS;
  const ins = (afterId, g) => { const i = L.findIndex((x) => x.id === afterId); L.splice(i + 1, 0, g); };
  ins("l4", G.g1); ins("g1", G.g2);
  ins("l7", G.g3); ins("g3", G.g4);
  ins("l9", G.g5);
  ins("l10", G.g6);
})();
