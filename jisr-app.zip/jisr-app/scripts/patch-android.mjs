// يضبط مشروع أندرويد المُولَّد: أذونات الإشعارات وأيقونة الإشعار الصغيرة
import { readFileSync, writeFileSync, existsSync, mkdirSync, copyFileSync } from "node:fs";
import { join, dirname } from "node:path";
import { createRequire } from "node:module";

const root = process.cwd();
const manifestPath = join(root, "android/app/src/main/AndroidManifest.xml");

if (!existsSync(manifestPath)) {
  console.error("لم يُعثر على مجلد android. شغّل أولاً: npx cap add android");
  process.exit(1);
}

let manifest = readFileSync(manifestPath, "utf8");
const permissions = [
  "android.permission.POST_NOTIFICATIONS",
  "android.permission.RECEIVE_BOOT_COMPLETED",
  "android.permission.WAKE_LOCK"
];
for (const p of permissions) {
  if (!manifest.includes(`"${p}"`)) {
    manifest = manifest.replace("</manifest>", `    <uses-permission android:name="${p}" />\n</manifest>`);
    console.log("أُضيف الإذن:", p);
  }
}
// أندرويد 11+ يحتاج إعلان الوصول لخدمة النطق حتى يجد التطبيق محرك تحويل النص إلى كلام
if (!manifest.includes("android.intent.action.TTS_SERVICE")) {
  manifest = manifest.replace(
    "</manifest>",
    `    <queries>\n        <intent>\n            <action android:name="android.intent.action.TTS_SERVICE" />\n        </intent>\n    </queries>\n</manifest>`
  );
  console.log("أُضيف إعلان خدمة النطق TTS_SERVICE");
}
writeFileSync(manifestPath, manifest);

// أيقونة الإشعار الصغيرة (بيضاء بخلفية شفافة كما يتطلب أندرويد)
const drawable = join(root, "android/app/src/main/res/drawable");
mkdirSync(drawable, { recursive: true });
copyFileSync(join(root, "assets/ic_stat_jisr.png"), join(drawable, "ic_stat_jisr.png"));

// نسخ مكتبات Capacitor الجاهزة (بدون أداة تجميع) إلى www/capacitor حتى تعمل الإشعارات والنطق
const require = createRequire(join(root, "package.json"));
const libs = [
  ["@capacitor/core", "core.js", ["dist/capacitor.js"]],
  ["@capacitor/local-notifications", "local-notifications.js", ["dist/plugin.js"]],
  ["@capacitor-community/text-to-speech", "text-to-speech.js", ["dist/plugin.js"]]
];
const outDir = join(root, "www/capacitor");
mkdirSync(outDir, { recursive: true });
for (const [pkg, out, guesses] of libs) {
  let pkgDir;
  try { pkgDir = dirname(require.resolve(pkg + "/package.json")); }
  catch (e) { console.warn("لم تُثبَّت الحزمة:", pkg); continue; }
  const meta = JSON.parse(readFileSync(join(pkgDir, "package.json"), "utf8"));
  const candidates = [meta.unpkg, meta.jsdelivr, ...guesses].filter(Boolean);
  const found = candidates.map((c) => join(pkgDir, c)).find((f) => existsSync(f));
  if (!found) { console.warn("لم يُعثر على ملف المتصفح للحزمة:", pkg); continue; }
  copyFileSync(found, join(outDir, out));
  console.log("نُسخت مكتبة:", pkg, "←", "www/capacitor/" + out);
}
console.log("تم ضبط مشروع أندرويد.");
