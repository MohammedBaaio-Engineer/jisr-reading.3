// يضبط مشروع أندرويد المُولَّد: أذونات الإشعارات وأيقونة الإشعار الصغيرة
import { readFileSync, writeFileSync, existsSync, mkdirSync, copyFileSync } from "node:fs";
import { join, dirname } from "node:path";
import { createRequire } from "node:module";
import { homedir } from "node:os";

const root = process.cwd();
const manifestPath = join(root, "android/app/src/main/AndroidManifest.xml");

if (!existsSync(manifestPath)) {
  console.error("لم يُعثر على مجلد android. شغّل أولاً: npx cap add android");
  process.exit(1);
}

let manifest = readFileSync(manifestPath, "utf8");
const permissions = [
  "android.permission.POST_NOTIFICATIONS",
  "android.permission.RECEIVE_BOOT_COMPLETED",
  "android.permission.WAKE_LOCK"
];
for (const p of permissions) {
  if (!manifest.includes(`"${p}"`)) {
    manifest = manifest.replace("</manifest>", `    <uses-permission android:name="${p}" />\n</manifest>`);
    console.log("أُضيف الإذن:", p);
  }
}
// أندرويد 11+ يحتاج إعلان الوصول لخدمة النطق حتى يجد التطبيق محرك تحويل النص إلى كلام
if (!manifest.includes("android.intent.action.TTS_SERVICE")) {
  manifest = manifest.replace(
    "</manifest>",
    `    <queries>\n        <intent>\n            <action android:name="android.intent.action.TTS_SERVICE" />\n        </intent>\n    </queries>\n</manifest>`
  );
  console.log("أُضيف إعلان خدمة النطق TTS_SERVICE");
}
writeFileSync(manifestPath, manifest);

// أيقونة الإشعار الصغيرة (بيضاء بخلفية شفافة كما يتطلب أندرويد)
const drawable = join(root, "android/app/src/main/res/drawable");
mkdirSync(drawable, { recursive: true });
copyFileSync(join(root, "assets/ic_stat_jisr.png"), join(drawable, "ic_stat_jisr.png"));

// نسخ مكتبات Capacitor الجاهزة (بدون أداة تجميع) إلى www/capacitor حتى تعمل الإشعارات والنطق
const require = createRequire(join(root, "package.json"));
const libs = [
  ["@capacitor/core", "core.js", ["dist/capacitor.js"]],
  ["@capacitor/local-notifications", "local-notifications.js", ["dist/plugin.js"]],
  ["@capacitor-community/text-to-speech", "text-to-speech.js", ["dist/plugin.js"]]
];
const outDir = join(root, "www/capacitor");
mkdirSync(outDir, { recursive: true });
for (const [pkg, out, guesses] of libs) {
  let pkgDir;
  try { pkgDir = dirname(require.resolve(pkg + "/package.json")); }
  catch (e) { console.warn("لم تُثبَّت الحزمة:", pkg); continue; }
  const meta = JSON.parse(readFileSync(join(pkgDir, "package.json"), "utf8"));
  const candidates = [meta.unpkg, meta.jsdelivr, ...guesses].filter(Boolean);
  const found = candidates.map((c) => join(pkgDir, c)).find((f) => existsSync(f));
  if (!found) { console.warn("لم يُعثر على ملف المتصفح للحزمة:", pkg); continue; }
  copyFileSync(found, join(outDir, out));
  console.log("نُسخت مكتبة:", pkg, "←", "www/capacitor/" + out);
}

// ===== توقيع ثابت: نفس المفتاح في كل بناء حتى يُثبَّت كل إصدار جديد كتحديث فوق القديم =====
const keystoreSrc = join(root, "keystore/jisr-debug.keystore");
if (existsSync(keystoreSrc)) {
  // 1) داخل مشروع التطبيق وربطه في build.gradle
  copyFileSync(keystoreSrc, join(root, "android/app/jisr-debug.keystore"));
  const gradlePath = join(root, "android/app/build.gradle");
  if (existsSync(gradlePath)) {
    let g = readFileSync(gradlePath, "utf8");
    if (!g.includes("jisr-debug.keystore")) {
      g = g.replace(/android\s*\{/, `android {
    signingConfigs {
        debug {
            storeFile file("jisr-debug.keystore")
            storePassword "android"
            keyAlias "androiddebugkey"
            keyPassword "android"
        }
    }`);
    }
    // 2) رقم إصدار يزيد مع كل بناء
    const run = parseInt(process.env.GITHUB_RUN_NUMBER || "1", 10) || 1;
    g = g.replace(/versionCode\s+\d+/, "versionCode " + run).replace(/versionName\s+"[^"]*"/, `versionName "1.${run}"`);
    writeFileSync(gradlePath, g);
    console.log("تم ضبط التوقيع الثابت ورقم الإصدار:", run);
  } else {
    console.warn("لم يُعثر على android/app/build.gradle");
  }
  // 3) احتياط: المكان الافتراضي لمفتاح التطوير
  const homes = [join(homedir(), ".android"), process.env.ANDROID_USER_HOME, process.env.ANDROID_SDK_HOME && join(process.env.ANDROID_SDK_HOME, ".android")].filter(Boolean);
  for (const h of homes) {
    try { mkdirSync(h, { recursive: true }); copyFileSync(keystoreSrc, join(h, "debug.keystore")); } catch (e) { /* تجاهل */ }
  }
}
console.log("تم ضبط مشروع أندرويد.");
