// يضبط مشروع أندرويد المُولَّد: أذونات الإشعارات وأيقونة الإشعار الصغيرة
import { readFileSync, writeFileSync, existsSync, mkdirSync, copyFileSync } from "node:fs";
import { join } from "node:path";

const root = process.cwd();
const manifestPath = join(root, "android/app/src/main/AndroidManifest.xml");

if (!existsSync(manifestPath)) {
  console.error("لم يُعثر على مجلد android. شغّل أولاً: npx cap add android");
  process.exit(1);
}

let manifest = readFileSync(manifestPath, "utf8");
const permissions = [
  "android.permission.POST_NOTIFICATIONS",
  "android.permission.RECEIVE_BOOT_COMPLETED",
  "android.permission.WAKE_LOCK"
];
for (const p of permissions) {
  if (!manifest.includes(`"${p}"`)) {
    manifest = manifest.replace("</manifest>", `    <uses-permission android:name="${p}" />\n</manifest>`);
    console.log("أُضيف الإذن:", p);
  }
}
writeFileSync(manifestPath, manifest);

// أيقونة الإشعار الصغيرة (بيضاء بخلفية شفافة كما يتطلب أندرويد)
const drawable = join(root, "android/app/src/main/res/drawable");
mkdirSync(drawable, { recursive: true });
copyFileSync(join(root, "assets/ic_stat_jisr.png"), join(drawable, "ic_stat_jisr.png"));
console.log("تم ضبط مشروع أندرويد.");
